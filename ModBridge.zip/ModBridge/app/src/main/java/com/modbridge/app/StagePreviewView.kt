package com.modbridge.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.util.Xml
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import kotlin.math.abs
import kotlin.math.max

private class Piece(
    val name: String, val bmp: Bitmap, val src: Rect,
    val fx: Float, val fy: Float, val fw: Float, val fh: Float, val sw: Float, val sh: Float
)

private class Asset(val pieces: List<Piece>) {
    fun frames(prefix: String): List<Piece> {
        if (pieces.size <= 1) return pieces
        var p = prefix
        if (p.isEmpty()) p = pieces[0].name.trimEnd { it.isDigit() }
        val list = pieces.filter { it.name.startsWith(p) }.sortedBy { it.name }
        return if (list.isEmpty()) listOf(pieces[0]) else list
    }
}

private class CharInfo(
    val asset: Asset?, val scale: Float, val flipX: Boolean, val posX: Float, val posY: Float,
    val camX: Float, val camY: Float, val offX: Float, val offY: Float, val prefix: String, val fps: Float
)

/** Live stage preview: draws the stage, characters and camera frame; supports dragging and pinch-zoom. */
internal class StagePreviewView(context: Context) : View(context) {
    var session: StageSession? = null
    var state: StageState? = null
    var selected: String = ""
    var cameraFocus: Int = 0 // 0 off, 1 bf, 2 dad, 3 gf
    var playing: Boolean = true
    var onPick: ((String) -> Unit)? = null
    var onEdited: (() -> Unit)? = null

    private var zoom = 0.45f
    private var panX = 40f
    private var panY = 40f
    private var fitted = false
    private val assets = HashMap<String, Asset?>()
    private val gifAssets = HashMap<String, Asset?>()
    private val chars = HashMap<String, CharInfo?>()
    private val rects = LinkedHashMap<String, RectF>()
    private val markers = LinkedHashMap<String, Pair<Float, Float>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val nz = (zoom * d.scaleFactor).coerceIn(0.06f, 4f)
            panX = d.focusX - (d.focusX - panX) * (nz / zoom)
            panY = d.focusY - (d.focusY - panY) * (nz / zoom)
            zoom = nz
            invalidate()
            return true
        }
    })

    fun clearCache() {
        assets.clear(); gifAssets.values.forEach { a -> a?.pieces?.forEach { it.bmp.recycle() } }
        gifAssets.clear(); chars.clear()
        invalidate()
    }

    fun fitView() {
        if (width == 0 || height == 0) return
        zoom = (width / 1700f).coerceAtMost(height / 1000f).coerceIn(0.1f, 1.5f)
        panX = width / 2f - 640f * zoom
        panY = height / 2f - 360f * zoom
        fitted = true
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted) fitView()
    }

    // ---------- assets ----------
    private fun loadAsset(imagePath: String): Asset? {
        val s = session ?: return null
        val bytes = s.read("images/$imagePath.png") ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val ow = bounds.outWidth; val oh = bounds.outHeight
        if (ow <= 0 || oh <= 0) return null
        var sample = 1
        while (max(ow, oh) / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
        val xml = s.readText("images/$imagePath.xml")
        if (xml == null) {
            return Asset(listOf(Piece("", bmp, Rect(0, 0, bmp.width, bmp.height), 0f, 0f, ow.toFloat(), oh.toFloat(), ow.toFloat(), oh.toFloat())))
        }
        val list = ArrayList<Piece>()
        try {
            val p = Xml.newPullParser()
            p.setInput(StringReader(xml))
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "SubTexture") {
                    fun f(n: String): Float? = p.getAttributeValue(null, n)?.toFloatOrNull()
                    val x = f("x") ?: 0f; val y = f("y") ?: 0f; val w = f("width") ?: 0f; val h = f("height") ?: 0f
                    val fx = f("frameX") ?: 0f; val fy = f("frameY") ?: 0f
                    val fw = f("frameWidth") ?: w; val fh = f("frameHeight") ?: h
                    val l = (x / sample).toInt().coerceIn(0, bmp.width - 1)
                    val t = (y / sample).toInt().coerceIn(0, bmp.height - 1)
                    val r = ((x + w) / sample).toInt().coerceIn(l + 1, bmp.width)
                    val b = ((y + h) / sample).toInt().coerceIn(t + 1, bmp.height)
                    list.add(Piece(p.getAttributeValue(null, "name") ?: "", bmp, Rect(l, t, r, b), fx, fy, fw, fh, w, h))
                }
                ev = p.next()
            }
        } catch (t: Exception) { /* fall through with what was parsed */ }
        if (list.isEmpty()) return Asset(listOf(Piece("", bmp, Rect(0, 0, bmp.width, bmp.height), 0f, 0f, ow.toFloat(), oh.toFloat(), ow.toFloat(), oh.toFloat())))
        return Asset(list)
    }

    private fun asset(path: String): Asset? {
        if (assets.containsKey(path)) return assets[path]
        val a = loadAsset(path)
        assets[path] = a
        return a
    }

    private fun gifAsset(o: StageObj): Asset? {
        if (gifAssets.containsKey(o.id)) return gifAssets[o.id]
        val bytes = o.gifBytes
        var a: Asset? = null
        if (bytes != null) {
            val g = GifDecoder.decode(bytes, 40, 1024, 24L * 1024 * 1024)
            if (g != null) {
                a = Asset(g.frames.mapIndexed { i, b ->
                    Piece("f$i", b, Rect(0, 0, b.width, b.height), 0f, 0f, g.origW.toFloat(), g.origH.toFloat(), g.origW.toFloat(), g.origH.toFloat())
                })
                o.fps = g.fps
            }
        }
        gifAssets[o.id] = a
        return a
    }

    private fun charInfo(name: String): CharInfo? {
        if (chars.containsKey(name)) return chars[name]
        val s = session
        var info: CharInfo? = null
        val text = s?.readText("characters/$name.json")
        if (text != null) {
            try {
                val j = JSONObject(text)
                val image = j.optString("image", "")
                val anims = j.optJSONArray("animations")
                var prefix = ""; var fps = 24f; var ox = 0f; var oy = 0f
                if (anims != null) {
                    var pick: JSONObject? = null
                    for (i in 0 until anims.length()) {
                        val a = anims.optJSONObject(i) ?: continue
                        val an = a.optString("anim")
                        if (an == "idle" || (an == "danceLeft" && pick == null)) pick = a
                        if (pick == null && i == 0) pick = a
                    }
                    if (pick != null) {
                        prefix = pick.optString("name", "")
                        fps = pick.optDouble("fps", 24.0).toFloat()
                        val off = pick.optJSONArray("offsets")
                        if (off != null) { ox = off.optDouble(0, 0.0).toFloat(); oy = off.optDouble(1, 0.0).toFloat() }
                    }
                }
                val pos = j.optJSONArray("position"); val cam = j.optJSONArray("camera_position")
                info = CharInfo(
                    if (image.isNotEmpty()) asset(image) else null,
                    j.optDouble("scale", 1.0).toFloat(), j.optBoolean("flip_x", false),
                    pos?.optDouble(0, 0.0)?.toFloat() ?: 0f, pos?.optDouble(1, 0.0)?.toFloat() ?: 0f,
                    cam?.optDouble(0, 0.0)?.toFloat() ?: 0f, cam?.optDouble(1, 0.0)?.toFloat() ?: 0f,
                    ox, oy, prefix, fps
                )
            } catch (t: Exception) { info = null }
        }
        chars[name] = info
        return info
    }

    // ---------- drawing ----------
    private fun pieceFor(a: Asset, prefix: String, fps: Float): Piece {
        val list = a.frames(prefix)
        if (list.size == 1 || !playing) return list[0]
        val idx = ((SystemClock.uptimeMillis() / (1000f / fps.coerceIn(1f, 60f))).toInt()) % list.size
        return list[idx]
    }

    /** Draws a frame box whose top-left is (left, top). Returns the box rectangle in world units. */
    private fun drawPiece(c: Canvas, p: Piece, left: Float, top: Float, sx: Float, sy: Float, flipX: Boolean, flipY: Boolean, alpha: Float, angle: Float): RectF {
        val box = RectF(left, top, left + p.fw * sx, top + p.fh * sy)
        val dst = RectF(left - p.fx * sx, top - p.fy * sy, left - p.fx * sx + p.sw * sx, top - p.fy * sy + p.sh * sy)
        c.save()
        if (angle != 0f) c.rotate(angle, box.centerX(), box.centerY())
        if (flipX || flipY) c.scale(if (flipX) -1f else 1f, if (flipY) -1f else 1f, box.centerX(), box.centerY())
        paint.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt()
        c.drawBitmap(p.bmp, p.src, dst, paint)
        paint.alpha = 255
        c.restore()
        return box
    }

    private fun placeholder(c: Canvas, label: String, x: Float, y: Float, w: Float, h: Float, color: Int): RectF {
        val r = RectF(x, y, x + w, y + h)
        fill.color = color; fill.alpha = 90
        c.drawRect(r, fill)
        fill.alpha = 255
        stroke.color = color; stroke.strokeWidth = 2f / zoom
        c.drawRect(r, stroke)
        text.textSize = 28f / zoom.coerceAtLeast(0.2f)
        c.drawText(label, r.left + 6f, r.top + 34f / zoom.coerceAtLeast(0.2f), text)
        return r
    }

    private fun drawObject(c: Canvas, o: StageObj) {
        val st = o.scaleX / (if (o.downscale > 0f) o.downscale else 1f)
        val sy = o.scaleY / (if (o.downscale > 0f) o.downscale else 1f)
        val a = if (o.kind == ObjKind.GIF) gifAsset(o) else asset(o.image)
        val r: RectF = if (a == null) {
            placeholder(c, o.tag, o.x, o.y, 200f * o.scaleX, 120f * o.scaleY, 0xFFFF8800.toInt())
        } else {
            val piece = pieceFor(a, o.prefix, o.fps.toFloat())
            drawPiece(c, piece, o.x, o.y, st, sy, o.flipX, o.flipY, o.alpha, o.angle)
        }
        rects[o.id] = r
    }

    private fun drawChar(c: Canvas, key: String, name: String, pos: Pt, isPlayer: Boolean, label: String, color: Int) {
        val info = charInfo(name)
        val r: RectF
        var camX = 0f; var camY = 0f
        if (info == null || info.asset == null) {
            r = placeholder(c, "$label ($name)", pos.x, pos.y, 330f, 420f, color)
        } else {
            val piece = pieceFor(info.asset, info.prefix, info.fps)
            val flip = info.flipX != isPlayer
            r = drawPiece(c, piece, pos.x + info.posX - info.offX, pos.y + info.posY - info.offY, info.scale, info.scale, flip, false, 1f, 0f)
            camX = info.camX; camY = info.camY
        }
        rects[key] = r
        val st = state ?: return
        val mx = r.centerX(); val my = r.centerY()
        when (key) {
            "bf" -> markers["cam_bf"] = Pair(mx - 100f - (camX - st.camBf.x), my - 100f + camY + st.camBf.y)
            "dad" -> markers["cam_dad"] = Pair(mx + 150f + camX + st.camDad.x, my - 100f + camY + st.camDad.y)
            else -> markers["cam_gf"] = Pair(mx + camX + st.camGf.x, my + camY + st.camGf.y)
        }
    }

    override fun onDraw(c: Canvas) {
        val st = state
        c.drawColor(0xFF15151C.toInt())
        if (st == null) return
        rects.clear(); markers.clear()
        c.save()
        c.translate(panX, panY)
        c.scale(zoom, zoom)
        // stage reference frame 1280x720
        stroke.color = 0x55FFFFFF; stroke.strokeWidth = 1.5f / zoom
        c.drawRect(0f, 0f, 1280f, 720f, stroke)
        for (o in st.objects) if (!o.removed && !o.front) drawObject(c, o)
        if (!st.hideGf) drawChar(c, "gf", st.gfChar, st.gf, false, "GF", 0xFFE04080.toInt())
        drawChar(c, "dad", st.dadChar, st.dad, false, "Dad", 0xFFB040E0.toInt())
        drawChar(c, "bf", st.bfChar, st.bf, true, "BF", 0xFF3090FF.toInt())
        for (o in st.objects) if (!o.removed && o.front) drawObject(c, o)

        // camera frame for the chosen focus
        val focusKey = when (cameraFocus) { 1 -> "cam_bf"; 2 -> "cam_dad"; 3 -> "cam_gf"; else -> "" }
        val fm = markers[focusKey]
        if (fm != null && st.defaultZoom > 0f) {
            val w = 1280f / st.defaultZoom; val h = 720f / st.defaultZoom
            stroke.color = 0xFF00E5FF.toInt(); stroke.strokeWidth = 3f / zoom
            c.drawRect(fm.first - w / 2f, fm.second - h / 2f, fm.first + w / 2f, fm.second + h / 2f, stroke)
        }
        // camera markers
        for ((k, pt) in markers) {
            fill.color = when (k) { "cam_bf" -> 0xFF3090FF.toInt(); "cam_dad" -> 0xFFB040E0.toInt(); else -> 0xFFE04080.toInt() }
            val rad = 14f / zoom
            c.drawCircle(pt.first, pt.second, rad, fill)
            stroke.color = 0xFFFFFFFF.toInt(); stroke.strokeWidth = 2f / zoom
            c.drawCircle(pt.first, pt.second, rad, stroke)
            c.drawLine(pt.first - rad * 1.6f, pt.second, pt.first + rad * 1.6f, pt.second, stroke)
            c.drawLine(pt.first, pt.second - rad * 1.6f, pt.first, pt.second + rad * 1.6f, stroke)
        }
        // selection outline
        val sel = rects[selected]
        if (sel != null) {
            stroke.color = 0xFFFFEB3B.toInt(); stroke.strokeWidth = 3f / zoom
            c.drawRect(sel, stroke)
        }
        val ms = markers[selected]
        if (ms != null) {
            stroke.color = 0xFFFFEB3B.toInt(); stroke.strokeWidth = 4f / zoom
            c.drawCircle(ms.first, ms.second, 24f / zoom, stroke)
        }
        c.restore()
        if (playing) postInvalidateOnAnimation()
    }

    /** Renders the 1280x720 stage frame (no markers or outlines) into a bitmap for the shader test view. */
    fun snapshot(w: Int, h: Int): Bitmap? {
        val st = state ?: return null
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(0xFF15151C.toInt())
        c.scale(w / 1280f, h / 720f)
        for (o in st.objects) if (!o.removed && !o.front) drawObject(c, o)
        if (!st.hideGf) drawChar(c, "gf", st.gfChar, st.gf, false, "GF", 0xFFE04080.toInt())
        drawChar(c, "dad", st.dadChar, st.dad, false, "Dad", 0xFFB040E0.toInt())
        drawChar(c, "bf", st.bfChar, st.bf, true, "BF", 0xFF3090FF.toInt())
        for (o in st.objects) if (!o.removed && o.front) drawObject(c, o)
        postInvalidate()
        return bmp
    }

    // ---------- touch ----------
    private fun hit(wx: Float, wy: Float): String? {
        val r = 34f / zoom
        for ((k, pt) in markers.entries.reversed()) if (abs(pt.first - wx) < r && abs(pt.second - wy) < r) return k
        val st = state ?: return null
        val order = ArrayList<String>()
        order.addAll(st.objects.filter { !it.removed && it.front }.map { it.id }.reversed())
        order.add("bf"); order.add("dad"); if (!st.hideGf) order.add("gf")
        order.addAll(st.objects.filter { !it.removed && !it.front }.map { it.id }.reversed())
        for (k in order) if (rects[k]?.contains(wx, wy) == true) return k
        return null
    }

    private fun applyDrag(key: String, dx: Float, dy: Float) {
        val st = state ?: return
        when (key) {
            "bf" -> { st.bf.x += dx; st.bf.y += dy }
            "dad" -> { st.dad.x += dx; st.dad.y += dy }
            "gf" -> { st.gf.x += dx; st.gf.y += dy }
            "cam_bf" -> { st.camBf.x += dx; st.camBf.y += dy }
            "cam_dad" -> { st.camDad.x += dx; st.camDad.y += dy }
            "cam_gf" -> { st.camGf.x += dx; st.camGf.y += dy }
            else -> st.objects.firstOrNull { it.id == key }?.let { it.x += dx; it.y += dy }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        parent?.requestDisallowInterceptTouchEvent(true)
        if (scaler.isInProgress || e.pointerCount > 1) {
            dragging = false
            lastX = e.getX(0); lastY = e.getY(0)
            if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) { val i = if (e.actionIndex == 0) 1 else 0; if (i < e.pointerCount) { lastX = e.getX(i); lastY = e.getY(i) } }
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y
                val h = hit((e.x - panX) / zoom, (e.y - panY) / zoom)
                if (h != null) { selected = h; dragging = true; onPick?.invoke(h) } else dragging = false
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX; val dy = e.y - lastY
                lastX = e.x; lastY = e.y
                if (dragging) applyDrag(selected, dx / zoom, dy / zoom) else { panX += dx; panY += dy }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) onEdited?.invoke()
                dragging = false
            }
        }
        return true
    }
}
