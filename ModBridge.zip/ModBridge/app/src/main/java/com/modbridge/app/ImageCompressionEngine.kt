package com.modbridge.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Movie
import android.graphics.Paint
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.DataOutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

internal enum class ImageOutputFormat(val label: String, val mime: String, val extension: String) {
    PNG("PNG", "image/png", "png"),
    WEBP("WebP", "image/webp", "webp"),
    JPEG("JPEG", "image/jpeg", "jpg"),
    GIF("GIF متحرك", "image/gif", "gif")
}

internal data class ImageCompressionSettings(
    val quality: Int = 82,
    val scalePercent: Int = 100,
    val format: ImageOutputFormat = ImageOutputFormat.PNG,
    val preserveTransparency: Boolean = true,
    val backgroundColor: Int = Color.WHITE
)

internal data class ImageCompressionResult(
    val originalName: String,
    val outputName: String,
    val originalBytes: Long,
    val output: ByteArray,
    val mime: String,
    val warning: String = "",
    val frames: Int = 1
) {
    val savedBytes: Long get() = (originalBytes - output.size).coerceAtLeast(0)
    val savedPercent: Int get() = if (originalBytes <= 0) 0 else ((savedBytes * 100.0) / originalBytes).roundToInt()
}

/** Android-native still-image and animated-GIF compressor. Alpha is retained for PNG/WebP/GIF. */
internal object ImageCompressionEngine {
    private const val MAX_INPUT_BYTES = 128L * 1024 * 1024
    private const val MAX_PIXELS = 40_000_000L

    fun compress(context: Context, uri: Uri, settings: ImageCompressionSettings): ImageCompressionResult {
        val resolver = context.contentResolver
        var originalName = "image"
        var originalSize = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0 && !c.isNull(n)) originalName = c.getString(n)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (s >= 0 && !c.isNull(s)) originalSize = c.getLong(s)
            }
        }
        val input = resolver.openInputStream(uri)?.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(32 * 1024)
            var total = 0L
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                require(total <= MAX_INPUT_BYTES) { "الصورة أكبر من حد القراءة الآمن (128MB)." }
                out.write(buffer, 0, count)
            }
            if (originalSize <= 0) originalSize = total
            out.toByteArray()
        } ?: throw IOException("تعذرت قراءة الصورة المحددة.")
        require(input.isNotEmpty()) { "الملف فارغ." }
        val base = originalName.substringBeforeLast('.', originalName).ifBlank { "image" }
        val outputName = "${base}_modbridge.${settings.format.extension}"
        val isGif = input.size >= 6 && (input.copyOfRange(0, 6).toString(Charsets.US_ASCII).startsWith("GIF8"))
        val output: ByteArray
        var frames = 1
        var warning = ""

        if (settings.format == ImageOutputFormat.GIF) {
            val gifOut = ByteArrayOutputStream()
            val movie = if (isGif) Movie.decodeStream(ByteArrayInputStream(input)) else null
            val movieWidth = movie?.width() ?: 0
            val movieHeight = movie?.height() ?: 0
            if (movie != null && movieWidth > 0 && movieHeight > 0) {
                require(movieWidth.toLong() * movieHeight <= MAX_PIXELS) { "أبعاد GIF كبيرة جداً." }
                val duration = movie.duration().takeIf { it > 0 } ?: 1000
                val interval = when {
                    settings.quality >= 90 -> 40
                    settings.quality >= 75 -> 60
                    settings.quality >= 55 -> 80
                    else -> 120
                }
                frames = (duration / interval).coerceIn(1, 180)
                val width = scaled(movieWidth, settings.scalePercent)
                val height = scaled(movieHeight, settings.scalePercent)
                require(width.toLong() * height <= MAX_PIXELS) { "أبعاد الصورة الناتجة كبيرة جداً." }
                val frameDelayCentiseconds = ((duration.toDouble() / frames) / 10.0).roundToInt().coerceIn(2, 65535)
                val encoder = AnimatedGifWriter(gifOut, width, height, frameDelayCentiseconds, 0)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                repeat(frames) { index ->
                    val frame = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(frame)
                    movie.setTime((index * duration / frames).coerceAtMost(duration - 1))
                    canvas.scale(width.toFloat() / movieWidth, height.toFloat() / movieHeight)
                    movie.draw(canvas, 0f, 0f, paint)
                    if (!settings.preserveTransparency) {
                        val flat = flatten(frame, settings.backgroundColor)
                        frame.recycle()
                        encoder.writeFrame(flat)
                        flat.recycle()
                    } else {
                        encoder.writeFrame(frame)
                        frame.recycle()
                    }
                }
                encoder.finish()
                warning = "GIF متحرك: تم إخراج $frames إطاراً بلوحة ألوان محدودة 3-3-1؛ الشفافية محفوظة كقناة شفافة/معتمة وقد تقل التدرجات اللونية."
            } else {
                val bitmap = decodeStill(input, settings.scalePercent)
                val frame = if (settings.preserveTransparency) bitmap else flatten(bitmap, settings.backgroundColor)
                val encoder = AnimatedGifWriter(gifOut, frame.width, frame.height, 10, 0)
                encoder.writeFrame(frame)
                encoder.finish()
                if (frame !== bitmap) frame.recycle()
                bitmap.recycle()
                warning = if (isGif) "تعذر فك إطارات GIF المتحرك؛ تم حفظ الإطار الأول فقط. جرّب ملف GIF آخر." else "المصدر صورة ثابتة؛ تم إنشاء GIF بإطار واحد."
            }
            output = gifOut.toByteArray()
        } else {
            if (isGif) warning = "صيغة الإخراج الثابتة تحفظ الإطار الأول فقط من GIF المتحرك. اختر GIF للحفاظ على الحركة."
            var bitmap = if (isGif) decodeGifFirstFrame(input, settings.scalePercent) else decodeStill(input, settings.scalePercent)
            if (!settings.preserveTransparency || settings.format == ImageOutputFormat.JPEG) {
                val flat = flatten(bitmap, settings.backgroundColor)
                bitmap.recycle()
                bitmap = flat
            }
            val stream = ByteArrayOutputStream()
            if (settings.format == ImageOutputFormat.PNG && settings.quality < 100) {
                output = try { IndexedPngEncoder.encode(bitmap, settings.quality) } finally { bitmap.recycle() }
                warning = "تم إنشاء PNG مفهرس بألوان ودرجات شفافية مضغوطة لتقليل الحجم. الجودة الأقل قد تقلل تدرجات الألوان؛ اختر 100% لحفظ PNG الأصلي دون فقد."
            } else {
                val compressFormat = when (settings.format) {
                    ImageOutputFormat.PNG -> Bitmap.CompressFormat.PNG
                    ImageOutputFormat.WEBP -> if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                    ImageOutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
                    ImageOutputFormat.GIF -> error("unreachable")
                }
                val qualityValue = if (settings.format == ImageOutputFormat.PNG) 100 else settings.quality
                val success = bitmap.compress(compressFormat, qualityValue, stream)
                bitmap.recycle()
                check(success) { "فشل ضغط الصورة." }
                output = stream.toByteArray()
                if (settings.format == ImageOutputFormat.PNG) warning = "تم حفظ PNG دون فقد. اختر جودة أقل لتفعيل PNG المفهرس أو قلّل الأبعاد."
            }
            if (settings.format == ImageOutputFormat.WEBP && android.os.Build.VERSION.SDK_INT < 30) {
                warning = "على هذا الإصدار من Android يتم ترميز WebP بالوضع المتاح للنظام؛ قد تختلف النتيجة عن WebP الحديث."
            }
        }
        return ImageCompressionResult(originalName, outputName, originalSize, output, settings.format.mime, warning, frames)
    }

    private fun decodeStill(bytes: ByteArray, scalePercent: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "صيغة الصورة غير مدعومة أو تالفة." }
        require(bounds.outWidth.toLong() * bounds.outHeight <= MAX_PIXELS) { "أبعاد الصورة الأصلية تتجاوز 40 ميغابكسل." }
        val targetW = scaled(bounds.outWidth, scalePercent)
        val targetH = scaled(bounds.outHeight, scalePercent)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= targetW && bounds.outHeight / (sample * 2) >= targetH) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        var bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: throw IOException("تعذر فك ترميز الصورة.")
        if (bitmap.width != targetW || bitmap.height != targetH) {
            val resized = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
            if (resized !== bitmap) bitmap.recycle()
            bitmap = resized
        }
        val orientation = runCatching { ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postRotate(270f); matrix.postScale(-1f, 1f) }
        }
        if (!matrix.isIdentity) {
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (rotated !== bitmap) bitmap.recycle()
            bitmap = rotated
        }
        return bitmap
    }

    private fun decodeGifFirstFrame(bytes: ByteArray, scalePercent: Int): Bitmap {
        val movie = Movie.decodeStream(ByteArrayInputStream(bytes)) ?: throw IOException("تعذر فك GIF.")
        val w = movie.width().takeIf { it > 0 } ?: throw IOException("عرض GIF غير صالح")
        val h = movie.height().takeIf { it > 0 } ?: throw IOException("ارتفاع GIF غير صالح")
        val targetW = scaled(w, scalePercent)
        val targetH = scaled(h, scalePercent)
        require(targetW.toLong() * targetH <= MAX_PIXELS) { "أبعاد GIF كبيرة جداً." }
        val bitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(targetW.toFloat() / w, targetH.toFloat() / h)
        movie.setTime(0)
        movie.draw(canvas, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return bitmap
    }

    private fun flatten(source: Bitmap, color: Int): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        Canvas(output).apply { drawColor(color); drawBitmap(source, 0f, 0f, null) }
        return output
    }

    private fun scaled(value: Int, percent: Int): Int = max(1, (value * percent.coerceIn(10, 100) / 100f).roundToInt())
}

/** GIF89a writer with a global 3-3-1 color palette and a reserved transparent index. */
private class AnimatedGifWriter(
    private val output: ByteArrayOutputStream,
    private val width: Int,
    private val height: Int,
    private val delayCentiseconds: Int,
    private val loopCount: Int
) {
    private var finished = false

    init {
        require(width in 1..65535 && height in 1..65535)
        output.write("GIF89a".toByteArray(Charsets.US_ASCII))
        writeShort(width); writeShort(height)
        output.write(0xF7); output.write(0); output.write(0)
        for (i in 0 until 256) {
            if (i == 0) { output.write(0); output.write(0); output.write(0) }
            else {
                val v = i - 1
                val r = ((v shr 4) and 7) * 255 / 7
                val g = ((v shr 1) and 7) * 255 / 7
                val b = (v and 1) * 255
                output.write(r); output.write(g); output.write(b)
            }
        }
        output.write(0x21); output.write(0xFF); output.write(11)
        output.write("NETSCAPE2.0".toByteArray(Charsets.US_ASCII))
        output.write(3); output.write(1); writeShort(loopCount); output.write(0)
    }

    fun writeFrame(bitmap: Bitmap) {
        check(!finished)
        require(bitmap.width == width && bitmap.height == height)
        output.write(0x21); output.write(0xF9); output.write(4); output.write(0x05)
        writeShort(delayCentiseconds); output.write(0); output.write(0)
        output.write(0x2C); writeShort(0); writeShort(0); writeShort(width); writeShort(height); output.write(0)
        output.write(8)
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val indexed = ByteArray(pixels.size)
        for (i in pixels.indices) {
            val c = pixels[i]
            indexed[i] = if (Color.alpha(c) < 96) 0 else (1 + ((Color.red(c) shr 5) shl 4) + ((Color.green(c) shr 5) shl 1) + (Color.blue(c) shr 7)).toByte()
        }
        writeSubBlocks(lzw(indexed))
    }

    fun finish() { if (!finished) { output.write(0x3B); finished = true } }

    private fun lzw(pixels: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        var accumulator = 0
        var bitCount = 0
        var codeSize = 9
        var nextCode = 258
        val clearCode = 256
        val endCode = 257
        val dictionary = HashMap<Int, Int>(4096)
        fun emit(code: Int) {
            accumulator = accumulator or (code shl bitCount)
            bitCount += codeSize
            while (bitCount >= 8) {
                out.write(accumulator and 0xFF)
                accumulator = accumulator ushr 8
                bitCount -= 8
            }
        }
        emit(clearCode)
        if (pixels.isNotEmpty()) {
            var prefix = pixels[0].toInt() and 0xFF
            for (i in 1 until pixels.size) {
                val value = pixels[i].toInt() and 0xFF
                val key = (prefix shl 8) or value
                val found = dictionary[key]
                if (found != null) {
                    prefix = found
                } else {
                    emit(prefix)
                    if (nextCode < 4096) {
                        dictionary[key] = nextCode++
                        if (nextCode > (1 shl codeSize) && codeSize < 12) codeSize++
                    } else {
                        emit(clearCode)
                        dictionary.clear()
                        codeSize = 9
                        nextCode = 258
                    }
                    prefix = value
                }
            }
            emit(prefix)
        }
        emit(endCode)
        if (bitCount > 0) out.write(accumulator and 0xFF)
        return out.toByteArray()
    }

    private fun writeSubBlocks(bytes: ByteArray) {
        var index = 0
        while (index < bytes.size) {
            val count = minOf(255, bytes.size - index)
            output.write(count)
            output.write(bytes, index, count)
            index += count
        }
        output.write(0)
    }

    private fun writeShort(value: Int) { output.write(value and 0xFF); output.write((value shr 8) and 0xFF) }
}


/** Writes indexed PNG directly. The palette includes quantized alpha, so transparent edges survive. */
private object IndexedPngEncoder {
    private val signature = byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10)

    fun encode(bitmap: Bitmap, quality: Int): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        require(width > 0 && height > 0 && width.toLong() * height <= 40_000_000L)
        val fine = quality >= 60
        val palette = ByteArray(256 * 3)
        val alpha = ByteArray(256)
        for (idx in 0 until 256) {
            val r: Int; val g: Int; val b: Int; val a: Int
            if (fine) {
                val aQ = (idx ushr 6) and 3
                val rQ = (idx ushr 4) and 3
                val gQ = (idx ushr 2) and 3
                val bQ = idx and 3
                r = rQ * 85; g = gQ * 85; b = bQ * 85; a = aQ * 85
            } else {
                val aQ = (idx ushr 3) and 31
                val rQ = (idx ushr 2) and 1
                val gQ = (idx ushr 1) and 1
                val bQ = idx and 1
                r = rQ * 255; g = gQ * 255; b = bQ * 255; a = aQ * 255 / 31
            }
            palette[idx * 3] = r.toByte(); palette[idx * 3 + 1] = g.toByte(); palette[idx * 3 + 2] = b.toByte()
            alpha[idx] = a.toByte()
        }
        val raw = ByteArrayOutputStream()
        val row = IntArray(width)
        for (y in 0 until height) {
            raw.write(0) // PNG filter: None
            bitmap.getPixels(row, 0, width, 0, y, width, 1)
            for (pixel in row) {
                val a = Color.alpha(pixel); val r = Color.red(pixel); val g = Color.green(pixel); val b = Color.blue(pixel)
                val index = if (fine) {
                    ((a * 3 / 255) shl 6) or ((r ushr 6) shl 4) or ((g ushr 6) shl 2) or (b ushr 6)
                } else {
                    (((a * 31 / 255) shl 3) or ((r ushr 7) shl 2) or ((g ushr 7) shl 1) or (b ushr 7))
                }
                raw.write(index)
            }
        }
        val compressed = ByteArrayOutputStream()
        DeflaterOutputStream(compressed, Deflater(Deflater.BEST_COMPRESSION)).use { it.write(raw.toByteArray()) }
        val out = ByteArrayOutputStream()
        out.write(signature)
        val ihdr = ByteArrayOutputStream().apply {
            val d = DataOutputStream(this); d.writeInt(width); d.writeInt(height); d.writeByte(8); d.writeByte(3); d.writeByte(0); d.writeByte(0); d.writeByte(0)
        }.toByteArray()
        chunk(out, "IHDR", ihdr)
        chunk(out, "PLTE", palette)
        chunk(out, "tRNS", alpha)
        chunk(out, "IDAT", compressed.toByteArray())
        chunk(out, "IEND", byteArrayOf())
        return out.toByteArray()
    }

    private fun chunk(out: ByteArrayOutputStream, type: String, data: ByteArray) {
        val name = type.toByteArray(Charsets.US_ASCII)
        val d = DataOutputStream(out)
        d.writeInt(data.size); d.write(name); d.write(data)
        val crc = CRC32(); crc.update(name); crc.update(data); d.writeInt(crc.value.toInt())
    }
}
