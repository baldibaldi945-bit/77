package com.modbridge.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

private fun shaderFileName(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
}.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "shader.frag"

private val shaderExt = listOf(".frag", ".glsl", ".fs", ".txt")

/** Reads shader sources from picked files; a ZIP (another mod) contributes every *.frag inside it. */
private fun readShaderSources(context: Context, uris: List<Uri>): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    for (u in uris) {
        val name = shaderFileName(context, u)
        val bytes = context.contentResolver.openInputStream(u)?.use { it.readBytes() } ?: continue
        if (name.endsWith(".zip", true)) {
            ZipInputStream(bytes.inputStream()).use { z ->
                while (out.size < 40) {
                    val e = z.nextEntry ?: break
                    if (!e.isDirectory && e.name.endsWith(".frag", true) && !e.name.contains("..")) {
                        val buf = ByteArrayOutputStream(); val tmp = ByteArray(16 * 1024); var total = 0
                        while (true) { val n = z.read(tmp); if (n < 0) break; total += n; if (total > 512 * 1024) break; buf.write(tmp, 0, n) }
                        if (total <= 512 * 1024) out.add(e.name.substringAfterLast('/') to buf.toString(Charsets.UTF_8.name()))
                    }
                    z.closeEntry()
                }
            }
        } else if (shaderExt.any { name.endsWith(it, true) } && bytes.size <= 512 * 1024) {
            out.add(name to bytes.toString(Charsets.UTF_8).trimStart('\uFEFF'))
        }
    }
    return out
}

@Composable
private fun SliderRow(label: String, value: Float, min: Float, max: Float, onValue: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text("$label: ${fmtNum(Math.round(value * 100f) / 100f)}", fontSize = 11.sp)
        Slider(value = value.coerceIn(min, max), onValueChange = onValue, valueRange = min..max)
    }
}

@Composable
private fun NumRow(label: String, value: Float, onValue: (Float) -> Unit) {
    var text by remember(label) { mutableStateOf(fmtNum(value)) }
    androidx.compose.material3.OutlinedTextField(
        value = text,
        onValueChange = { t -> text = t; t.toFloatOrNull()?.let { v -> if (v.isFinite()) onValue(v) } },
        label = { Text(label, fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

/**
 * Shaders tab. [testMode]: 0 = off, 1 = test all added shaders, 2 = test only the selected one.
 * Everything here edits [StageState.shaders]; the mod gets the .frag files + Lua only if shaders exist at save time.
 */
@Composable
internal fun ShaderPanel(
    st: StageState,
    session: StageSession,
    selId: Int,
    onSel: (Int) -> Unit,
    testMode: Int,
    onTest: (Int) -> Unit,
    busy: Boolean,
    onChange: () -> Unit,
    onStatus: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showPresets by remember { mutableStateOf(false) }
    val sel = st.shaders.firstOrNull { it.id == selId }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { readShaderSources(context, uris) } }
            r.onSuccess { files ->
                if (files.isEmpty()) { onStatus("لم أجد ملفات شادر (.frag / .glsl) في الاختيار."); return@onSuccess }
                var ok = 0; val msgs = ArrayList<String>(); var last: ShaderInst? = null
                for ((name, text) in files) {
                    runCatching { ShaderLib.importSource(st, session, name, text) }
                        .onSuccess { st.shaders.add(it.inst); last = it.inst; ok++; it.warning?.let { w -> msgs.add("${it.inst.title}: $w") } }
                        .onFailure { msgs.add("$name: ${it.message}") }
                }
                last?.let { onSel(it.id) }
                onChange()
                onStatus("تم استحضار $ok شادر" + (if (msgs.isNotEmpty()) " • " + msgs.joinToString(" | ") else "") + " — جرّبه بزر 🧪")
            }.onFailure { onStatus("تعذر قراءة الملفات: ${it.message}") }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { showPresets = !showPresets }, enabled = !busy) { Text("➕ إضافة شادر", fontSize = 12.sp) }
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("📥 من ملفات / مود آخر", fontSize = 11.sp) }
        }
        if (showPresets) {
            Text("اختر شادراً جاهزاً (يمكن إضافة نفس الشادر أكثر من مرة):", fontSize = 11.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ShaderLib.presets.forEach { p ->
                    FilterChip(selected = false, onClick = {
                        ShaderLib.create(st, p.key)?.let { st.shaders.add(it); onSel(it.id); onChange(); onStatus("أضيف ${p.title}") }
                        showPresets = false
                    }, label = { Text(p.title, fontSize = 10.sp) })
                }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = testMode == 1, enabled = st.shaders.isNotEmpty(),
                onClick = { onTest(if (testMode == 1) 0 else 1) }, label = { Text("🧪 تجربة الكل", fontSize = 10.sp) })
            FilterChip(selected = testMode == 2, enabled = sel != null,
                onClick = { onTest(if (testMode == 2) 0 else 2) }, label = { Text("🧪 تجربة المحدد فقط", fontSize = 10.sp) })
            if (testMode != 0) FilterChip(selected = false, onClick = { onTest(-1) }, label = { Text("🔄 لقطة جديدة", fontSize = 10.sp) })
            if (testMode != 0) FilterChip(selected = false, onClick = { onTest(0) }, label = { Text("إيقاف التجربة", fontSize = 10.sp) })
        }
        if (st.shaders.isEmpty()) {
            Text("لا توجد شادرات. لن يُضاف أي شادر أو ملف للمود عند الحفظ إلا إذا أضفت واحداً هنا.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        st.shaders.forEach { s ->
            Row(Modifier.fillMaxWidth().clickable { onSel(s.id) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (s.id == selId) "▶ " else "") + (if (s.imported) "📄 " else "✨ ") + s.title + (if (!s.enabled) " (متوقف)" else ""),
                    fontSize = 12.sp, fontWeight = if (s.id == selId) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.weight(1f)
                )
                Switch(checked = s.enabled, onCheckedChange = { s.enabled = it; onChange() })
            }
        }
        if (sel != null) {
            val preset = if (sel.imported) null else ShaderLib.preset(sel.key)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(sel.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("يُطبّق على:", fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ShaderLib.cameraNames.forEachIndexed { i, n ->
                            FilterChip(selected = sel.camera == i, onClick = { sel.camera = i; onChange() }, label = { Text(n, fontSize = 10.sp) })
                        }
                    }
                    if (sel.camera != 0) Text("تنبيه: الواجهة HUD تحمل الهلث بار والأيقونات والنوتات، فسيتأثر بها الشادر أيضاً.", fontSize = 10.sp, color = MaterialTheme.colorScheme.error)
                    if (!sel.imported) {
                        SliderRow("القوة", sel.strength, 0f, 2f) { sel.strength = it; onChange() }
                        SliderRow("الثبات (1 = ثابت تماماً، 0 = يتحرك/ينبض)", sel.stability, 0f, 1f) { sel.stability = it; onChange() }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("التخفيف / التثقيل", fontSize = 11.sp, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { sel.weight = (sel.weight * 0.8f).coerceAtLeast(0.1f); onChange() }) { Text("خفّف", fontSize = 10.sp) }
                            OutlinedButton(onClick = { sel.weight = (sel.weight * 1.25f).coerceAtMost(4f); onChange() }) { Text("ثقّل", fontSize = 10.sp) }
                        }
                        SliderRow("الوزن", sel.weight, 0.1f, 4f) { sel.weight = it; onChange() }
                        Text("الشكل (منطقة التأثير)", fontSize = 11.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ShaderLib.shapeNames.forEachIndexed { i, n ->
                                FilterChip(selected = sel.shape == i, onClick = { sel.shape = i; onChange() }, label = { Text(n, fontSize = 10.sp) })
                            }
                        }
                        if (sel.shape != 0) {
                            SliderRow("حجم المنطقة", sel.size, 0.05f, 2f) { sel.size = it; onChange() }
                            SliderRow("المكان X", sel.cx, 0f, 1f) { sel.cx = it; onChange() }
                            SliderRow("المكان Y", sel.cy, 0f, 1f) { sel.cy = it; onChange() }
                        } else if (sel.key == "vignette") {
                            SliderRow("مركز التغميق X", sel.cx, 0f, 1f) { sel.cx = it; onChange() }
                            SliderRow("مركز التغميق Y", sel.cy, 0f, 1f) { sel.cy = it; onChange() }
                        }
                        SliderRow("الاتجاه (درجة)", sel.angle, 0f, 360f) { sel.angle = it; onChange() }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { sel.angle = (sel.angle + 180f) % 360f; onChange() }) { Text("🔄 عكس الاتجاه", fontSize = 10.sp) }
                            OutlinedButton(onClick = { sel.angle = (180f - sel.angle + 360f) % 360f; onChange() }) { Text("↔ قلب أفقي", fontSize = 10.sp) }
                            OutlinedButton(onClick = { sel.angle = (360f - sel.angle) % 360f; onChange() }) { Text("↕ قلب رأسي", fontSize = 10.sp) }
                            OutlinedButton(onClick = { sel.angle = (sel.angle + 90f) % 360f; onChange() }) { Text("⟳ 90°", fontSize = 10.sp) }
                        }
                        preset?.params?.forEach { p ->
                            SliderRow(p.label, sel.extras[p.id] ?: p.def, p.min, p.max) { sel.extras[p.id] = it; onChange() }
                        }
                    } else {
                        Text(
                            if (sel.extras.isEmpty()) "هذا الشادر لا يعرّف متغيرات float قابلة للتعديل." else "متغيرات الشادر (uniform float):",
                            fontSize = 11.sp
                        )
                        sel.extras.keys.toList().forEach { k -> NumRow(k, sel.extras[k] ?: 0f) { sel.extras[k] = it; onChange() } }
                        if (sel.timeUniform.isNotEmpty()) Text("الوقت يُرسل تلقائياً إلى ${sel.timeUniform}.", fontSize = 10.sp)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (preset != null) OutlinedButton(onClick = { ShaderLib.applyDefaults(sel, preset); onChange() }) { Text("↩ الافتراضي", fontSize = 10.sp) }
                        OutlinedButton(onClick = { val d = ShaderLib.duplicate(st, sel); st.shaders.add(d); onSel(d.id); onChange() }) { Text("⧉ نسخ", fontSize = 10.sp) }
                        OutlinedButton(onClick = {
                            ShaderLib.remove(st, session, sel); onSel(st.shaders.lastOrNull()?.id ?: 0)
                            if (st.shaders.isEmpty()) onTest(0)
                            onChange(); onStatus("حُذف الشادر ${sel.title}")
                        }) { Text("🗑 إزالة", fontSize = 10.sp) }
                    }
                }
            }
        }
        Text(
            "التجربة تشغّل نفس كود GLSL الذي سيعمل في اللعبة فوق لقطة من المرحلة. الشادرات المضافة فقط تُكتب في المود عند الحفظ: shaders/*.frag + scripts/ModBridge_<المرحلة>.lua.",
            fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
