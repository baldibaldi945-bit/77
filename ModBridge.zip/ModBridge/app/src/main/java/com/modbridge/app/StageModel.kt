package com.modbridge.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Movie
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

internal enum class ObjKind { SPRITE, ANIMATED, GIF }

internal class Pt(var x: Float, var y: Float)

internal class StageObj(
    val id: String,
    var tag: String,
    var kind: ObjKind,
    var image: String,
    var x: Float,
    var y: Float
) {
    var scaleX = 1f
    var scaleY = 1f
    var scrollX = 1f
    var scrollY = 1f
    var alpha = 1f
    var angle = 0f
    var flipX = false
    var flipY = false
    var front = false
    var sendToBack = false
    var isNew = false          // created by this editor (fully regenerated in the override script)
    var removed = false
    var gifBytes: ByteArray? = null
    var fps = 24
    var prefix = ""
    var downscale = 1f         // atlas frames were shrunk by this factor (<= 1)
    var replaces = ""          // tag of the object this one replaces (keeps its draw order)
    var label = ""
    // values read from the original stage Lua (used to emit only real changes)
    var baseX = x
    var baseY = y
    var baseSx = 1f
    var baseSy = 1f
    var baseScrollX = 1f
    var baseScrollY = 1f
    var baseAlpha = 1f
    var baseAngle = 0f
}

internal class StageState(val name: String) {
    var defaultZoom = 0.9f
    var cameraSpeed = 1f
    var hideGf = false
    val bf = Pt(770f, 100f)
    val dad = Pt(100f, 100f)
    val gf = Pt(400f, 130f)
    val camBf = Pt(0f, 0f)
    val camDad = Pt(0f, 0f)
    val camGf = Pt(0f, 0f)
    var bfChar = "bf"
    var dadChar = "dad"
    var gfChar = "gf"
    val objects = ArrayList<StageObj>()
    var nextId = 1
    var unparsedLuaCalls = 0
    var healthBarPng: ByteArray? = null
    val shaders = ArrayList<ShaderInst>()
    var nextShaderId = 1

    companion object {
        fun load(s: StageSession, name: String): StageState {
            val st = StageState(name)
            val json = s.readText("stages/$name.json")?.let { runCatching { JSONObject(it) }.getOrNull() }
            if (json != null) {
                st.defaultZoom = json.optDouble("defaultZoom", 0.9).toFloat()
                st.cameraSpeed = json.optDouble("camera_speed", 1.0).toFloat()
                st.hideGf = json.optBoolean("hide_girlfriend", false)
                fun pt(key: String, p: Pt) {
                    val a = json.optJSONArray(key) ?: return
                    p.x = a.optDouble(0, p.x.toDouble()).toFloat()
                    p.y = a.optDouble(1, p.y.toDouble()).toFloat()
                }
                pt("boyfriend", st.bf); pt("girlfriend", st.gf); pt("opponent", st.dad)
                pt("camera_boyfriend", st.camBf); pt("camera_girlfriend", st.camGf); pt("camera_opponent", st.camDad)
            }
            val lua = s.readText("stages/$name.lua")
            if (lua != null) StageLua.parse(lua, st)
            val mb = s.readText("scripts/ModBridge_$name.lua")
            if (mb != null) StageLua.applyState(st, mb)
            val chart = s.charts().firstOrNull { it.stage == name }
            if (chart != null) {
                if (chart.player1.isNotBlank()) st.bfChar = chart.player1
                if (chart.player2.isNotBlank()) st.dadChar = chart.player2
                if (chart.gf.isNotBlank()) st.gfChar = chart.gf
            }
            return st
        }
    }
}

internal fun fmtNum(f: Float): String {
    if (f == f.toLong().toFloat()) return f.toLong().toString()
    return String.format(Locale.US, "%.4f", f.toDouble()).trimEnd('0').trimEnd('.')
}

private fun jd(f: Float): Double = f.toString().toDouble()

internal object StageLua {
    private const val N = "(-?\\d*\\.?\\d+)"
    private val make = Regex("make(Animated)?LuaSprite\\s*\\(\\s*['\"]([^'\"]+)['\"]\\s*,\\s*['\"]([^'\"]*)['\"]\\s*,\\s*$N\\s*,\\s*$N\\s*\\)")
    private val anyMake = Regex("make(Animated)?LuaSprite\\s*\\(")
    private const val STATE_BEGIN = "-- MODBRIDGE_STATE_BEGIN"
    private const val STATE_END = "-- MODBRIDGE_STATE_END"

    fun parse(lua: String, st: StageState) {
        val matches = make.findAll(lua).toList()
        val total = anyMake.findAll(lua).count()
        st.unparsedLuaCalls = max(0, total - matches.size)
        for (m in matches) {
            val animated = m.groupValues[1].isNotEmpty()
            val tag = m.groupValues[2]
            val image = m.groupValues[3]
            if (image.isBlank()) continue
            val tg = Regex.escape(tag)
            val add = Regex("addLuaSprite\\s*\\(\\s*['\"]$tg['\"]\\s*(?:,\\s*(true|false))?\\s*\\)").find(lua) ?: continue
            val o = StageObj("s_$tag", tag, if (animated) ObjKind.ANIMATED else ObjKind.SPRITE, image,
                m.groupValues[4].toFloatOrNull() ?: 0f, m.groupValues[5].toFloatOrNull() ?: 0f)
            o.baseX = o.x; o.baseY = o.y
            o.front = add.groupValues[1] == "true"
            Regex("setScrollFactor\\s*\\(\\s*['\"]$tg['\"]\\s*,\\s*$N\\s*,\\s*$N").find(lua)?.let {
                o.scrollX = it.groupValues[1].toFloatOrNull() ?: 1f; o.scrollY = it.groupValues[2].toFloatOrNull() ?: 1f
            }
            Regex("scaleObject\\s*\\(\\s*['\"]$tg['\"]\\s*,\\s*$N\\s*,\\s*$N").find(lua)?.let {
                o.scaleX = it.groupValues[1].toFloatOrNull() ?: 1f; o.scaleY = it.groupValues[2].toFloatOrNull() ?: 1f
            }
            Regex("setProperty\\s*\\(\\s*['\"]$tg\\.alpha['\"]\\s*,\\s*$N").find(lua)?.let {
                o.alpha = it.groupValues[1].toFloatOrNull() ?: 1f
            }
            Regex("setProperty\\s*\\(\\s*['\"]$tg\\.angle['\"]\\s*,\\s*$N").find(lua)?.let {
                o.angle = it.groupValues[1].toFloatOrNull() ?: 0f
            }
            o.baseSx = o.scaleX; o.baseSy = o.scaleY; o.baseScrollX = o.scrollX; o.baseScrollY = o.scrollY
            o.baseAlpha = o.alpha; o.baseAngle = o.angle
            if (st.objects.none { it.tag == tag }) st.objects.add(o)
        }
    }

    fun applyState(st: StageState, script: String) {
        val b = script.indexOf(STATE_BEGIN)
        val e = script.indexOf(STATE_END)
        if (b < 0 || e < b) return
        val line = script.substring(b + STATE_BEGIN.length, e).trim().removePrefix("--").trim()
        val root = runCatching { JSONObject(line) }.getOrNull() ?: return
        ShaderLib.fromJson(root.optJSONArray("shaders"), st)
        val arr = root.optJSONArray("objects") ?: return
        for (i in 0 until arr.length()) {
            val j = arr.optJSONObject(i) ?: continue
            val tag = j.optString("tag")
            if (tag.isEmpty()) continue
            val isNew = j.optBoolean("new", false)
            val existing = st.objects.firstOrNull { it.tag == tag }
            val o: StageObj = if (isNew) {
                val kind = runCatching { ObjKind.valueOf(j.optString("kind", "SPRITE")) }.getOrDefault(ObjKind.SPRITE)
                StageObj("n_$tag", tag, kind, j.optString("image"), 0f, 0f).also { it.isNew = true; st.objects.add(it) }
            } else existing ?: continue
            o.x = j.optDouble("x", o.x.toDouble()).toFloat(); o.y = j.optDouble("y", o.y.toDouble()).toFloat()
            o.scaleX = j.optDouble("sx", o.scaleX.toDouble()).toFloat(); o.scaleY = j.optDouble("sy", o.scaleY.toDouble()).toFloat()
            o.scrollX = j.optDouble("cx", o.scrollX.toDouble()).toFloat(); o.scrollY = j.optDouble("cy", o.scrollY.toDouble()).toFloat()
            o.alpha = j.optDouble("a", o.alpha.toDouble()).toFloat(); o.angle = j.optDouble("r", o.angle.toDouble()).toFloat()
            o.flipX = j.optBoolean("fx", false); o.flipY = j.optBoolean("fy", false)
            o.front = j.optBoolean("front", o.front); o.removed = j.optBoolean("removed", false)
            o.sendToBack = j.optBoolean("back", false)
            o.fps = j.optInt("fps", 24); o.prefix = j.optString("prefix", ""); o.downscale = j.optDouble("down", 1.0).toFloat()
            o.replaces = j.optString("replaces", "")
            if (isNew) {
                val n = tag.removePrefix("mb_").toIntOrNull()
                if (n != null) st.nextId = max(st.nextId, n + 1)
            }
        }
    }

    private fun changed(o: StageObj): Boolean =
        o.removed || o.isNew || o.x != o.baseX || o.y != o.baseY || o.scaleX != o.baseSx || o.scaleY != o.baseSy ||
            o.scrollX != o.baseScrollX || o.scrollY != o.baseScrollY || o.alpha != o.baseAlpha || o.angle != o.baseAngle ||
            o.flipX || o.flipY

    /** Generates scripts/ModBridge_<stage>.lua, or null when there is nothing to override. */
    fun generate(st: StageState): String? {
        val list = st.objects.filter { changed(it) && !(it.isNew && it.removed) }
        if (list.isEmpty() && st.shaders.isEmpty()) return null
        val state = JSONArray()
        for (o in list) {
            val j = JSONObject()
            j.put("tag", o.tag); j.put("new", o.isNew); j.put("kind", o.kind.name); j.put("image", o.image)
            j.put("x", jd(o.x)); j.put("y", jd(o.y)); j.put("sx", jd(o.scaleX)); j.put("sy", jd(o.scaleY))
            j.put("cx", jd(o.scrollX)); j.put("cy", jd(o.scrollY)); j.put("a", jd(o.alpha)); j.put("r", jd(o.angle))
            j.put("fx", o.flipX); j.put("fy", o.flipY); j.put("front", o.front); j.put("removed", o.removed)
            j.put("back", o.sendToBack); j.put("fps", o.fps); j.put("prefix", o.prefix); j.put("down", jd(o.downscale))
            j.put("replaces", o.replaces)
            state.put(j)
        }
        val root = JSONObject().put("objects", state).put("shaders", ShaderLib.toJson(st.shaders))
        val sb = StringBuilder()
        sb.append(STATE_BEGIN).append('\n').append("-- ").append(root.toString()).append('\n').append(STATE_END).append('\n')
        sb.append("-- Generated by ModBridge stage editor. Original stage files are untouched; this script only overrides them.\n")
        sb.append("local MB_STAGE = '").append(st.name.replace("'", "\\'")).append("'\n\n")
        sb.append("function onCreatePost()\n    if curStage ~= MB_STAGE then return end\n")
        // 1) new / replacement objects first so draw order can be copied from the replaced object
        for (o in list) {
            if (!o.isNew || o.removed) continue
            val animated = o.kind != ObjKind.SPRITE
            val img = o.image
            if (animated) sb.append("    makeAnimatedLuaSprite('${o.tag}', '$img', ${fmtNum(o.x)}, ${fmtNum(o.y)})\n")
            else sb.append("    makeLuaSprite('${o.tag}', '$img', ${fmtNum(o.x)}, ${fmtNum(o.y)})\n")
            if (animated) sb.append("    addAnimationByPrefix('${o.tag}', 'loop', '${o.prefix}', ${o.fps}, true)\n")
            sb.append("    setScrollFactor('${o.tag}', ${fmtNum(o.scrollX)}, ${fmtNum(o.scrollY)})\n")
            val sx = if (o.downscale > 0f) o.scaleX / o.downscale else o.scaleX
            val sy = if (o.downscale > 0f) o.scaleY / o.downscale else o.scaleY
            if (sx != 1f || sy != 1f) sb.append("    scaleObject('${o.tag}', ${fmtNum(sx)}, ${fmtNum(sy)})\n")
            if (o.alpha != 1f) sb.append("    setProperty('${o.tag}.alpha', ${fmtNum(o.alpha)})\n")
            if (o.angle != 0f) sb.append("    setProperty('${o.tag}.angle', ${fmtNum(o.angle)})\n")
            if (o.flipX) sb.append("    setProperty('${o.tag}.flipX', true)\n")
            if (o.flipY) sb.append("    setProperty('${o.tag}.flipY', true)\n")
            sb.append("    addLuaSprite('${o.tag}', ${o.front})\n")
            if (o.replaces.isNotEmpty()) sb.append("    setObjectOrder('${o.tag}', getObjectOrder('${o.replaces}'))\n")
            else if (o.sendToBack && !o.front) sb.append("    setObjectOrder('${o.tag}', 0)\n")
            if (animated) sb.append("    objectPlayAnimation('${o.tag}', 'loop', true)\n")
        }
        // 2) changes to sprites that already existed in the stage script
        for (o in list) {
            if (o.isNew || o.removed) continue
            if (o.x != o.baseX) sb.append("    setProperty('${o.tag}.x', ${fmtNum(o.x)})\n")
            if (o.y != o.baseY) sb.append("    setProperty('${o.tag}.y', ${fmtNum(o.y)})\n")
            if (o.scrollX != o.baseScrollX || o.scrollY != o.baseScrollY) sb.append("    setScrollFactor('${o.tag}', ${fmtNum(o.scrollX)}, ${fmtNum(o.scrollY)})\n")
            if (o.scaleX != o.baseSx || o.scaleY != o.baseSy) sb.append("    scaleObject('${o.tag}', ${fmtNum(o.scaleX)}, ${fmtNum(o.scaleY)})\n")
            if (o.alpha != o.baseAlpha) sb.append("    setProperty('${o.tag}.alpha', ${fmtNum(o.alpha)})\n")
            if (o.angle != o.baseAngle) sb.append("    setProperty('${o.tag}.angle', ${fmtNum(o.angle)})\n")
            if (o.flipX) sb.append("    setProperty('${o.tag}.flipX', true)\n")
            if (o.flipY) sb.append("    setProperty('${o.tag}.flipY', true)\n")
        }
        // 3) removals last (replacements already copied the order)
        for (o in list) if (o.removed && !o.isNew) sb.append("    removeLuaSprite('${o.tag}', true)\n")
        // 4) shaders (camera filters; the health bar and icons are never touched)
        sb.append(ShaderLib.luaCreate(st))
        sb.append("end\n")
        sb.append(ShaderLib.luaUpdate(st))
        return sb.toString()
    }
}

internal class GifFrames(val frames: List<Bitmap>, val origW: Int, val origH: Int, val fps: Int, val downscale: Float)

internal object GifDecoder {
    fun isGif(b: ByteArray): Boolean = b.size > 6 && b[0] == 'G'.code.toByte() && b[1] == 'I'.code.toByte() && b[2] == 'F'.code.toByte()

    fun size(b: ByteArray): Pair<Int, Int>? {
        val m = Movie.decodeByteArray(b, 0, b.size) ?: return null
        return if (m.width() > 0 && m.height() > 0) Pair(m.width(), m.height()) else null
    }

    fun decode(bytes: ByteArray, maxFrames: Int, maxSheet: Int, maxBytes: Long): GifFrames? {
        val movie = Movie.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val w = movie.width(); val h = movie.height()
        if (w <= 0 || h <= 0) return null
        val duration = if (movie.duration() > 0) movie.duration() else 100
        var count = min(maxFrames, max(1, duration / 40))
        var scale = 1f
        fun fit() {
            val cols = ceil(sqrt(count.toDouble())).toInt()
            val rows = ceil(count / cols.toDouble()).toInt()
            val sw = cols * w * scale; val sh = rows * h * scale
            if (sw > maxSheet || sh > maxSheet) scale *= min(maxSheet / sw, maxSheet / sh)
            val bytesNeeded = count.toLong() * (w * scale).toLong() * (h * scale).toLong() * 4L
            if (bytesNeeded > maxBytes) scale *= sqrt(maxBytes.toDouble() / bytesNeeded).toFloat()
        }
        fit()
        val fw = max(1, (w * scale).roundToInt()); val fh = max(1, (h * scale).roundToInt())
        val frames = ArrayList<Bitmap>()
        for (i in 0 until count) {
            val bmp = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.save(); c.scale(fw / w.toFloat(), fh / h.toFloat())
            movie.setTime((i.toLong() * duration / count).toInt())
            movie.draw(c, 0f, 0f)
            c.restore()
            frames.add(bmp)
        }
        val fps = (count * 1000f / duration).roundToInt().coerceIn(1, 60)
        return GifFrames(frames, w, h, fps, fw / w.toFloat())
    }

    /** Builds a Sparrow atlas (PNG + XML) from GIF frames. */
    fun buildAtlas(g: GifFrames, name: String): Pair<ByteArray, String> {
        val n = g.frames.size
        val cols = ceil(sqrt(n.toDouble())).toInt()
        val rows = ceil(n / cols.toDouble()).toInt()
        val fw = g.frames[0].width; val fh = g.frames[0].height
        val sheet = Bitmap.createBitmap(cols * fw, rows * fh, Bitmap.Config.ARGB_8888)
        val c = Canvas(sheet)
        val xml = StringBuilder()
        xml.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<TextureAtlas imagePath=\"").append(name).append(".png\">\n")
        for (i in 0 until n) {
            val x = (i % cols) * fw; val y = (i / cols) * fh
            c.drawBitmap(g.frames[i], x.toFloat(), y.toFloat(), null)
            xml.append("    <SubTexture name=\"").append(name).append(String.format(Locale.US, "%04d", i))
                .append("\" x=\"").append(x).append("\" y=\"").append(y).append("\" width=\"").append(fw).append("\" height=\"").append(fh)
                .append("\" frameX=\"0\" frameY=\"0\" frameWidth=\"").append(fw).append("\" frameHeight=\"").append(fh).append("\"/>\n")
        }
        xml.append("</TextureAtlas>\n")
        val out = ByteArrayOutputStream()
        sheet.compress(Bitmap.CompressFormat.PNG, 100, out)
        sheet.recycle()
        return Pair(out.toByteArray(), xml.toString())
    }
}

/** Health bar frame presets. Psych draws the fill inset by 4px inside images/healthBar.png (601x19). */
internal object HealthBarStyles {
    val names = listOf("Classic", "Capsule", "Slanted", "Notched", "Outlined")
    private const val W = 601
    private const val H = 19

    fun render(style: Int): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFF000000.toInt()
        val w = W.toFloat(); val h = H.toFloat()
        when (style) {
            0 -> c.drawRoundRect(RectF(0f, 0f, w, h), 5f, 5f, p)
            1 -> c.drawRoundRect(RectF(0f, 0f, w, h), h / 2f, h / 2f, p)
            2 -> {
                val s = 4f
                val path = Path()
                path.moveTo(s, 0f); path.lineTo(w, 0f); path.lineTo(w - s, h); path.lineTo(0f, h); path.close()
                c.drawPath(path, p)
            }
            3 -> {
                val s = 5f
                val path = Path()
                path.moveTo(s, 0f); path.lineTo(w - s, 0f); path.lineTo(w, s); path.lineTo(w, h - s)
                path.lineTo(w - s, h); path.lineTo(s, h); path.lineTo(0f, h - s); path.lineTo(0f, s); path.close()
                c.drawPath(path, p)
            }
            else -> {
                c.drawRoundRect(RectF(0f, 0f, w, h), 5f, 5f, p)
                val line = Paint(Paint.ANTI_ALIAS_FLAG)
                line.color = 0xFFFFFFFF.toInt(); line.style = Paint.Style.STROKE; line.strokeWidth = 1f
                c.drawRoundRect(RectF(1.5f, 1.5f, w - 1.5f, h - 1.5f), 4f, 4f, line)
            }
        }
        return bmp
    }

    fun toPng(b: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }

    /** Preview with fill colours, the way the game composes it (fill rect inset by 4px). */
    fun preview(frame: Bitmap, opponent: Int, player: Int, percent: Float): Bitmap {
        val out = Bitmap.createBitmap(frame.width, frame.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(frame, 0f, 0f, null)
        val p = Paint()
        val inner = RectF(4f, 4f, frame.width - 4f, frame.height - 4f)
        val split = inner.right - (inner.width() * percent)
        p.color = opponent; c.drawRect(inner.left, inner.top, split, inner.bottom, p)
        p.color = player; c.drawRect(split, inner.top, inner.right, inner.bottom, p)
        return out
    }
}

internal class EditPlan {
    var flips: Map<String, Set<Int>> = emptyMap()
    var swapMode = 0
    var applyCharacters = true
    var skinsForAllCharts = false
    var arrowSkin: String? = null
    var splashSkin: String? = null
}

internal object StageSaver {
    fun save(session: StageSession, st: StageState, plan: EditPlan, out: File): String {
        val notes = ArrayList<String>()
        // 1) stage JSON (existing fields are preserved)
        val jsonPath = "stages/${st.name}.json"
        val json = session.readText(jsonPath)?.let { runCatching { JSONObject(it) }.getOrNull() } ?: JSONObject()
        json.put("defaultZoom", jd(st.defaultZoom)); json.put("camera_speed", jd(st.cameraSpeed))
        json.put("hide_girlfriend", st.hideGf)
        fun pair(key: String, p: Pt) { json.put(key, JSONArray().put(jd(p.x)).put(jd(p.y))) }
        pair("boyfriend", st.bf); pair("girlfriend", st.gf); pair("opponent", st.dad)
        pair("camera_boyfriend", st.camBf); pair("camera_girlfriend", st.camGf); pair("camera_opponent", st.camDad)
        if (!json.has("directory")) json.put("directory", "")
        if (!json.has("isPixelStage")) json.put("isPixelStage", false)
        session.put(jsonPath, json.toString(2).toByteArray(Charsets.UTF_8))

        // 2) GIF objects become Sparrow atlases (frames of the GIF)
        for (o in st.objects) {
            val gif = o.gifBytes
            if (o.isNew && !o.removed && o.kind == ObjKind.GIF && gif != null) {
                val g = GifDecoder.decode(gif, 80, 4096, 96L * 1024 * 1024)
                if (g == null) { notes.add("تعذر تحويل GIF للعنصر ${o.tag}"); o.removed = true; continue }
                val atlas = GifDecoder.buildAtlas(g, o.tag)
                session.put("images/modbridge/${o.tag}.png", atlas.first)
                session.put("images/modbridge/${o.tag}.xml", atlas.second.toByteArray(Charsets.UTF_8))
                o.kind = ObjKind.ANIMATED; o.image = "modbridge/${o.tag}"; o.prefix = o.tag; o.fps = g.fps
                o.downscale = g.downscale; o.gifBytes = null
                notes.add("GIF ${o.tag} → سبرايت ${g.frames.size} فريم")
                g.frames.forEach { it.recycle() }
            }
        }

        // 3) override script
        val scriptPath = "scripts/ModBridge_${st.name}.lua"
        val script = StageLua.generate(st)
        if (script != null) session.put(scriptPath, script.toByteArray(Charsets.UTF_8)) else session.remove(scriptPath)

        // 3b) shader files: only shaders that are actually added get written into the mod
        val shaderFiles = ShaderLib.filesToWrite(st)
        shaderFiles.forEach { (path, bytes) -> session.put(path, bytes) }
        val usedImported = st.shaders.filter { it.imported && it.enabled }.map { "shaders/${it.fileName}.frag" }.toSet()
        session.paths().filter { it.startsWith("shaders/MB_") && it.endsWith(".frag") && it !in shaderFiles.keys && it !in usedImported }
            .forEach { session.remove(it) }
        if (st.shaders.isNotEmpty()) notes.add("شادرات: ${st.shaders.count { it.enabled }} مفعّل من ${st.shaders.size}")

        // 4) health bar
        st.healthBarPng?.let { session.put("images/healthBar.png", it); notes.add("تم استبدال healthBar.png") }

        // 5) charts: page flips, characters and skins
        var editedCharts = 0
        for (chart in session.charts()) {
            val onStage = chart.stage == st.name
            val flips = plan.flips[chart.path] ?: emptySet()
            val applyChars = plan.applyCharacters && onStage
            val skinScope = plan.skinsForAllCharts || onStage
            val edit = ChartEdit(
                flips, plan.swapMode,
                if (applyChars) st.bfChar else null, if (applyChars) st.dadChar else null, if (applyChars) st.gfChar else null,
                if (skinScope) plan.arrowSkin else null, if (skinScope) plan.splashSkin else null
            )
            if (session.editChart(chart.path, edit)) editedCharts++
        }
        notes.add("شارتات معدلة: $editedCharts")
        plan.flips = emptyMap()
        plan.arrowSkin = null; plan.splashSkin = null
        st.healthBarPng = null

        session.writeTo(out)
        return notes.joinToString(" • ")
    }
}
