package com.modbridge.app

import android.content.Context
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** Offline retrieval over supplied Lua/Haxe/Psych/FNMM examples and format references. */
internal class CodeKnowledgeBase(private val context: Context) {
    data class Hit(val path: String, val excerpt: String, val score: Int)
    @Volatile private var cache: List<Pair<String, String>>? = null

    private fun entries(): List<Pair<String, String>> {
        cache?.let { return it }
        val loaded = mutableListOf<Pair<String, String>>()
        var totalBytes = 0L
        val maxEntryBytes = 2L * 1024 * 1024
        val maxTotalBytes = 32L * 1024 * 1024
        val allowed = setOf("lua", "hx", "hxc", "json", "xml", "txt", "html", "hscript", "js")

        context.assets.open("modbridge_knowledge_base.zip").use { raw ->
            ZipInputStream(raw).use { zip ->
                var fileCount = 0
                while (fileCount < 12_000) {
                    val entry = zip.nextEntry ?: break
                    fileCount++
                    if (!entry.isDirectory) {
                        val ext = entry.name.substringAfterLast('.', "").lowercase()
                        if (ext in allowed) {
                            val bytes = readBounded(zip, maxEntryBytes)
                            if (bytes == null) {
                                // Stop rather than drain an unexpectedly huge compressed entry.
                                break
                            }
                            totalBytes += bytes.size
                            if (totalBytes > maxTotalBytes) break
                            val body = bytes.toString(Charsets.UTF_8)
                            if (body.isNotBlank()) loaded += entry.name to body
                        }
                    }
                    zip.closeEntry()
                }
            }
        }

        // These structured references are separate from the archived code samples and must
        // participate in retrieval as first-class knowledge, not merely ship unused in assets.
        listOf("sprite_map_reference.json", "fnmm_format_reference.json", "porting_expertise.txt").forEach { assetName ->
            runCatching {
                context.assets.open(assetName).use { input ->
                    val bytes = readBounded(input, 2L * 1024 * 1024) ?: return@use
                    if (totalBytes + bytes.size <= maxTotalBytes) {
                        val body = bytes.toString(Charsets.UTF_8)
                        if (body.isNotBlank()) {
                            if (assetName.endsWith(".txt")) {
                                // hand-written expertise: one retrievable entry per "### TOPIC" block
                                body.split("\n### ").forEachIndexed { i, block ->
                                    val text = if (i == 0) block else "### $block"
                                    val title = text.lineSequence().firstOrNull { it.isNotBlank() }?.removePrefix("### ")?.trim().orEmpty()
                                    if (text.isNotBlank()) loaded += "reference/$assetName#$title" to text
                                }
                            } else loaded += "reference/$assetName" to body
                        }
                        totalBytes += bytes.size
                    }
                }
            }
        }
        cache = loaded.toList()
        return cache!!
    }

    private fun readBounded(input: java.io.InputStream, limit: Long): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > limit) return null
            out.write(buffer, 0, count)
        }
        return out.toByteArray()
    }

    fun search(query: String, limit: Int = 6): List<Hit> {
        val terms = Regex("[A-Za-z_][A-Za-z0-9_]{2,}|[\\u0600-\\u06FF]{3,}")
            .findAll(query.lowercase()).map { it.value }.distinct().take(32).toList()
        if (terms.isEmpty()) return emptyList()
        return entries().mapNotNull { (path, body) ->
            val lower = body.lowercase()
            val score = terms.sumOf { term ->
                val inName = if (path.substringAfterLast('/').lowercase().contains(term)) 3 else 0
                inName + minOf(8, Regex(Regex.escape(term)).findAll(lower).count())
            }
            if (score == 0) null else {
                val first = terms.firstOrNull { lower.contains(it) }
                val at = first?.let { lower.indexOf(it) }?.coerceAtLeast(0) ?: 0
                val start = (at - 260).coerceAtLeast(0)
                val end = (at + 820).coerceAtMost(body.length)
                Hit(path, body.substring(start, end).trim(), score)
            }
        }.sortedByDescending { it.score }.take(limit.coerceIn(1, 20))
    }

    fun count(): Int = entries().size
}
