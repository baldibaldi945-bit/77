package com.modbridge.app

import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

internal class ChartInfo(
    val path: String,
    val stage: String,
    val player1: String,
    val player2: String,
    val gf: String,
    val mustHit: List<Boolean>,
    val arrowSkin: String,
    val splashSkin: String
)

internal class ChartEdit(
    val flipPages: Set<Int>,
    val swapMode: Int, // 0 = flip mustHitSection (sides + camera), 1 = swap note lanes only (camera stays)
    val player1: String?,
    val player2: String?,
    val gf: String?,
    val arrowSkin: String?,
    val splashSkin: String?
)

/**
 * Disk-backed view of a Psych mod ZIP. Only the files that are actually needed are read into memory,
 * so large mods can be opened on low-RAM phones. Edits are kept as pending bytes and the output ZIP
 * is streamed entry-by-entry from the original archive.
 */
internal class StageSession(source: File) : Closeable {
    private class Src(val full: String, val entry: ZipEntry)

    private val zip = ZipFile(source)
    private val index = LinkedHashMap<String, Src>()
    val prefix: String
    private val pending = LinkedHashMap<String, ByteArray>()
    private val deleted = HashSet<String>()

    init {
        val all = ArrayList<ZipEntry>()
        val en = zip.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (!e.isDirectory && isSafe(e.name)) all.add(e)
        }
        prefix = detectPrefix(all.map { it.name })
        for (e in all) {
            val rel = if (prefix.isNotEmpty() && e.name.startsWith(prefix)) e.name.substring(prefix.length) else e.name
            index[rel] = Src(e.name, e)
        }
    }

    private fun isSafe(name: String): Boolean = !name.startsWith("/") && name.split('/').none { it == ".." }

    private fun detectPrefix(names: List<String>): String {
        val markers = listOf("stages/", "characters/", "data/", "images/", "songs/", "scripts/", "weeks/", "custom_events/", "custom_notetypes/")
        val counts = HashMap<String, Int>()
        for (n in names) {
            var best = -1
            for (m in markers) {
                val i = if (n.startsWith(m)) 0 else {
                    val k = n.indexOf("/" + m)
                    if (k < 0) -1 else k + 1
                }
                if (i >= 0 && (best < 0 || i < best)) best = i
            }
            if (best >= 0) {
                val p = n.substring(0, best)
                counts[p] = (counts[p] ?: 0) + 1
            }
        }
        return counts.maxByOrNull { it.value }?.key ?: ""
    }

    fun exists(rel: String): Boolean = !deleted.contains(rel) && (pending.containsKey(rel) || index.containsKey(rel))

    fun read(rel: String, limit: Long = 48L * 1024 * 1024): ByteArray? {
        if (deleted.contains(rel)) return null
        val p = pending[rel]
        if (p != null) return p
        val s = index[rel] ?: return null
        if (s.entry.size > limit) return null
        return zip.getInputStream(s.entry).use { it.readBytes() }
    }

    fun readText(rel: String): String? = read(rel)?.toString(Charsets.UTF_8)?.trimStart('\uFEFF')

    fun put(rel: String, bytes: ByteArray) {
        deleted.remove(rel)
        pending[rel] = bytes
    }

    fun remove(rel: String) {
        pending.remove(rel)
        if (index.containsKey(rel)) deleted.add(rel)
    }

    fun paths(): List<String> = (index.keys + pending.keys).filter { !deleted.contains(it) }.distinct()

    fun stageNames(): List<String> = paths()
        .filter { it.startsWith("stages/") && it.count { c -> c == '/' } == 1 && (it.endsWith(".json") || it.endsWith(".lua")) }
        .map { it.substringAfterLast('/').substringBeforeLast('.') }
        .distinct().sorted()

    fun characterNames(): List<String> = paths()
        .filter { it.startsWith("characters/") && it.count { c -> c == '/' } == 1 && it.endsWith(".json") }
        .map { it.substringAfterLast('/').substringBeforeLast('.') }
        .sorted()

    fun charts(): List<ChartInfo> = paths()
        .filter { it.startsWith("data/") && it.endsWith(".json") && !it.endsWith("/events.json") }
        .mapNotNull { chartInfo(it) }
        .sortedBy { it.path }

    fun chartInfo(path: String): ChartInfo? {
        val text = read(path, 12L * 1024 * 1024)?.toString(Charsets.UTF_8)?.trimStart('\uFEFF') ?: return null
        val root = try { JSONObject(text) } catch (t: Exception) { return null }
        val song = root.optJSONObject("song") ?: root
        val notes = song.optJSONArray("notes") ?: return null
        val mustHit = ArrayList<Boolean>()
        for (i in 0 until notes.length()) mustHit.add(notes.optJSONObject(i)?.optBoolean("mustHitSection", false) ?: false)
        if (mustHit.isEmpty()) return null
        return ChartInfo(
            path, song.optString("stage", ""), song.optString("player1", ""), song.optString("player2", ""),
            song.optString("gfVersion", song.optString("player3", "")), mustHit,
            song.optString("arrowSkin", ""), song.optString("splashSkin", "")
        )
    }

    /** Applies page flips, character replacement and skin names to one chart. Returns true if the file changed. */
    fun editChart(path: String, edit: ChartEdit): Boolean {
        val text = readText(path) ?: return false
        val root = try { JSONObject(text) } catch (t: Exception) { return false }
        val song = root.optJSONObject("song") ?: root
        var changed = false
        val notes = song.optJSONArray("notes")
        if (notes != null) {
            for (i in edit.flipPages) {
                val sec = notes.optJSONObject(i) ?: continue
                if (edit.swapMode == 0) {
                    sec.put("mustHitSection", !sec.optBoolean("mustHitSection", false))
                    changed = true
                } else {
                    val sn = sec.optJSONArray("sectionNotes") ?: continue
                    for (k in 0 until sn.length()) {
                        val note = sn.optJSONArray(k) ?: continue
                        val lane = note.optInt(1, -1)
                        if (lane < 0) continue
                        note.put(1, (lane + 4) % 8)
                        changed = true
                    }
                }
            }
        }
        if (edit.player1 != null && song.optString("player1") != edit.player1) { song.put("player1", edit.player1); changed = true }
        if (edit.player2 != null && song.optString("player2") != edit.player2) { song.put("player2", edit.player2); changed = true }
        if (edit.gf != null && song.optString("gfVersion") != edit.gf) { song.put("gfVersion", edit.gf); changed = true }
        if (edit.arrowSkin != null) { song.put("arrowSkin", edit.arrowSkin); changed = true }
        if (edit.splashSkin != null) { song.put("splashSkin", edit.splashSkin); changed = true }
        if (changed) put(path, root.toString().toByteArray(Charsets.UTF_8))
        return changed
    }

    /** Streams the original archive plus pending edits into [out]. */
    fun writeTo(out: File) {
        ZipOutputStream(FileOutputStream(out).buffered()).use { zo ->
            for ((rel, src) in index) {
                if (deleted.contains(rel) || pending.containsKey(rel)) continue
                zo.putNextEntry(ZipEntry(src.full))
                zip.getInputStream(src.entry).use { it.copyTo(zo) }
                zo.closeEntry()
            }
            for ((rel, bytes) in pending) {
                if (deleted.contains(rel)) continue
                val full = if (index.containsKey(rel)) index[rel]!!.full else prefix + rel
                zo.putNextEntry(ZipEntry(full))
                zo.write(bytes)
                zo.closeEntry()
            }
        }
    }

    override fun close() {
        runCatching { zip.close() }
    }
}
