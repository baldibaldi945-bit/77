package com.modbridge.app

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.zip.ZipInputStream

/** Reads supported attachments for the offline Script Lab without executing their contents. */
internal object ScriptAttachmentReader {
    data class Result(
        val name: String,
        val textForAnalysis: String,
        val kind: Kind,
        val description: String,
        val codeText: Boolean
    )
    enum class Kind { SCRIPT, ARCHIVE, IMAGE, AUDIO, OTHER }

    fun read(context: Context, uri: Uri): Result {
        val resolver = context.contentResolver
        var name = "attachment"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 } ?: 0)?.let { name = it }
        }
        val mime = resolver.getType(uri).orEmpty()
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            ext in TEXT_EXTENSIONS || mime.startsWith("text/") || mime == "application/json" -> {
                val bytes = resolver.openInputStream(uri)?.use { readLimited(it, MAX_TEXT_BYTES) }
                    ?: throw IOException("تعذرت قراءة الملف النصي")
                val text = bytes.toString(Charsets.UTF_8).trimStart('\uFEFF')
                Result(name, text, Kind.SCRIPT, "ملف نصي • ${text.length} حرف • ${mime.ifBlank { ext }}", true)
            }
            ext == "zip" || mime.contains("zip") -> {
                val bytes = resolver.openInputStream(uri)?.use { readLimited(it, MAX_ARCHIVE_BYTES) }
                    ?: throw IOException("تعذرت قراءة الأرشيف")
                val text = extractTextFromZip(bytes)
                Result(name, text, Kind.ARCHIVE, "أرشيف ZIP • تم استخراج ${text.length} حرفاً من ملفات النص والكود", true)
            }
            mime.startsWith("image/") || ext in IMAGE_EXTENSIONS -> {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("صيغة الصورة غير مقروءة")
                val text = "[Image attachment: $name; MIME=${mime.ifBlank { "unknown" }}; width=${bounds.outWidth}; height=${bounds.outHeight}; alpha may be present. The local helper can inspect metadata only and does not perform visual recognition.]"
                Result(name, text, Kind.IMAGE, "صورة • ${bounds.outWidth} × ${bounds.outHeight} • ${mime.ifBlank { ext }}", false)
            }
            mime.startsWith("audio/") || ext in AUDIO_EXTENSIONS -> {
                val retriever = MediaMetadataRetriever()
                val metadata = try {
                    retriever.setDataSource(context, uri)
                    val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                    val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty()
                    val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty()
                    buildString {
                        append("[Audio attachment: $name; MIME=${mime.ifBlank { "unknown" }}")
                        if (duration != null) append("; duration_ms=$duration")
                        if (title.isNotBlank()) append("; title=$title")
                        if (artist.isNotBlank()) append("; artist=$artist")
                        append(". Audio is not transcribed or listened to by this offline helper.]")
                    }
                } finally { runCatching { retriever.release() } }
                Result(name, metadata, Kind.AUDIO, "ملف صوتي • بيانات وصفية فقط • لا يوجد تفريغ للكلام أو تحليل للموجة الصوتية", false)
            }
            else -> Result(name, "[Binary attachment: $name; MIME=${mime.ifBlank { "unknown" }}; local helper did not decode this file.]", Kind.OTHER, "ملف غير نصي • $mime", false)
        }
    }

    private fun extractTextFromZip(bytes: ByteArray): String {
        val out = StringBuilder()
        ZipInputStream(bytes.inputStream()).use { zip ->
            var count = 0
            while (true) {
                val entry = zip.nextEntry ?: break
                val path = entry.name
                val ext = path.substringAfterLast('.', "").lowercase()
                val safe = !entry.isDirectory && !path.startsWith("/") && path.split('/').none { it == ".." || it == "." }
                if (safe && ext in TEXT_EXTENSIONS && count < 80) {
                    val remaining = (MAX_EXTRACTED_TEXT - out.length).coerceAtLeast(0)
                    if (remaining > 0) {
                        val data = readLimited(zip, minOf(remaining.toLong(), MAX_TEXT_ENTRY_BYTES)).toString(Charsets.UTF_8)
                        out.append("\n\n===== $path =====\n")
                        out.append(data.take(remaining))
                        count++
                    }
                }
                zip.closeEntry()
                if (out.length >= MAX_EXTRACTED_TEXT) break
            }
        }
        if (out.isEmpty()) return "[ZIP attachment: no supported text/code files were found.]"
        return out.toString()
    }

    private fun readLimited(input: java.io.InputStream, maxBytes: Long): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            total += n
            require(total <= maxBytes) { "الملف تجاوز حد القراءة المخصص لهذه الأداة (${maxBytes / (1024 * 1024)}MB)." }
            output.write(buffer, 0, n)
        }
        return output.toByteArray()
    }

    private val TEXT_EXTENSIONS = setOf("lua", "hx", "hxc", "hscript", "json", "xml", "txt", "ini", "cfg", "md", "html", "css", "js", "ts", "yml", "yaml", "toml", "csv", "frag", "vert", "glsl")
    private val IMAGE_EXTENSIONS = setOf("png", "jpg", "jpeg", "webp", "gif", "bmp")
    private val AUDIO_EXTENSIONS = setOf("ogg", "mp3", "wav", "m4a", "flac", "aac")
    private const val MAX_TEXT_BYTES = 2L * 1024 * 1024
    private const val MAX_ARCHIVE_BYTES = 64L * 1024 * 1024
    private const val MAX_TEXT_ENTRY_BYTES = 256L * 1024
    private const val MAX_EXTRACTED_TEXT = 2 * 1024 * 1024
}
