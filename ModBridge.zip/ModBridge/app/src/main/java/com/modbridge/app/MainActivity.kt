package com.modbridge.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.modbridge.core.ArchiveConverter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.random.Random

private enum class AppPage { HOME, LIBRARY, AI, EDITOR, IMAGES, SETTINGS, ABOUT }
private data class LabMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ModBridgeScreen() }
    }

    @Composable
    private fun ModBridgeScreen() {
        val preferences = remember { getSharedPreferences("modbridge-preferences", MODE_PRIVATE) }
        var languageName by rememberSaveable {
            mutableStateOf(preferences.getString("language", AppLanguage.ALGERIAN_ARABIC.name) ?: AppLanguage.ALGERIAN_ARABIC.name)
        }
        val language = remember(languageName) {
            runCatching { AppLanguage.valueOf(languageName) }.getOrDefault(AppLanguage.ALGERIAN_ARABIC)
        }
        val strings = remember(language) { stringsFor(language) }
        var darkMode by rememberSaveable { mutableStateOf(preferences.getBoolean("dark_mode", false)) }
        var soundsEnabled by rememberSaveable { mutableStateOf(preferences.getBoolean("sounds", true)) }
        var pageName by rememberSaveable { mutableStateOf(AppPage.HOME.name) }
        val page = runCatching { AppPage.valueOf(pageName) }.getOrDefault(AppPage.HOME)

        var sourceUri by remember { mutableStateOf<Uri?>(null) }
        var targetUri by remember { mutableStateOf<Uri?>(null) }
        var sourceLabel by remember { mutableStateOf(strings.noArchive) }
        var targetLabel by remember { mutableStateOf(strings.noFolder) }
        var selectedEngine by rememberSaveable { mutableStateOf("Auto") }
        var status by remember { mutableStateOf(strings.ready) }
        var report by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var labMessages by remember { mutableStateOf(listOf(LabMessage("أهلاً! ارفع Lua أو Haxe أو JSON، أو اكتب سؤالك. أبحث في أمثلتك المحلية وأعطيك تشخيصاً محافظاً؛ لا أدّعي تنفيذ الكود أو فهم كل مكتبة خارجية.", false))) }
        var labDraft by rememberSaveable { mutableStateOf("") }
        var attachedScriptName by remember { mutableStateOf("") }
        var attachedScriptText by remember { mutableStateOf("") }
        var attachedScriptIsCode by remember { mutableStateOf(false) }
        var showSuccessDialog by remember { mutableStateOf(false) }
        var includeBackup by rememberSaveable { mutableStateOf(false) }
        var optimizeShaders by rememberSaveable { mutableStateOf(preferences.getBoolean("optimize_shaders", true)) }
        var loaderVariant by remember { mutableStateOf(0) }
        var libraryItems by remember { mutableStateOf(SavedArchiveStore(this).list()) }
        val store = remember { SavedArchiveStore(this) }
        val scope = rememberCoroutineScope()
        val codeKnowledgeBase = remember { CodeKnowledgeBase(this@MainActivity) }

        val sourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                sourceUri = uri
                sourceLabel = runCatching {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) cursor.getString(0) else null
                    }
                }.getOrNull() ?: uri.lastPathSegment ?: "Mod.zip"
                status = strings.ready
                report = ""
            }
        }
        val scriptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching {
                    val attachment = ScriptAttachmentReader.read(this, uri)
                    attachedScriptName = attachment.name
                    attachedScriptText = attachment.textForAnalysis
                    attachedScriptIsCode = attachment.codeText
                    labMessages = labMessages + LabMessage("تم إرفاق ${attachment.name} — ${attachment.description}. ${if (attachment.codeText) "يمكن فحص النصوص والكود المستخرج." else "المعلومات المتاحة محلياً هي البيانات الوصفية فقط؛ لا يوجد تعرف بصري أو تفريغ صوتي."}", false)
                }.onFailure { labMessages = labMessages + LabMessage("تعذر إرفاق الملف: ${it.message}", false) }
            }
        }

        val targetPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                targetUri = uri
                targetLabel = DocumentFile.fromTreeUri(this, uri)?.name ?: uri.lastPathSegment ?: "Output"
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
            }
        }

        fun playUiSound(resourceId: Int) {
            if (!soundsEnabled) return
            runCatching {
                val player = MediaPlayer.create(this, resourceId) ?: return
                player.setOnCompletionListener { it.release() }
                player.start()
            }
        }

        LaunchedEffect(language) {
            if (sourceUri == null) sourceLabel = strings.noArchive
            if (targetUri == null) targetLabel = strings.noFolder
            if (!busy && report.isBlank()) status = strings.ready
        }

        val lifecycleOwner = this@MainActivity
        DisposableEffect(soundsEnabled, lifecycleOwner) {
            val music = if (soundsEnabled) runCatching {
                MediaPlayer.create(this@MainActivity, R.raw.background_loop)?.apply {
                    isLooping = true
                    setVolume(0.45f, 0.45f)
                    start()
                }
            }.getOrNull() else null
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> runCatching { if (music?.isPlaying == true) music.pause() }
                    Lifecycle.Event.ON_RESUME -> runCatching { if (soundsEnabled && music != null && !music.isPlaying) music.start() }
                    else -> Unit
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
                runCatching { music?.stop() }
                runCatching { music?.release() }
            }
        }

        LaunchedEffect(page) { libraryItems = store.list() }

        val palette = if (darkMode) darkColorScheme(
            primary = Color(0xFF9A7BFF), secondary = Color(0xFFFF4B9B), tertiary = Color(0xFF66C7D8),
            background = Color(0xFF050505), surface = Color(0xFF111111), surfaceVariant = Color(0xFF1D1D1D),
            onBackground = Color(0xFFF5F5F5), onSurface = Color(0xFFF5F5F5), onSurfaceVariant = Color(0xFFCECECE)
        ) else lightColorScheme(
            primary = Color(0xFF6840C8), secondary = Color(0xFFE91E78), tertiary = Color(0xFF168DA3),
            background = Color(0xFFFFFFFF), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFF3F0FA),
            onBackground = Color(0xFF15121A), onSurface = Color(0xFF15121A), onSurfaceVariant = Color(0xFF56515E)
        )

        var cursorPosition by remember { mutableStateOf(Offset.Unspecified) }
        var cursorVisible by remember { mutableStateOf(false) }
        LaunchedEffect(cursorPosition) {
            if (cursorPosition != Offset.Unspecified) {
                cursorVisible = true
                delay(480)
                cursorVisible = false
            }
        }

        androidx.compose.runtime.CompositionLocalProvider(
            LocalLayoutDirection provides if (language == AppLanguage.ENGLISH || language == AppLanguage.PORTUGUESE || language == AppLanguage.JAPANESE || language == AppLanguage.THAI) LayoutDirection.Ltr else LayoutDirection.Rtl
        ) {
            MaterialTheme(colorScheme = palette) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    val change = event.changes.firstOrNull()
                                    if (change != null && change.pressed) cursorPosition = change.position
                                }
                            }
                        }
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        AppHeader(strings, onCreator = {
                            playUiSound(R.raw.button_click)
                            openExternal(CreatorBranding.YOUTUBE)
                        })
                        AnimatedContent(
                            targetState = page,
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            transitionSpec = {
                                (slideInHorizontally { it / 4 } + fadeIn()) togetherWith
                                    (slideOutHorizontally { -it / 6 } + fadeOut())
                            },
                            label = "page-slide"
                        ) { destination ->
                            when (destination) {
                                AppPage.HOME -> HomePage(
                                    strings = strings,
                                    sourceLabel = sourceLabel,
                                    targetLabel = targetLabel,
                                    selectedEngine = selectedEngine,
                                    onEngine = { selectedEngine = it; playUiSound(R.raw.button_click) },
                                    onPickArchive = { playUiSound(R.raw.button_click); sourcePicker.launch(arrayOf("*/*")) },
                                    onPickFolder = { playUiSound(R.raw.button_click); targetPicker.launch(null) },
                                    optimizeShaders = optimizeShaders,
                                    onOptimizeShaders = { optimizeShaders = it; preferences.edit().putBoolean("optimize_shaders", it).apply() },
                                    includeBackup = includeBackup,
                                    onIncludeBackup = { includeBackup = it },
                                    busy = busy,
                                    loaderVariant = loaderVariant,
                                    status = status,
                                    report = report,
                                    onConvert = {
                                        playUiSound(R.raw.button_click)
                                        val selectedSource = sourceUri
                                        val selectedTarget = targetUri
                                        if (selectedSource == null || selectedTarget == null) {
                                            status = strings.chooseFirst
                                            return@HomePage
                                        }
                                        busy = true
                                        val roll = Random.nextInt(100)
                                        loaderVariant = when (roll) { in 0..69 -> 0; in 70..89 -> 1; else -> 2 }
                                        status = strings.analysing
                                        report = ""
                                        val backupOption = includeBackup
                                        val shaderOption = optimizeShaders
                                        val originalName = sourceLabel
                                        val manualEngine = selectedEngine.takeIf { it != "Auto" }
                                        scope.launch {
                                            val operation = withContext(Dispatchers.IO) {
                                                runCatching {
                                                    val input = contentResolver.openInputStream(selectedSource)?.use { stream ->
                                                        val output = ByteArrayOutputStream()
                                                        val buffer = ByteArray(64 * 1024)
                                                        var totalBytes = 0L
                                                        while (true) {
                                                            val count = stream.read(buffer)
                                                            if (count < 0) break
                                                            totalBytes += count
                                                            require(totalBytes <= 256L * 1024L * 1024L) {
                                                                "حجم الأرشيف أكبر من حد القراءة الآمن (256MB)."
                                                            }
                                                            output.write(buffer, 0, count)
                                                        }
                                                        output.toByteArray()
                                                    } ?: error("تعذرت قراءة الأرشيف المختار.")

                                                    val converted = ArchiveConverter.convert(
                                                        input,
                                                        includeSourceBackup = backupOption,
                                                        optimizeShaders = shaderOption,
                                                        sourceName = originalName,
                                                        sourceOverride = manualEngine
                                                    )
                                                    val templated = PsychOutputFinalizer.apply(this@MainActivity, converted.bytes, converted.source)
                                                    val atlas = AndroidSpriteSheetBuilder.process(templated)
                                                    val spriteMaps = SpriteMapRebuilder.process(atlas.archive)
                                                    val gifs = GifSpriteBuilder.process(spriteMaps.archive)
                                                    val finalArchive = gifs.archive
                                                    val safeSource = converted.source.replace(Regex("[^A-Za-z0-9_-]"), "-")
                                                    val fileName = "ModBridge-$safeSource-Psych.zip"
                                                    val tree = DocumentFile.fromTreeUri(this@MainActivity, selectedTarget)
                                                        ?: error("مجلد الإخراج غير صالح.")
                                                    tree.findFile(fileName)?.delete()
                                                    val resultFile = tree.createFile("application/zip", fileName)
                                                        ?: error("تعذر إنشاء ملف ZIP في مجلد الإخراج.")
                                                    contentResolver.openOutputStream(resultFile.uri)?.use { it.write(finalArchive) }
                                                        ?: error("تعذر حفظ ملف ZIP الناتج.")
                                                    val savedInLibrary = runCatching { store.save(finalArchive, converted.source) }.isSuccess
                                                    Triple(converted, Triple(atlas, spriteMaps, gifs), finalArchive.size to savedInLibrary)
                                                }
                                            }
                                            operation.onSuccess { (converted, builders, sizeAndSaved) ->
                                                val (atlas, spriteMaps, gifs) = builders
                                                val (outputSize, savedInLibrary) = sizeAndSaved
                                                status = if (savedInLibrary) "${strings.outputDone}\n${strings.saved} ✓" else strings.outputDone
                                                report = buildString {
                                                    appendLine("Source: ${converted.source}")
                                                    appendLine("Files scanned: ${converted.files}")
                                                    appendLine("Charts converted: ${converted.charts}")
                                                    appendLine("Recognized scripts translated: ${converted.scriptsTranslated}")
                                                    appendLine("FNMM sprite atlases: ${atlas.atlases} • Frames: ${atlas.frames}")
                                                    appendLine("Rebuilt sprite maps: ${spriteMaps.atlases} • Cropped frames: ${spriteMaps.frames}")
                                                    appendLine("GIFs converted: ${gifs.gifs} • Frames generated: ${gifs.frames}")
                                                    appendLine("ZIP size: ${outputSize / 1024} KB")
                                                    appendLine("Unsupported source files excluded: ${converted.sourceFilesExcluded}")
                                                    if (!savedInLibrary) appendLine("Library copy could not be saved; the exported ZIP is still available.")
                                                    (converted.warnings + atlas.warnings + spriteMaps.warnings + gifs.warnings).take(120).forEach { appendLine("• $it") }
                                                }
                                                libraryItems = store.list()
                                                showSuccessDialog = true
                                                playUiSound(R.raw.conversion_success)
                                            }.onFailure { error ->
                                                status = "${strings.unsupported}\n${error.message ?: "Unknown error"}"
                                                report = "لم يتم إنشاء ملف ناتج. تأكد من أن الأرشيف يحتوي بنية مصدر مدعومة وغير مشفرة بكلمة مرور."
                                            }
                                            busy = false
                                        }
                                    },
                                    onReverseToFnmm = {
                                        val selectedSource = sourceUri
                                        val selectedTarget = targetUri
                                        if (selectedSource == null || selectedTarget == null) {
                                            status = strings.chooseFirst
                                        } else {
                                            busy = true
                                            status = "تحليل مود Psych Engine وبناء ملفات FNMM منفصلة..."
                                            report = ""
                                            scope.launch {
                                                val conversion = withContext(Dispatchers.IO) {
                                                    runCatching {
                                                        val input = contentResolver.openInputStream(selectedSource)?.use { stream ->
                                                            val output = ByteArrayOutputStream()
                                                            val buffer = ByteArray(64 * 1024)
                                                            var total = 0L
                                                            while (true) {
                                                                val count = stream.read(buffer)
                                                                if (count < 0) break
                                                                total += count
                                                                require(total <= 256L * 1024L * 1024L) { "أرشيف المصدر أكبر من 256MB." }
                                                                output.write(buffer, 0, count)
                                                            }
                                                            output.toByteArray()
                                                        } ?: error("تعذرت قراءة مود Psych Engine.")
                                                        PsychFnmmConverter.convert(input)
                                                    }
                                                }
                                                conversion.onSuccess { result ->
                                                    if (result.artifacts.isEmpty()) {
                                                        status = result.warnings.joinToString("\n").ifBlank { "لم يتم إنشاء ملفات FNMM." }
                                                        report = "لم يتم حفظ أي ملف."
                                                    } else {
                                                        val tree = DocumentFile.fromTreeUri(this@MainActivity, selectedTarget)
                                                        if (tree == null) {
                                                            status = "مجلد الإخراج غير صالح."
                                                        } else {
                                                            var saved = 0
                                                            result.artifacts.forEach { artifact ->
                                                                tree.findFile(artifact.name)?.delete()
                                                                val file = tree.createFile("application/octet-stream", artifact.name) ?: error("تعذر إنشاء ${artifact.name}")
                                                                contentResolver.openOutputStream(file.uri)?.use { it.write(artifact.bytes) } ?: error("تعذر حفظ ${artifact.name}")
                                                                saved++
                                                            }
                                                            status = "اكتمل التحويل: تم إنشاء $saved ملف FNMM."
                                                            report = buildString {
                                                                appendLine("Psych Engine → Funky Maker Mobile")
                                                                appendLine("Archives created: $saved")
                                                                appendLine("Files inspected: ${result.sourceFiles}")
                                                                result.artifacts.forEach { appendLine("• ${it.name} — ${it.notes} notes — stage ${it.stage}") }
                                                                result.warnings.take(160).forEach { appendLine("⚠ $it") }
                                                            }
                                                            showSuccessDialog = true
                                                        }
                                                    }
                                                }.onFailure { error ->
                                                    status = "فشل التحويل العكسي: ${error.message}"
                                                    report = "لم يتم حفظ أي ملف FNMM."
                                                }
                                                busy = false
                                            }
                                        }
                                    }
                                )
                                AppPage.LIBRARY -> LibraryPage(
                                    strings = strings,
                                    items = libraryItems,
                                    onExport = { item ->
                                        playUiSound(R.raw.button_click)
                                        val folder = targetUri
                                        if (folder == null) status = strings.chooseFirst
                                        else {
                                            val ok = runCatching { store.export(item, folder) }.getOrDefault(false)
                                            status = if (ok) strings.outputDone else "تعذر تصدير الملف."
                                        }
                                    },
                                    onDelete = { item ->
                                        playUiSound(R.raw.button_click)
                                        store.delete(item)
                                        libraryItems = store.list()
                                    }
                                )
                                AppPage.AI -> ScriptLabPage(
                                    messages = labMessages,
                                    draft = labDraft,
                                    attachedName = attachedScriptName,
                                    onDraft = { labDraft = it },
                                    onAttach = { scriptPicker.launch(arrayOf("*/*")) },
                                    onSend = { question ->
                                        val prompt = question.ifBlank { "افحص الملف المرفق" }
                                        labMessages = labMessages + LabMessage(prompt, true)
                                        labDraft = ""
                                        scope.launch {
                                            val answer = withContext(Dispatchers.IO) {
                                                val report = if (attachedScriptIsCode && attachedScriptText.isNotBlank()) ScriptDoctor.inspect(attachedScriptName, attachedScriptText) else null
                                                val hits = if (attachedScriptIsCode) codeKnowledgeBase.search(prompt + " " + attachedScriptText.take(12000), 4) else emptyList()
                                                buildString {
                                                    if (!attachedScriptIsCode && attachedScriptText.isNotBlank()) appendLine(attachedScriptText)
                                                    if (report != null) {
                                                        appendLine("تحليل ${report.language} — ${attachedScriptName}")
                                                        report.errors.forEach { appendLine("خطأ: $it") }
                                                        report.warnings.forEach { appendLine("تنبيه: $it") }
                                                        report.migration?.let { appendLine(it) }
                                                        if (report.errors.isEmpty() && report.warnings.isEmpty()) appendLine("لم تظهر أخطاء بنيوية واضحة بالفحوصات الساكنة المحدودة.")
                                                    }
                                                    if (hits.isNotEmpty()) {
                                                        appendLine("\nأمثلة قريبة من قاعدة البيانات المحلية:")
                                                        hits.forEach { appendLine("\n[${it.path}] (مطابقة ${it.score})\n${it.excerpt.take(1100)}") }
                                                    } else appendLine("لم أجد مثالاً مطابقاً في قاعدة المعرفة المحلية.")
                                                    appendLine("\nملاحظة: هذا تحليل ساكن واسترجاع أمثلة، وليس نموذجاً لغوياً عاماً ولا اختباراً داخل Psych Engine. راجع أي تعديل قبل تشغيله.")
                                                }
                                            }
                                            labMessages = labMessages + LabMessage(answer, false)
                                        }
                                    }
                                )
                                AppPage.EDITOR -> StageEditorScreen()
                                AppPage.IMAGES -> ImageToolsPage()
                                AppPage.SETTINGS -> SettingsPage(
                                    strings = strings,
                                    language = language,
                                    darkMode = darkMode,
                                    soundsEnabled = soundsEnabled,
                                    onLanguage = {
                                        languageName = it.name
                                        preferences.edit().putString("language", it.name).apply()
                                        playUiSound(R.raw.button_click)
                                    },
                                    onDarkMode = {
                                        darkMode = it
                                        preferences.edit().putBoolean("dark_mode", it).apply()
                                        playUiSound(R.raw.button_click)
                                    },
                                    onSounds = {
                                        soundsEnabled = it
                                        preferences.edit().putBoolean("sounds", it).apply()
                                    }
                                )
                                AppPage.ABOUT -> AboutPage(strings, onYoutube = {
                                    playUiSound(R.raw.button_click)
                                    openExternal(CreatorBranding.YOUTUBE)
                                }, onInstagram = {
                                    playUiSound(R.raw.button_click)
                                    openExternal(CreatorBranding.INSTAGRAM)
                                })
                            }
                        }
                        BottomNavigation(strings, page, onNavigate = {
                            pageName = it.name
                            playUiSound(R.raw.button_click)
                        })
                    }
                    if (showSuccessDialog) {
                        AlertDialog(
                            onDismissRequest = { showSuccessDialog = false },
                            title = { Text("✓  ${strings.outputDone}", fontWeight = FontWeight.Bold) },
                            text = { Text(status) },
                            confirmButton = {
                                TextButton(onClick = {
                                    showSuccessDialog = false
                                    playUiSound(R.raw.button_click)
                                }) { Text(strings.ready) }
                            }
                        )
                    }
                    if (cursorVisible && cursorPosition != Offset.Unspecified) {
                        Image(
                            painter = painterResource(R.drawable.touch_cursor),
                            contentDescription = "Touch pointer",
                            modifier = Modifier
                                .absoluteOffset { IntOffset(cursorPosition.x.toInt(), cursorPosition.y.toInt()) }
                                .size(30.dp)
                                .graphicsLayer(alpha = 0.88f),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }
        }
    }

    private fun openExternal(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    @Composable
    private fun AppHeader(strings: UiStrings, onCreator: () -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.app_icon),
                contentDescription = "${CreatorBranding.APP_NAME} by ${CreatorBranding.CREATOR}",
                modifier = Modifier.size(62.dp).clip(RoundedCornerShape(15.dp)),
                contentScale = ContentScale.Crop
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(CreatorBranding.APP_NAME, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text(strings.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("by ${CreatorBranding.CREATOR}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            TextButton(onClick = onCreator) { Text("▶ YouTube") }
        }
        Divider(color = MaterialTheme.colorScheme.surfaceVariant)
    }

    @Composable
    private fun HomePage(
        strings: UiStrings,
        sourceLabel: String,
        targetLabel: String,
        selectedEngine: String,
        onEngine: (String) -> Unit,
        onPickArchive: () -> Unit,
        onPickFolder: () -> Unit,
        optimizeShaders: Boolean,
        onOptimizeShaders: (Boolean) -> Unit,
        includeBackup: Boolean,
        onIncludeBackup: (Boolean) -> Unit,
        busy: Boolean,
        loaderVariant: Int,
        status: String,
        report: String,
        onConvert: () -> Unit,
        onReverseToFnmm: () -> Unit
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.sourceEngine, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(strings.sourceHint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf("Auto", "Codename Engine", "V-Slice", "Funky Maker Mobile", "Psych Engine").chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            pair.forEach { engine ->
                                FilterChip(
                                    selected = selectedEngine == engine,
                                    onClick = { onEngine(engine) },
                                    label = { Text(when (engine) {
                                        "Auto" -> strings.autoDetect
                                        "Codename Engine" -> "Codename"
                                        "V-Slice" -> "V-Slice"
                                        "Funky Maker Mobile" -> "FNMM"
                                        else -> "Psych Engine"
                                    }, fontSize = 11.sp) },
                                    enabled = !busy,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(strings.chooseArchive, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = onPickArchive, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("📦  ${strings.chooseArchive}")
                    }
                    Text(sourceLabel, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                    Text(strings.outputFolder, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = onPickFolder, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("📁  ${strings.chooseFolder}")
                    }
                    Text(targetLabel, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.options, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ToggleRow(strings.optimizeShaders, optimizeShaders, !busy, onOptimizeShaders)
                    ToggleRow(strings.sourceBackup, includeBackup, !busy, onIncludeBackup)
                }
            }

            Button(onClick = onConvert, enabled = !busy && selectedEngine != "Psych Engine", modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (busy) strings.converting else strings.start, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onReverseToFnmm, enabled = !busy && selectedEngine == "Psych Engine", modifier = Modifier.fillMaxWidth()) {
                Text("↔ تحويل Psych Engine إلى FNMM (ملف مستقل لكل شارت)")
            }
            if (selectedEngine == "Psych Engine") Text("اختر Psych Engine ثم استخدم التحويل العكسي. سيتم إنشاء ملفات FNMM منفصلة في مجلد الإخراج.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            AnimatedVisibility(visible = busy) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AnimatedContent(targetState = loaderVariant, label = "loader-message") { variant ->
                            val (symbol, message) = when (variant) {
                                0 -> "✦" to strings.analysing
                                1 -> "◈" to strings.sourceHint
                                else -> "✧" to strings.converting
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(symbol, fontSize = 34.sp, color = MaterialTheme.colorScheme.primary)
                                Text(message, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            Text(status, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            AnimatedVisibility(visible = report.isNotBlank()) {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(strings.report, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(report, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Text(
                strings.aiNote,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    @Composable
    private fun LibraryPage(
        strings: UiStrings,
        items: List<SavedArchiveStore.Item>,
        onExport: (SavedArchiveStore.Item) -> Unit,
        onDelete: (SavedArchiveStore.Item) -> Unit
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(strings.library, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (items.isEmpty()) Text(strings.noSaved, style = MaterialTheme.typography.bodyMedium)
            items.forEach { item ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(item.source, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(item.fileName, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${item.sizeBytes / 1024} KB • ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.savedAt))}", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onExport(item) }) { Text(strings.export) }
                            OutlinedButton(onClick = { onDelete(item) }) { Text(strings.delete) }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsPage(
        strings: UiStrings,
        language: AppLanguage,
        darkMode: Boolean,
        soundsEnabled: Boolean,
        onLanguage: (AppLanguage) -> Unit,
        onDarkMode: (Boolean) -> Unit,
        onSounds: (Boolean) -> Unit
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(strings.settings, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.language, fontWeight = FontWeight.Bold)
                    AppLanguage.entries.forEach { option ->
                        FilterChip(
                            selected = option == language,
                            onClick = { onLanguage(option) },
                            label = { Text(when (option) {
                                AppLanguage.ALGERIAN_ARABIC -> "🇩🇿 العربية الجزائرية"
                                AppLanguage.ENGLISH -> "🇺🇸 English"
                                AppLanguage.PORTUGUESE -> "🇧🇷 Português"
                                AppLanguage.JAPANESE -> "🇯🇵 日本語"
                                AppLanguage.THAI -> "🇹🇭 ไทย"
                                AppLanguage.STANDARD_ARABIC -> "🇸🇦 العربية الفصحى"
                            }) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ToggleRow(strings.darkMode, darkMode, true, onDarkMode)
                    ToggleRow(strings.sound, soundsEnabled, true, onSounds)
                }
            }
            Text("${CreatorBranding.APP_NAME} • ${CreatorBranding.CREATOR}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    private fun AboutPage(strings: UiStrings, onYoutube: () -> Unit, onInstagram: () -> Unit) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(painterResource(R.drawable.app_icon), "${CreatorBranding.APP_NAME} icon", Modifier.size(68.dp).clip(RoundedCornerShape(14.dp)))
                Column {
                    Text(CreatorBranding.APP_NAME, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("${strings.creator} ${CreatorBranding.CREATOR}", color = MaterialTheme.colorScheme.primary)
                }
            }
            Card { Text(strings.aboutText, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            Card { Text(strings.supports, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            Card { Text(strings.limitations, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            Text(strings.aiNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(strings.social, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onYoutube) { Text("▶ YouTube") }
                OutlinedButton(onClick = onInstagram) { Text("◎ Instagram") }
            }
            Text(strings.copyright, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, modifier = Modifier.weight(1f).padding(end = 8.dp), style = MaterialTheme.typography.bodyMedium)
            Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
        }
    }

    @Composable
    private fun ScriptLabPage(
        messages: List<LabMessage>, draft: String, attachedName: String,
        onDraft: (String) -> Unit, onAttach: () -> Unit, onSend: (String) -> Unit
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("ModBridge Script Lab", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("مساعد محلي لقراءة Lua / Haxe / JSON والبحث في أمثلتك", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (attachedName.isNotBlank()) Text("📎 $attachedName", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                messages.forEach { message ->
                    Card(
                        modifier = Modifier.fillMaxWidth(if (message.fromUser) 0.88f else 1f).align(if (message.fromUser) Alignment.End else Alignment.Start),
                        colors = CardDefaults.cardColors(containerColor = if (message.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                    ) { Text(message.text, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onAttach) { Text("إرفاق") }
                OutlinedTextField(value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f), placeholder = { Text("اكتب طلبك...") }, maxLines = 3)
                Button(onClick = { onSend(draft) }, enabled = draft.isNotBlank() || attachedName.isNotBlank()) { Text("إرسال") }
            }
        }
    }

    @Composable
    private fun PsychEditorPage() {
        val context = LocalContext.current
        val activity = context as? ComponentActivity
        DisposableEffect(activity) {
            val previousOrientation = activity?.requestedOrientation
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            onDispose { if (previousOrientation != null) activity?.requestedOrientation = previousOrientation }
        }
        val scope = rememberCoroutineScope()
        var sourceBytes by remember { mutableStateOf<ByteArray?>(null) }
        var sourceName by remember { mutableStateOf("لم يتم اختيار مود Psych Engine") }
        var stageFiles by remember { mutableStateOf(emptyList<PsychModEditor.StageFile>()) }
        var selectedPath by remember { mutableStateOf("") }
        var values by remember { mutableStateOf<PsychModEditor.Values?>(null) }
        var initialValues by remember { mutableStateOf<PsychModEditor.Values?>(null) }
        var flipCharts by rememberSaveable { mutableStateOf(false) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("اختر مود Psych Engine بصيغة ZIP لفتح بيانات المراحل.") }
        var pendingOutput by remember { mutableStateOf<ByteArray?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                busy = true
                scope.launch {
                    val loaded = withContext(Dispatchers.IO) {
                        runCatching {
                            val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
                                val out = ByteArrayOutputStream(); val buffer = ByteArray(32 * 1024); var total = 0L
                                while (true) { val n = stream.read(buffer); if (n < 0) break; total += n; require(total <= 256L * 1024 * 1024) { "المود أكبر من 256MB." }; out.write(buffer, 0, n) }
                                out.toByteArray()
                            } ?: error("تعذرت قراءة ملف المود.")
                            bytes to PsychModEditor.inspect(bytes)
                        }
                    }
                    loaded.onSuccess { (bytes, info) ->
                        sourceBytes = bytes
                        stageFiles = info.stages
                        sourceName = uri.lastPathSegment?.substringAfterLast('/') ?: "Psych-Mod.zip"
                        selectedPath = info.stages.firstOrNull()?.path.orEmpty()
                        values = info.stages.firstOrNull()?.let { PsychModEditor.defaults(it) }
                        initialValues = values
                        status = "تم فحص ${info.totalFiles} ملفاً • ${info.stages.size} مرحلة JSON • ${info.charts} شارت."
                        if (info.stages.isEmpty()) status += " لم يعثر على stages/*.json؛ قد تكون بيانات المرحلة داخل Lua فقط."
                    }.onFailure { status = "تعذر فتح المود: ${it.message}" }
                    busy = false
                }
            }
        }
        val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            val bytes = pendingOutput
            if (uri != null && bytes != null) {
                scope.launch {
                    val saved = withContext(Dispatchers.IO) { runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("تعذر فتح ملف الحفظ.") } }
                    status = if (saved.isSuccess) "تم حفظ نسخة المود المعدلة." else "تعذر حفظ المود: ${saved.exceptionOrNull()?.message}"
                }
            }
        }
        val selectedStage = stageFiles.firstOrNull { it.path == selectedPath }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Psych Engine Stage Editor", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Text("يحرر قيم stage JSON مباشرة ويحافظ على بقية ملفات ZIP. كما يمكنه قلب ملكية أقسام الشارت بين اللاعب والخصم.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("📦 اختيار مود Psych Engine") }
            Text(sourceName, style = MaterialTheme.typography.labelSmall)
            if (stageFiles.isNotEmpty()) {
                Text("اختر المرحلة", fontWeight = FontWeight.Bold)
                stageFiles.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { stage -> FilterChip(selected = selectedPath == stage.path, onClick = {
                            selectedPath = stage.path
                            values = PsychModEditor.defaults(stage)
                            initialValues = values
                        }, label = { Text(stage.name) }, modifier = Modifier.weight(1f), enabled = !busy) }
                    }
                }
            }
            values?.let { v ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الكاميرا والمرحلة", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(v.defaultZoom, { values = v.copy(defaultZoom = it) }, modifier = Modifier.weight(1f), label = { Text("Default Zoom") }, singleLine = true)
                            OutlinedTextField(v.cameraSpeed, { values = v.copy(cameraSpeed = it) }, modifier = Modifier.weight(1f), label = { Text("Camera Speed") }, singleLine = true)
                        }
                        Text("Boyfriend", fontWeight = FontWeight.SemiBold)
                        editPair("X", v.boyfriendX, { values = v.copy(boyfriendX = it) }, "Y", v.boyfriendY, { values = v.copy(boyfriendY = it) })
                        Text("Camera Boyfriend", fontWeight = FontWeight.SemiBold)
                        editPair("Camera X", v.cameraBoyfriendX, { values = v.copy(cameraBoyfriendX = it) }, "Camera Y", v.cameraBoyfriendY, { values = v.copy(cameraBoyfriendY = it) })
                        Text("Girlfriend", fontWeight = FontWeight.SemiBold)
                        editPair("X", v.girlfriendX, { values = v.copy(girlfriendX = it) }, "Y", v.girlfriendY, { values = v.copy(girlfriendY = it) })
                        Text("Camera Girlfriend", fontWeight = FontWeight.SemiBold)
                        editPair("Camera X", v.cameraGirlfriendX, { values = v.copy(cameraGirlfriendX = it) }, "Camera Y", v.cameraGirlfriendY, { values = v.copy(cameraGirlfriendY = it) })
                        Text("Opponent / Dad", fontWeight = FontWeight.SemiBold)
                        editPair("X", v.opponentX, { values = v.copy(opponentX = it) }, "Y", v.opponentY, { values = v.copy(opponentY = it) })
                        Text("Camera Opponent", fontWeight = FontWeight.SemiBold)
                        editPair("Camera X", v.cameraOpponentX, { values = v.copy(cameraOpponentX = it) }, "Camera Y", v.cameraOpponentY, { values = v.copy(cameraOpponentY = it) })
                        OutlinedButton(onClick = { values = initialValues }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("↶ إعادة القيم الأصلية للمرحلة") }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("قلب شارت اللاعب والخصم", fontWeight = FontWeight.Bold)
                            Text("يقلب mustHitSection لكل الأقسام في جميع ملفات data/*.json.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = flipCharts, onCheckedChange = { flipCharts = it }, enabled = !busy)
                    }
                }
            }
            Button(onClick = {
                val input = sourceBytes
                val stage = selectedStage
                val edited = values
                if (input == null || stage == null || edited == null) { status = "اختر موداً يحتوي على stage JSON أولاً."; return@Button }
                busy = true
                scope.launch {
                    val saved = withContext(Dispatchers.IO) { runCatching { PsychModEditor.save(input, stage, edited, flipCharts) } }
                    saved.onSuccess {
                        pendingOutput = it.bytes
                        status = "تم تجهيز ZIP معدل. الشارتات التي تم قلبها: ${it.changedCharts}. اضغط حفظ لتنزيل النسخة."
                        savePicker.launch("ModBridge-${stage.name}-edited.zip")
                    }.onFailure { status = "تعذر تعديل المود: ${it.message}" }
                    busy = false
                }
            }, enabled = !busy && sourceBytes != null && selectedStage != null && values != null, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text(if (busy) "جارٍ تعديل المود..." else "حفظ المود المعدل ZIP")
            }
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            Text("حدود هذه الأداة: تعدّل stage JSON وقلب ملكية أقسام الشارت، لكنها لا تعرض Render حي للمرحلة ولا تعيد هندسة عناصر Lua المتحركة أو تختبر الشارت داخل محرك Psych.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    private fun editPair(labelA: String, valueA: String, onA: (String) -> Unit, labelB: String, valueB: String, onB: (String) -> Unit) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(valueA, onA, modifier = Modifier.weight(1f), label = { Text(labelA) }, singleLine = true)
            OutlinedTextField(valueB, onB, modifier = Modifier.weight(1f), label = { Text(labelB) }, singleLine = true)
        }
    }

    @Composable
    private fun ImageToolsPage() {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        var source by remember { mutableStateOf<Uri?>(null) }
        var sourceName by remember { mutableStateOf("لم يتم اختيار صورة") }
        var formatName by rememberSaveable { mutableStateOf(ImageOutputFormat.PNG.name) }
        var quality by rememberSaveable { mutableStateOf(82f) }
        var scale by rememberSaveable { mutableStateOf(100f) }
        var keepAlpha by rememberSaveable { mutableStateOf(true) }
        var blackBackground by rememberSaveable { mutableStateOf(false) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("اختر PNG أو JPG أو WebP أو GIF للبدء.") }
        var result by remember { mutableStateOf<ImageCompressionResult?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                source = uri
                sourceName = runCatching {
                    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                }.getOrNull() ?: uri.lastPathSegment ?: "image"
                result = null
                status = "تم اختيار $sourceName"
            }
        }
        val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val ready = result
            if (uri != null && ready != null) {
                scope.launch {
                    val saved = withContext(Dispatchers.IO) {
                        runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(ready.output) } ?: error("تعذر فتح ملف الحفظ.") }
                    }
                    status = if (saved.isSuccess) "تم حفظ ${ready.outputName} بنجاح." else "تعذر الحفظ: ${saved.exceptionOrNull()?.message}"
                }
            }
        }
        val selectedFormat = runCatching { ImageOutputFormat.valueOf(formatName) }.getOrDefault(ImageOutputFormat.PNG)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Image Optimizer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Text("ضغط وتصغير الصور مع التحكم بالشفافية. يدعم PNG وWebP وJPEG وGIF المتحرك.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("🖼 اختيار صورة أو GIF") }
                    Text(sourceName, style = MaterialTheme.typography.bodySmall)
                    Text("صيغة الإخراج", fontWeight = FontWeight.Bold)
                    listOf(ImageOutputFormat.PNG, ImageOutputFormat.WEBP, ImageOutputFormat.JPEG, ImageOutputFormat.GIF).chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { item -> FilterChip(selected = selectedFormat == item, onClick = { formatName = item.name }, label = { Text(item.label) }, modifier = Modifier.weight(1f), enabled = !busy) }
                        }
                    }
                    Text("الجودة: ${quality.toInt()}%", fontWeight = FontWeight.SemiBold)
                    Slider(value = quality, onValueChange = { quality = it }, valueRange = 10f..100f, enabled = !busy)
                    Text("حجم الأبعاد: ${scale.toInt()}%", fontWeight = FontWeight.SemiBold)
                    Slider(value = scale, onValueChange = { scale = it }, valueRange = 10f..100f, enabled = !busy)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("الحفاظ على الشفافية", fontWeight = FontWeight.SemiBold)
                            Text("PNG وWebP وGIF يحافظون على قناة Alpha.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = keepAlpha, onCheckedChange = { keepAlpha = it }, enabled = !busy && selectedFormat != ImageOutputFormat.JPEG)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("خلفية الصور غير الشفافة:", style = MaterialTheme.typography.bodySmall)
                        FilterChip(selected = !blackBackground, onClick = { blackBackground = false }, label = { Text("بيضاء") }, enabled = !busy)
                        FilterChip(selected = blackBackground, onClick = { blackBackground = true }, label = { Text("سوداء") }, enabled = !busy)
                    }
                    Button(onClick = {
                        val uri = source ?: return@Button
                        busy = true; status = "جارٍ ضغط الصورة..."
                        val settings = ImageCompressionSettings(quality.toInt(), scale.toInt(), selectedFormat, keepAlpha && selectedFormat != ImageOutputFormat.JPEG, if (blackBackground) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                        scope.launch {
                            val compressed = withContext(Dispatchers.IO) { runCatching { ImageCompressionEngine.compress(context, uri, settings) } }
                            compressed.onSuccess { ready ->
                                result = ready
                                status = "اكتمل: ${ready.originalBytes / 1024} KB ← ${ready.output.size / 1024} KB • ${ready.savedPercent}% توفير • ${ready.frames} إطار"
                            }.onFailure { status = "تعذر الضغط: ${it.message}" }
                            busy = false
                        }
                    }, enabled = source != null && !busy, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(if (busy) "جارٍ الضغط..." else "ضغط الصورة") }
                }
            }
            result?.let { ready ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("نتيجة الضغط", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("${ready.originalName} → ${ready.outputName}", style = MaterialTheme.typography.bodySmall)
                        Text("${ready.originalBytes / 1024} KB → ${ready.output.size / 1024} KB (${ready.savedPercent}% توفير)")
                        if (ready.warning.isNotBlank()) Text(ready.warning, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                        Button(onClick = { savePicker.launch(ready.outputName) }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الصورة المضغوطة") }
                    }
                }
            }
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            Text("PNG عند 100% يحفظ البكسلات دون فقد. عند جودة أقل يُستخدم PNG مفهرس بلوحة ألوان وشفافية محدودة وقد تتغير التدرجات. GIF المتحرك يُعاد ترميزه بلوحة ألوان صغيرة ويُؤخذ منه عينات إطارات؛ اختر الحفاظ على الشفافية لتجنب إضافة خلفية.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    private fun BottomNavigation(strings: UiStrings, selected: AppPage, onNavigate: (AppPage) -> Unit) {
        Divider(color = MaterialTheme.colorScheme.surfaceVariant)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val entries = listOf(
                AppPage.HOME to "⌂ ${strings.home}",
                AppPage.LIBRARY to "▤ ${strings.library}",
                AppPage.AI to "✦ Script Lab",
                AppPage.EDITOR to "⚒ Stage Edit",
                AppPage.IMAGES to "🖼 الصور",
                AppPage.SETTINGS to "⚙ ${strings.settings}",
                AppPage.ABOUT to "ⓘ ${strings.about}"
            )
            entries.forEach { (page, label) ->
                TextButton(onClick = { onNavigate(page) }) {
                    Text(label, color = if (selected == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, fontWeight = if (selected == page) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}
