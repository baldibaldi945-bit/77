package com.modbridge.core

import kotlin.test.Test
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class ScriptMigrationAITest {
    @Test fun translatesRecognizedCameraAndFlashPatternsOnly() {
        val source = """
            function onCreate() {
                FlxG.camera.zoom = 0.8;
                FlxG.camera.flash(FlxColor.WHITE, 0.5);
                unknownEngineThing(42);
            }
        """.trimIndent()
        val result = ScriptMigrationAI.translate(source)
        assertNotNull(result)
        assertTrue(result.lua.contains("setProperty('camGame.zoom', 0.8)"))
        assertTrue(result.lua.contains("cameraFlash('game', 'FFFFFF', 0.5)"))
        assertTrue(!result.lua.contains("unknownEngineThing"))
        assertTrue(result.skipped > 0)
    }
    @Test fun doesNotMoveConditionalLogicIntoUnconditionalLua() {
        val source = """
            function onUpdate(elapsed) {
                if (FlxG.random.bool(50)) {
                    FlxG.camera.zoom = 1.2;
                }
                FlxG.camera.flash(FlxColor.WHITE, 0.25);
            }
        """.trimIndent()
        val result = ScriptMigrationAI.translate(source)
        assertNotNull(result)
        assertTrue(!result.lua.contains("camGame.zoom"))
        assertTrue(result.lua.contains("cameraFlash('game', 'FFFFFF', 0.25)"))
        assertTrue(result.lua.contains("function onUpdate(elapsed)"))
    }

}
