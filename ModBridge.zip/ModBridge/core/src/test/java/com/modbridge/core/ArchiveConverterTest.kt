package com.modbridge.core

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class ArchiveConverterTest {
    private fun zip(files: Map<String, String>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            files.forEach { (name, value) ->
                z.putNextEntry(ZipEntry(name)); z.write(value.toByteArray()); z.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun entries(bytes: ByteArray): Set<String> {
        val result = linkedSetOf<String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) { val e = z.nextEntry ?: break; result += e.name; z.closeEntry() }
        }
        return result
    }

    @Test fun detectsAndConvertsFnmmWithoutRequiringMusicOrScene() {
        val input = zip(mapOf(
            "data.json" to """{"bpm":120,"strumLines":[[[{"start":1.0,"duration":0.5}]],[[{"start":2.0,"duration":0.0}]]]}"""
        ))
        val result = ArchiveConverter.convert(input)
        val names = entries(result.bytes)
        assertEquals("Funky Maker Mobile", result.source)
        assertEquals(1, result.charts)
        assertTrue(names.contains("data/fnmm-song/fnmm-song-hard.json"))
        assertTrue(names.contains("conversion-report.txt"))
    }

    @Test fun detectsCodenameAndConvertsChartWithoutAudio() {
        val input = zip(mapOf(
            "songs/demo/charts/hard.json" to """{"codenameChart":true,"stage":"demo","noteTypes":["Alt Anim Note"],"strumLines":[{"keyCount":4,"position":"dad","characters":["gary"],"notes":[{"id":0,"time":100,"sLen":0,"type":1}]},{"keyCount":4,"position":"bf","characters":["bf-mollusk"],"notes":[{"id":1,"time":200,"sLen":250}]},{"keyCount":4,"position":"girlfriend","characters":["gf-mollusk"],"notes":[]}]}""",
            "songs/demo/meta.json" to """{"displayName":"Demo","bpm":120,"needsVoices":true}""",
            "data/config/modpack.ini" to "[modpack]",
            "data/stages/demo.xml" to "<stage folder=\"stages/demo/\" zoom=\"0.75\"><bf x=\"800\" y=\"120\"/><dad x=\"100\" y=\"90\"/><gf x=\"400\" y=\"130\"/></stage>"
        ))
        val result = ArchiveConverter.convert(input)
        val names = entries(result.bytes)
        assertEquals("Codename Engine", result.source)
        assertEquals(1, result.charts)
        assertTrue(names.contains("data/demo/demo-hard.json"))
        assertTrue(names.contains("stages/demo.json"))
        assertTrue(names.contains("stages/demo.lua"))
        assertFalse(names.any { it.startsWith("_modbridge_source/") })
        val chartBytes = ZipInputStream(ByteArrayInputStream(result.bytes)).use { zip ->
            var found: ByteArray? = null
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name == "data/demo/demo-hard.json") found = zip.readBytes()
                zip.closeEntry()
            }
            found ?: error("chart not produced")
        }
        val song = org.json.JSONObject(chartBytes.toString(Charsets.UTF_8)).getJSONObject("song")
        assertEquals("bf-mollusk", song.getString("player1"))
        assertEquals("gary", song.getString("player2"))
        assertEquals("gf-mollusk", song.getString("gfVersion"))
        assertEquals("Alt Animation", song.getJSONArray("notes").getJSONObject(0).getJSONArray("sectionNotes").getJSONArray(0).getString(3))
    }

    @Test fun createsPsychContainerFoldersAndFreeplayOnlyWeek() {
        val input = zip(mapOf(
            "data.json" to """{"bpm":120,"strumLines":[[[{"start":1.0,"duration":0.0}]],[[{"start":2.0,"duration":0.0}]]]}"""
        ))
        val names = entries(ArchiveConverter.convert(input).bytes)
        assertTrue(names.contains("characters/.keep"))
        assertTrue(names.contains("custom_events/.keep"))
        assertTrue(names.contains("custom_notetypes/.keep"))
        assertTrue(names.contains("images/noteSkins/.keep"))
        assertTrue(names.contains("weeks/ModBridge-Freeplay.json"))
        val week = ZipInputStream(ByteArrayInputStream(ArchiveConverter.convert(input).bytes)).use { zip ->
            var value = ""
            while (true) { val entry = zip.nextEntry ?: break; if (entry.name == "weeks/ModBridge-Freeplay.json") value = zip.readBytes().toString(Charsets.UTF_8); zip.closeEntry() }
            org.json.JSONObject(value)
        }
        assertTrue(week.getBoolean("hideStoryMode"))
        assertFalse(week.getBoolean("hideFreeplay"))
    }

    @Test fun optionalSourceBackupCanBeIncluded() {
        val input = zip(mapOf("data/config/modpack.ini" to "[modpack]", "data/states/menu.hx" to "class Menu {}"))
        val names = entries(ArchiveConverter.convert(input, includeSourceBackup = true).bytes)
        assertTrue(names.contains("_modbridge_source/data/states/menu.hx"))
    }

    @Test fun detectsVSliceAndConvertsCommonChartFields() {
        val input = zip(mapOf(
            "data/songs/demo/chart.json" to """{"notes":[{"t":1000,"d":2,"l":250,"mustHit":true}]}""",
            "data/songs/demo/metadata.json" to """{"songName":"Demo","bpm":100}"""
        ))
        val result = ArchiveConverter.convert(input)
        assertEquals("V-Slice", result.source)
        assertEquals(1, result.charts)
        assertTrue(entries(result.bytes).contains("data/demo/demo.json"))
    }
    @Test fun fnmmConvertsChartStageAnimatedCharacterAndTimelineWithoutMusic() {
        val input = zip(mapOf(
            "data.json" to """{"bpm":136,"strumLines":[[[{"start":1.0,"duration":0.5}]],[[{"start":2.0,"duration":0.0}]]]}""",
            "scene.json" to """{"objects":[{"spr":"enemy","strumLine":1,"visible":true,"transform":[{"position":{"x":700,"y":900},"scale":{"x":1,"y":1}}]}]}""",
            "events.json" to """{"events":[{"time":1.5,"actions":[{"type":"ObjectVisibilitySet","props":{"object":0,"value":false}},{"type":"CameraZoom","props":{"value":0.5,"transitionTime":1.0,"transitionTimeUnit":"seconds"}}]},{"time":2.0,"actions":[{"type":"BPMChange","props":{"bpm":140}}]}]}""",
            "sprites/enemy/sprite.json" to """{"type":1,"data":[{"num":"2","spd":1,"spd_fps":true,"loop":true,"offset":{"x":12,"y":8}}]}""",
            "sprites/enemy/0.png" to "fake-png"
        ))
        val result = ArchiveConverter.convert(input, sourceName = "Demo.FNMM")
        val names = entries(result.bytes)
        assertEquals("Funky Maker Mobile", result.source)
        assertEquals(1, result.charts)
        assertTrue(names.contains("data/demo/demo.json"))
        assertTrue(names.contains("stages/fnmm-stage.lua"))
        assertTrue(names.contains("stages/fnmm-stage.json"))
        assertTrue(names.contains("characters/enemy.json"))
        assertTrue(names.contains("data/modbridge-sprites/enemy.json"))
        val characterBytes = ZipInputStream(ByteArrayInputStream(result.bytes)).use { zip ->
            var found: ByteArray? = null
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name == "characters/enemy.json") found = zip.readBytes()
                zip.closeEntry()
            }
            found ?: error("character JSON not produced")
        }
        val character = org.json.JSONObject(characterBytes.toString(Charsets.UTF_8))
        assertEquals("characters/enemy", character.getString("image"))
        assertEquals("idle", character.getJSONArray("animations").getJSONObject(0).getString("anim"))
        assertEquals("fnmm_anim0", character.getJSONArray("animations").getJSONObject(0).getString("name"))
        val chartBytes = ZipInputStream(ByteArrayInputStream(result.bytes)).use { zip ->
            var found: ByteArray? = null
            while (true) { val entry = zip.nextEntry ?: break; if (entry.name == "data/demo/demo.json") found = zip.readBytes(); zip.closeEntry() }
            found ?: error("FNMM chart not produced")
        }
        val song = org.json.JSONObject(chartBytes.toString(Charsets.UTF_8)).getJSONObject("song")
        assertEquals(140.0, song.getJSONArray("notes").getJSONObject(1).getDouble("bpm"))
        assertTrue(result.warnings.any { it.contains("Inst غير موجود") })
    }

    @Test fun vSliceExportsEachDifficultyAndUsesDefaultAlias() {
        val input = zip(mapOf(
            "data/songs/demo/demo-chart.json" to """{"version":"1","scrollSpeed":{"normal":1,"hard":1.2},"notes":{"normal":[{"t":500,"d":5,"l":100}],"hard":[{"t":1000,"d":2,"k":"Hurt Note"}]},"events":[{"t":0,"e":"FocusCamera","v":{"char":0}}]}""",
            "data/songs/demo/demo-metadata.json" to """{"songName":"Demo","artist":"Composer","playData":{"difficulties":["normal","hard"],"characters":{"player":"bf","opponent":"dad","girlfriend":"gf"},"stage":"mainStage"},"timeChanges":[{"t":0,"bpm":120},{"t":4000,"bpm":150}]}""",
            "data/stages/mainStage.json" to """{"cameraZoom":0.8,"characters":{"bf":{"position":[800,130]},"dad":{"position":[90,100]},"gf":{"position":[400,130]}},"props":[]}"""
        ))
        val result = ArchiveConverter.convert(input)
        val names = entries(result.bytes)
        assertEquals("V-Slice", result.source)
        assertEquals(2, result.charts)
        assertTrue(names.contains("data/demo/demo.json"))
        assertTrue(names.contains("data/demo/demo-hard.json"))
        assertTrue(names.contains("stages/stage.json"))
    }

    @Test fun codenameBpmChangeIsConvertedIntoPsychTempoSections() {
        val input = zip(mapOf(
            "songs/demo/charts/hard.json" to """{"codenameChart":true,"stage":"demo","strumLines":[{"position":"bf","notes":[{"id":0,"time":1000,"sLen":0}]}]}""",
            "songs/demo/meta.json" to """{"displayName":"Demo","bpm":120}""",
            "songs/demo/events.json" to """{"events":[{"name":"BPM Change","time":2000,"params":[150]},{"name":"Time Signature Change","time":3000,"params":[3,4]}]}""",
            "data/config/modpack.ini" to "[modpack]"
        ))
        val result = ArchiveConverter.convert(input)
        val output = entries(result.bytes)
        assertTrue(output.contains("data/demo/demo-hard.json"))
        assertTrue(result.warnings.any { it.contains("Time Signature") })
        val chartBytes = ZipInputStream(ByteArrayInputStream(result.bytes)).use { zip ->
            var found: ByteArray? = null
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name == "data/demo/demo-hard.json") found = zip.readBytes()
                zip.closeEntry()
            }
            found ?: error("chart not produced")
        }
        val song = org.json.JSONObject(chartBytes.toString(Charsets.UTF_8)).getJSONObject("song")
        assertEquals(150.0, song.getJSONArray("notes").getJSONObject(1).getDouble("bpm"))
    }

    @Test fun rejectsUnknownModInsteadOfCreatingFalseSuccessArchive() {
        val input = zip(mapOf("random/readme.txt" to "not a supported mod"))
        assertFailsWith<IllegalArgumentException> { ArchiveConverter.convert(input) }
    }

    @Test fun rejectsMismatchedManualSourceEngineSelection() {
        val input = zip(mapOf(
            "data/songs/demo/demo-chart.json" to """{"notes":[{"t":1000,"d":2,"l":250}]}""",
            "data/songs/demo/demo-metadata.json" to """{"songName":"Demo","bpm":100}"""
        ))
        assertFailsWith<IllegalStateException> {
            ArchiveConverter.convert(input, sourceOverride = "Codename Engine")
        }
    }

}
