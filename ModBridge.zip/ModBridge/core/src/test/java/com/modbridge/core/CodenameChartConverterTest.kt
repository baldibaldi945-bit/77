package com.modbridge.core

import kotlin.test.Test
import kotlin.test.assertEquals
import org.json.JSONObject

class CodenameChartConverterTest {
    @Test fun convertsTwoStrumLinesAndSustain() {
        val chart = """{"codenameChart":true,"strumLines":[{"keyCount":4,"position":"dad","notes":[{"id":2,"time":0,"sLen":250,"type":0}]},{"keyCount":4,"position":"bf","notes":[{"id":1,"time":100,"sLen":0,"type":0}]}]}"""
        val meta = """{"displayName":"Demo","bpm":120,"needsVoices":true}"""
        val (out, _) = CodenameChartConverter.convert(chart, meta, "demo", "hard")
        val song = JSONObject(out).getJSONObject("song")
        val section = song.getJSONArray("notes").getJSONObject(0).getJSONArray("sectionNotes")
        assertEquals(2, section.length())
        assertEquals(2, section.getJSONArray(0).getInt(1))
        assertEquals(5, section.getJSONArray(1).getInt(1))
    }
}
