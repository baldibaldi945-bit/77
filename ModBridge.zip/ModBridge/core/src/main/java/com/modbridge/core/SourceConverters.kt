package com.modbridge.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

internal object CodenameConverter {
    fun convert(files: Map<String, ByteArray>, out: MutableMap<String, ByteArray>, warnings: MutableList<String>): Int {
        var convertedCharts = 0
        val chartPaths = files.keys.filter {
            (it.contains("/charts/", true) || it.startsWith("charts/", true)) && it.endsWith(".json", true)
        }
        for (path in chartPaths) {
            val chartCandidate = json(files[path]!!)
            if (chartCandidate == null) { warnings += "$path: JSON غير صالح؛ تم تخطي هذا الشارت فقط."; continue }
            val chart = chartCandidate
            val chartBase = path.substringBeforeLast("/charts/", path.substringBeforeLast('/'))
            val folder = chartBase.substringAfterLast('/')
            val chartsForSong = chartPaths.count { it.substringBeforeLast("/charts/", it.substringBeforeLast('/')) == chartBase }
            val metaPath = path.substringBeforeLast("/charts/", "") + "/meta.json"
            val meta = files[metaPath]?.let { json(it) } ?: JSONObject()
            val bpm = meta.optDouble("bpm", 100.0).takeIf { it > 0 } ?: 100.0
            val lines = chart.optJSONArray("strumLines") ?: JSONArray()
            val notes = mutableListOf<Triple<Double, Int, Double>>()
            val noteTypeNames = chart.optJSONArray("noteTypes") ?: JSONArray()
            val noteTypes = linkedMapOf<Triple<Double, Int, Double>, String>()
            var playerCharacter = "bf"
            var opponentCharacter = "dad"
            var girlfriendCharacter = "gf"
            for (lineIndex in 0 until lines.length()) {
                val line = lines.optJSONObject(lineIndex) ?: continue
                val position = line.optString("position", "").lowercase(Locale.ROOT)
                val characters = line.optJSONArray("characters")
                val primaryCharacter = characters?.optString(0, "")?.takeIf { it.isNotBlank() }?.let { safeName(it) }
                val isPlayer = when (position) {
                    "bf", "boyfriend", "player" -> true
                    "dad", "opponent" -> false
                    else -> lineIndex == 1
                }
                when (position) {
                    "bf", "boyfriend", "player" -> if (primaryCharacter != null) playerCharacter = primaryCharacter
                    "dad", "opponent" -> if (primaryCharacter != null) opponentCharacter = primaryCharacter
                    "gf", "girlfriend" -> if (primaryCharacter != null) girlfriendCharacter = primaryCharacter
                }
                // Psych has no separate girlfriend note lane; do not fold GF notes into opponent lanes.
                if (position == "gf" || position == "girlfriend") continue
                val laneCount = line.optInt("keyCount", 4).coerceAtLeast(1)
                val lineNotes = line.optJSONArray("notes") ?: JSONArray()
                for (i in 0 until lineNotes.length()) {
                    val note = lineNotes.optJSONObject(i) ?: continue
                    val lane = note.optInt("id", 0).coerceIn(0, laneCount - 1) + if (isPlayer) 4 else 0
                    val time = note.optDouble("time", 0.0)
                    val sustain = note.optDouble("sLen", 0.0).coerceAtLeast(0.0)
                    val noteData = Triple(time, lane, sustain)
                    notes += noteData
                    val typeIndex = note.optInt("type", 0)
                    if (typeIndex > 0) {
                        val sourceType = noteTypeNames.optString(typeIndex - 1, "").takeIf { it.isNotBlank() }
                        if (sourceType != null) {
                            val mappedType = when (sourceType.lowercase(Locale.ROOT)) {
                                "alt anim note", "alt animation note" -> "Alt Animation"
                                "hurt note" -> "Hurt Note"
                                "no animation" -> "No Animation"
                                "gf sing" -> "GF Sing"
                                else -> sourceType
                            }
                            noteTypes[noteData] = mappedType
                            if (mappedType == sourceType && mappedType !in setOf("Hurt Note", "No Animation", "GF Sing", "Alt Animation")) {
                                warnings += "$path: نوع النوتة '$sourceType' نُقل باسمه؛ قد يحتاج سكربت custom notetype في Psych."
                            }
                        } else warnings += "$path: note type index $typeIndex غير معرف في noteTypes؛ حُوّلت النوتة بدون نوع."
                    }
                }
            }
            val sourceEvents = chart.optJSONArray("events")
                ?: files[path.substringBeforeLast("/charts/") + "/events.json"]?.let { json(it)?.optJSONArray("events") }
                ?: JSONArray()
            val bpmChanges = mutableListOf<Pair<Double, Double>>()
            val events = convertCodenameEvents(sourceEvents, warnings, path, bpmChanges)
            val slug = safeName(folder)
            val diff = safeName(path.substringAfterLast('/').removeSuffix(".json"))
            val chartTitle = meta.optString("displayName", folder)
            val convertedChart = utf(
                psychChart(
                    chartTitle, bpm, chart.optDouble("scrollSpeed", 1.0), chart.optString("stage", "stage"),
                    playerCharacter, opponentCharacter, notes, events, meta.optBoolean("needsVoices", true),
                    bpmChanges = bpmChanges, noteTypes = noteTypes, girlfriend = girlfriendCharacter
                )
            )
            out["data/$slug/$slug-$diff.json"] = convertedChart
            if (diff.equals("normal", true) || chartsForSong == 1) {
                out.putIfAbsent("data/$slug/$slug.json", convertedChart)
            }
            convertedCharts++
        }

        // Codename XML character definitions -> Psych character JSON.
        for ((path, bytes) in files) {
            if (!path.startsWith("data/characters/", true) || !path.endsWith(".xml", true)) continue
            val xml = bytes.toString(Charsets.UTF_8)
            val headerMatch = Regex("<character\\b([^>]*)>", RegexOption.IGNORE_CASE).find(xml)
            if (headerMatch == null) { warnings += "$path: وسم character غير مفهوم."; continue }
            val header = headerMatch.groupValues[1]
            fun attr(source: String, key: String, default: String = "") =
                Regex("(?:^|\\s)$key=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(source)?.groupValues?.get(1) ?: default
            val id = safeName(path.substringAfterLast('/').removeSuffix(".xml"))
            val sprite = attr(header, "sprite", id).removeSuffix(".png")
            val animations = JSONArray()
            for (match in Regex("<anim\\b([^>]*)/?>", RegexOption.IGNORE_CASE).findAll(xml)) {
                val attrs = match.groupValues[1]
                val name = attr(attrs, "name")
                if (name.isBlank()) continue
                val indices = JSONArray()
                val rawIndices = attr(attrs, "indices")
                if (rawIndices.contains("..")) {
                    val pair = rawIndices.split("..")
                    val first = pair.getOrNull(0)?.toIntOrNull() ?: 0
                    val last = (pair.getOrNull(1)?.toIntOrNull() ?: first).coerceAtMost(first + 500)
                    if (last >= first) for (index in first..last) indices.put(index)
                } else rawIndices.split(',').mapNotNull { it.trim().toIntOrNull() }.forEach { indices.put(it) }
                val offsets = JSONArray().put(attr(attrs, "x", "0").toDoubleOrNull() ?: 0.0).put(attr(attrs, "y", "0").toDoubleOrNull() ?: 0.0)
                animations.put(JSONObject()
                    .put("anim", name)
                    .put("name", attr(attrs, "anim", name))
                    .put("fps", attr(attrs, "fps", "24").toIntOrNull() ?: 24)
                    .put("loop", attr(attrs, "loop", name.contains("idle", true).toString()).toBoolean())
                    .put("indices", indices)
                    .put("offsets", offsets))
            }
            val char = JSONObject()
                .put("image", if (sprite.startsWith("characters/")) sprite else "characters/$sprite")
                .put("healthicon", attr(header, "icon", id))
                .put("scale", attr(header, "scale", "1").toDoubleOrNull() ?: 1.0)
                .put("sing_duration", attr(header, "singDuration", "4").toDoubleOrNull() ?: 4.0)
                .put("camera_position", JSONArray().put(attr(header, "camx", "0").toDoubleOrNull() ?: 0.0).put(attr(header, "camy", "0").toDoubleOrNull() ?: 0.0))
                .put("position", JSONArray().put(attr(header, "x", "0").toDoubleOrNull() ?: 0.0).put(attr(header, "y", "0").toDoubleOrNull() ?: 0.0))
                .put("flip_x", attr(header, "flipX", "false").toBoolean())
                .put("no_antialiasing", attr(header, "antialiasing", "true").equals("false", true))
                .put("animations", animations)
            out["characters/$id.json"] = utf(char.toString(2))
            if (animations.length() == 0) warnings += "$path: تم إنشاء JSON للشخصية، لكن لا توجد تعريفات animation قابلة للتحويل."
        }

        // Codename XML stage -> Psych Lua stage script.
        for ((path, bytes) in files) {
            if (!path.startsWith("data/stages/", true) || !path.endsWith(".xml", true)) continue
            val xml = bytes.toString(Charsets.UTF_8)
            val stage = safeName(path.substringAfterLast('/').removeSuffix(".xml"))
            val header = Regex("<stage\\b([^>]*)>", RegexOption.IGNORE_CASE).find(xml)?.groupValues?.get(1) ?: ""
            fun attr(source: String, key: String, default: String = "") =
                Regex("(?:^|\\s)$key=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(source)?.groupValues?.get(1) ?: default
            fun luaString(value: String) = value.replace("\\", "\\\\").replace("'", "\\'")
            val folder = attr(header, "folder").trimEnd('/')
            val sb = StringBuilder("-- Converted from Codename Engine stage XML\nfunction onCreate()\n")
            val spriteRegex = Regex("<sprite\\b([^>]*)/?>", RegexOption.IGNORE_CASE)
            for ((index, match) in spriteRegex.findAll(xml).withIndex()) {
                val attrs = match.groupValues[1]
                val name = attr(attrs, "name", "sprite$index")
                val image = attr(attrs, "sprite", attr(attrs, "path", attr(attrs, "image", name))).removeSuffix(".png")
                val asset = listOf(folder, image).filter { it.isNotBlank() }.joinToString("/").replace(Regex("/+"), "/")
                val x = attr(attrs, "x", "0").toDoubleOrNull() ?: 0.0
                val y = attr(attrs, "y", "0").toDoubleOrNull() ?: 0.0
                val scale = attr(attrs, "scale", "1").toDoubleOrNull() ?: 1.0
                val sx = attr(attrs, "scaleX", attr(attrs, "scalex", scale.toString())).toDoubleOrNull() ?: scale
                val sy = attr(attrs, "scaleY", attr(attrs, "scaley", scale.toString())).toDoubleOrNull() ?: scale
                val scrollX = attr(attrs, "scrollX", attr(attrs, "scroll", "1")).toDoubleOrNull() ?: 1.0
                val scrollY = attr(attrs, "scrollY", attr(attrs, "scroll", "1")).toDoubleOrNull() ?: 1.0
                val front = attr(attrs, "front", "false").toBoolean()
                sb.append("makeLuaSprite('").append(luaString(name)).append("','").append(luaString(asset)).append("',").append(x).append(',').append(y).append(")\n")
                sb.append("setScrollFactor('").append(luaString(name)).append("',").append(scrollX).append(',').append(scrollY).append(")\n")
                sb.append("scaleObject('").append(luaString(name)).append("',").append(sx).append(',').append(sy).append(")\n")
                sb.append("addLuaSprite('").append(luaString(name)).append("',").append(front).append(")\n")
            }
            sb.append("end\n\nfunction onCreatePost()\n")
            val zoom = attr(header, "zoom", "0.9").toDoubleOrNull() ?: 0.9
            sb.append("setProperty('defaultCamZoom', ").append(zoom).append(")\n")
            for ((role, psychRole, defaultPosition) in listOf(
                Triple("bf", "boyfriend", 770.0 to 100.0),
                Triple("gf", "gf", 400.0 to 130.0),
                Triple("dad", "dad", 100.0 to 100.0)
            )) {
                val roleAttrs = Regex("<$role\\b([^>]*)/?>", RegexOption.IGNORE_CASE).find(xml)?.groupValues?.get(1) ?: continue
                val x = attr(roleAttrs, "x", defaultPosition.first.toString()).toDoubleOrNull() ?: defaultPosition.first
                val y = attr(roleAttrs, "y", defaultPosition.second.toString()).toDoubleOrNull() ?: defaultPosition.second
                sb.append("setProperty('").append(psychRole).append(".x', ").append(x).append(")\n")
                sb.append("setProperty('").append(psychRole).append(".y', ").append(y).append(")\n")
            }
            sb.append("end\n")
            val stagePositions = JSONObject()
            for ((sourceRole, psychRole, defaults) in listOf(
                Triple("bf", "boyfriend", 770.0 to 100.0),
                Triple("dad", "opponent", 100.0 to 100.0),
                Triple("gf", "girlfriend", 400.0 to 130.0)
            )) {
                val roleAttrs = Regex("<$sourceRole\\b([^>]*)/?>", RegexOption.IGNORE_CASE).find(xml)?.groupValues?.get(1) ?: ""
                stagePositions.put(psychRole, JSONArray().put(attr(roleAttrs, "x", defaults.first.toString()).toDoubleOrNull() ?: defaults.first).put(attr(roleAttrs, "y", defaults.second.toString()).toDoubleOrNull() ?: defaults.second))
            }
            val stageData = JSONObject()
                .put("directory", "")
                .put("defaultZoom", zoom)
                .put("isPixelStage", attr(header, "isPixelStage", attr(header, "pixelStage", "false")).toBoolean())
                .put("boyfriend", stagePositions.optJSONArray("boyfriend"))
                .put("opponent", stagePositions.optJSONArray("opponent"))
                .put("girlfriend", stagePositions.optJSONArray("girlfriend"))
                .put("hide_girlfriend", false)
                .put("camera_boyfriend", JSONArray().put(0).put(0))
                .put("camera_opponent", JSONArray().put(0).put(0))
                .put("camera_girlfriend", JSONArray().put(0).put(0))
                .put("camera_speed", 1.0)
            out["stages/$stage.json"] = utf(stageData.toString(2))
            out["stages/$stage.lua"] = utf(sb.toString())
        }

        if (convertedCharts == 0) warnings += "Codename Engine: لم أعثر على شارتات قابلة للقراءة؛ استمر تحويل الشخصيات والستاجات والأصول الموجودة."
        return convertedCharts
    }

    private fun convertCodenameEvents(
        source: JSONArray,
        warnings: MutableList<String>,
        path: String,
        bpmChanges: MutableList<Pair<Double, Double>>
    ): JSONArray {
        val output = JSONArray()
        for (index in 0 until source.length()) {
            val event = source.optJSONObject(index) ?: continue
            val name = event.optString("name", event.optString("event", ""))
            val time = event.optDouble("time", event.optDouble("timestamp", 0.0))
            val params = event.optJSONArray("params") ?: JSONArray()
            val v1 = params.opt(0)?.toString() ?: ""
            val v2 = params.opt(1)?.toString() ?: ""
            when (name.lowercase(Locale.ROOT)) {
                "camera movement" -> {
                    output.put(JSONArray().put(time).put(JSONArray().put("Camera Follow Pos").put(params.opt(5)?.toString() ?: "").put(params.opt(6)?.toString() ?: "")))
                    warnings += "$path: Camera Movement حُوّل إلى Camera Follow Pos؛ انتقال الحركة ومدته المصدرية لا يُعاد تمثيلهما بالكامل."
                }
                "camera zoom" -> {
                    output.put(JSONArray().put(time).put(JSONArray().put("Set Property").put("camGame.zoom").put(params.opt(1)?.toString() ?: "1")))
                    warnings += "$path: Camera Zoom حُوّل إلى Set Property فوري؛ مدة الـtween الأصلية لم تُحوّل."
                }
                "bpm change" -> {
                    val newBpm = params.opt(0)?.toString()?.toDoubleOrNull()
                    if (newBpm != null && newBpm.isFinite() && newBpm > 0 && time > 0) bpmChanges += time to newBpm
                    else warnings += "$path: BPM Change بقيمة غير صالحة؛ تم تجاهله."
                }
                "time signature change" -> warnings += "$path: تغيير Time Signature لا يملك تمثيلاً مطابقاً في مخطط Psych القياسي؛ تم إسقاطه."
                else -> {
                    if (name.isNotBlank()) {
                        output.put(JSONArray().put(time).put(JSONArray().put(name).put(v1).put(v2)))
                        warnings += "$path: الحدث '$name' نُقل باسمه وبارامتراته؛ تأكد من وجود Event مماثل في Psych."
                    }
                }
            }
        }
        return output
    }
}

internal object FnmmConverter {
    fun convert(files: Map<String, ByteArray>, out: MutableMap<String, ByteArray>, warnings: MutableList<String>, sourceName: String? = null): Int {
        fun entry(name: String) = files.entries.firstOrNull { it.key.substringAfterLast('/').equals(name, true) }?.value
        val data = entry("data.json")?.let { json(it) }
        val scene = entry("scene.json")?.let { json(it) } ?: JSONObject()
        val eventRoot = entry("events.json")?.let { json(it) } ?: JSONObject()
        val sceneObjects = scene.optJSONArray("objects") ?: JSONArray()
        val fallbackName = sourceName?.substringAfterLast('/')?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: "fnmm-song"
        val songName = safeName(data?.let { it.optString("songName", it.optString("name", fallbackName)) } ?: fallbackName)
        val bpm = (data?.optDouble("bpm", 100.0) ?: 100.0).takeIf { it.isFinite() && it > 0 } ?: 100.0
        val noteTriples = mutableListOf<Triple<Double, Int, Double>>()
        val strumLines = data?.optJSONArray("strumLines") ?: JSONArray()
        for (side in 0 until strumLines.length()) {
            val lanes = strumLines.optJSONArray(side) ?: continue
            for (lane in 0 until lanes.length()) {
                val laneNotes = lanes.optJSONArray(lane) ?: continue
                for (i in 0 until laneNotes.length()) {
                    val note = laneNotes.optJSONObject(i) ?: continue
                    val time = note.optDouble("start", note.optDouble("time", Double.NaN)) * 1000.0
                    val sustain = note.optDouble("duration", note.optDouble("length", 0.0)).coerceAtLeast(0.0) * 1000.0
                    if (!time.isFinite() || time < 0) continue
                    // In the FNMM sample format strumLine 0 is the player and 1 is the opponent.
                    val psychLane = lane.coerceIn(0, 3) + if (side == 0) 4 else 0
                    noteTriples += Triple(time, psychLane, sustain)
                }
            }
        }
        // FNMM event exports may store timeline time in seconds (common) or milliseconds.
        // Inspect every events.json file instead of assuming one root-level event file.
        val fnmmBpmChanges = mutableListOf<Pair<Double, Double>>()
        val maxNoteTimeSeconds = (noteTriples.maxOfOrNull { it.first } ?: 0.0) / 1000.0
        for ((eventPath, eventBytes) in files) {
            if (!eventPath.substringAfterLast('/').equals("events.json", true)) continue
            val root = json(eventBytes) ?: continue
            val events = root.optJSONArray("events") ?: continue
            for (eventIndex in 0 until events.length()) {
                val event = events.optJSONObject(eventIndex) ?: continue
                val rawTime = event.opt("time")?.toString()?.toDoubleOrNull()
                    ?: event.opt("timestamp")?.toString()?.toDoubleOrNull()
                    ?: event.opt("t")?.toString()?.toDoubleOrNull()
                    ?: Double.NaN
                // A time much larger than the song duration is already expressed in ms.
                val timeMs = when {
                    !rawTime.isFinite() || rawTime < 0 -> Double.NaN
                    rawTime > maxNoteTimeSeconds * 10.0 && rawTime >= 100.0 -> rawTime
                    else -> rawTime * 1000.0
                }
                val actions = event.optJSONArray("actions") ?: continue
                for (actionIndex in 0 until actions.length()) {
                    val action = actions.optJSONObject(actionIndex) ?: continue
                    val type = action.optString("type", "").trim()
                        .replace(" ", "").replace("_", "").lowercase(Locale.ROOT)
                    if (type !in setOf("bpmchange", "setbpm", "changetempo", "settempo")) continue
                    val props = action.optJSONObject("props") ?: action.optJSONObject("parameters") ?: JSONObject()
                    val value = listOf("bpm", "value", "newBpm", "newValue", "tempo")
                        .firstNotNullOfOrNull { key ->
                            props.opt(key)?.toString()?.toDoubleOrNull()?.takeIf { it.isFinite() && it > 0 }
                        } ?: Double.NaN
                    if (timeMs.isFinite() && timeMs > 0 && value.isFinite() && value > 0) {
                        fnmmBpmChanges += timeMs to value
                    } else {
                        warnings += "FNMM: حدث تغيير BPM غير صالح في $eventPath عند الحدث $eventIndex/$actionIndex؛ تم تجاهيله."
                    }
                }
            }
        }
        val sortedFnmmBpmChanges = fnmmBpmChanges.distinct().sortedBy { it.first }
        var charts = 0
        if (data != null && noteTriples.isNotEmpty()) {
            val sideIds = MutableList(2) { if (it == 0) "bf" else "dad" }
            for (i in 0 until sceneObjects.length()) {
                val obj = sceneObjects.optJSONObject(i) ?: continue
                val side = obj.optInt("strumLine", -1)
                val spriteId = safeName(obj.optString("spr", if (side == 0) "player" else "enemy"))
                val descriptor = files.entries.firstOrNull { it.key.equals("sprites/$spriteId/sprite.json", true) }?.value?.let { json(it) }
                if (side in 0..1 && descriptor?.optInt("type", 0) == 1) sideIds[side] = spriteId
            }
            val chartSong = psychChart(
                data.optString("displayName", fallbackName), bpm,
                data.optDouble("scrollSpeed", 1.0), "fnmm-stage",
                sideIds[0], sideIds[1], noteTriples, JSONArray(), true,
                bpmChanges = sortedFnmmBpmChanges
            )
            // Re-apply tempo at each generated section boundary. This also covers chart files
            // where the source event time is rounded to the nearest Psych step boundary.
            val chartRoot = JSONObject(chartSong)
            val songObject = chartRoot.optJSONObject("song")
            val sections = songObject?.optJSONArray("notes")
            if (sections != null) {
                var sectionTimeMs = 0.0
                var activeBpm = bpm.takeIf { it.isFinite() && it > 0 } ?: 100.0
                var previousBpm = activeBpm
                var changeIndex = 0
                for (sectionIndex in 0 until sections.length()) {
                    val stepMs = 60000.0 / activeBpm / 4.0
                    while (changeIndex < sortedFnmmBpmChanges.size &&
                        sortedFnmmBpmChanges[changeIndex].first <= sectionTimeMs + stepMs * 0.5) {
                        activeBpm = sortedFnmmBpmChanges[changeIndex].second
                        changeIndex++
                    }
                    val section = sections.optJSONObject(sectionIndex) ?: continue
                    section.put("bpm", activeBpm)
                    section.put("changeBPM", kotlin.math.abs(activeBpm - previousBpm) > 0.0001)
                    previousBpm = activeBpm
                    sectionTimeMs += (60000.0 / activeBpm / 4.0) *
                        section.optInt("lengthInSteps", 16).coerceIn(1, 64)
                }
            }
            val chartBytes = utf(chartRoot.toString(2))
            out["data/$songName/$songName-hard.json"] = chartBytes
            out["data/$songName/$songName.json"] = chartBytes
            charts++
        } else if (data == null) {
            warnings += "FNMM: data.json غير موجود أو غير صالح؛ استمر تحويل المشهد والأحداث والأصول."
        } else {
            warnings += "FNMM: data.json موجود لكن لم أجد نوتات صالحة؛ استمر تحويل باقي المود."
        }

        // Copy each source sprite and its descriptor to a neutral staging area. The Android
        // atlas builder splits real FNMM horizontal strips using data[i].num.
        val spriteFolders = linkedSetOf<String>()
        for (path in files.keys) {
            if (!path.startsWith("sprites/", true)) continue
            val parts = path.split('/')
            if (parts.size >= 3) spriteFolders += parts[1]
        }
        for (rawId in spriteFolders) {
            val id = safeName(rawId)
            val manifestEntry = files.entries.firstOrNull { it.key.equals("sprites/$rawId/sprite.json", true) }
            val manifest = manifestEntry?.value?.let { json(it) }
            val imageFiles = files.keys.filter { it.startsWith("sprites/$rawId/", true) && it.endsWith(".png", true) }
            if (manifest == null) {
                warnings += "FNMM sprite '$id': ملف sprite.json مفقود؛ تم نسخ الصور الثابتة المتاحة فقط."
                val png = imageFiles.firstOrNull { it.substringAfterLast('/').substringBeforeLast('.').toIntOrNull() == 0 }
                    ?.let { files[it] }
                if (png != null) out["images/$id.png"] = png
                continue
            }
            val type = manifest.optInt("type", 0)
            if (type == 1) {
                out["data/modbridge-sprites/$id.json"] = utf(manifest.toString())
                for (path in imageFiles) {
                    val index = path.substringAfterLast('/').substringBeforeLast('.').toIntOrNull() ?: continue
                    val bytes = files[path] ?: continue
                    out["images/$id/$index.png"] = bytes
                    if (index == 0) {
                        out.putIfAbsent("images/$id.png", bytes)
                        out.putIfAbsent("images/characters/$id.png", bytes)
                    }
                }
                if (imageFiles.isEmpty()) warnings += "FNMM sprite '$id': تعريف متحرك دون صور PNG؛ سيظهر كعنصر مفقود."
            } else {
                val first = imageFiles.sortedBy { it.substringAfterLast('/').substringBeforeLast('.').toIntOrNull() ?: Int.MAX_VALUE }.firstOrNull()
                if (first != null) out["images/$id.png"] = files[first]!!
                imageFiles.drop(1).forEachIndexed { index, path -> out["images/${id}_${index + 1}.png"] = files[path]!! }
            }
        }

        fun luaQ(value: String) = value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        fun luaNum(value: Double) = if (value.isFinite()) value.toString() else "0"
        fun manifestFor(id: String) = files.entries.firstOrNull { it.key.equals("sprites/$id/sprite.json", true) }?.value?.let { json(it) }
        fun firstTransform(obj: JSONObject): JSONObject = obj.optJSONArray("transform")?.optJSONObject(0)
            ?: obj.optJSONObject("transform") ?: JSONObject()
        fun pos(transform: JSONObject): JSONObject = transform.optJSONObject("position") ?: JSONObject()
        fun scale(transform: JSONObject): JSONObject = transform.optJSONObject("scale") ?: JSONObject()
        fun scroll(transform: JSONObject): JSONObject = transform.optJSONObject("scrollFactor") ?: JSONObject()

        val objectTags = mutableListOf<String>()
        val characterTags = mutableMapOf<Int, String>()
        val objectInfo = mutableListOf<JSONObject>()
        val characterLua = StringBuilder()
        val lua = StringBuilder("-- FNMM conversion. Unsupported scene UI is intentionally not ported.\nlocal mbEvents = {}\nlocal mbEventIndex = 1\nfunction onCreate()\n")
        for (index in 0 until sceneObjects.length()) {
            val obj = sceneObjects.optJSONObject(index) ?: continue
            objectInfo += obj
            val rawId = obj.optString("spr", obj.optString("name", "object$index"))
            val id = safeName(rawId)
            val tag = "mb_${id}_$index"
            val transform = firstTransform(obj)
            val position = pos(transform)
            val size = scale(transform)
            val scrollFactor = scroll(transform)
            val sourceX = position.optDouble("x", 0.0)
            val sourceY = position.optDouble("y", 0.0)
            val fixed = obj.optBoolean("fixed", false)
            // FNMM scenes use a 2160×1920-ish portrait authoring canvas. Psych's gameplay
            // view is landscape. Keep source coordinates by default; report the mismatch.
            val x = if (fixed && sourceX in 0.0..1.0) sourceX * 1280.0 else sourceX
            val y = if (fixed && sourceY in 0.0..1.0) sourceY * 720.0 else sourceY
            val sx = size.optDouble("x", 1.0)
            val sy = size.optDouble("y", 1.0)
            val alpha = obj.optDouble("opacity", 1.0).coerceIn(0.0, 1.0)
            val visible = obj.optBoolean("visible", true)
            val sprite = manifestFor(id)
            val type = sprite?.optInt("type", 0) ?: 0
            val animationData = sprite?.optJSONArray("data") ?: JSONArray()
            val strumLine = obj.optInt("strumLine", -1)
            if (strumLine in 0..1 && type == 1) {
                val role = if (strumLine == 0) "boyfriend" else "dad"
                characterTags[index] = role
                val charJson = JSONObject()
                    .put("image", "characters/$id").put("healthicon", id).put("scale", 1)
                    .put("sing_duration", 4).put("camera_position", JSONArray().put(0).put(0))
                    .put("position", JSONArray().put(0).put(0)).put("flip_x", sx < 0)
                    .put("no_antialiasing", false).put("animations", buildFnmmAnimations(animationData))
                out["characters/$id.json"] = utf(charJson.toString(2))
                characterLua.append("setProperty('$role.x', ${luaNum(x)})\nsetProperty('$role.y', ${luaNum(y)})\n")
                characterLua.append("setProperty('$role.alpha', ${luaNum(alpha)})\nsetProperty('$role.visible', $visible)\n")
                characterLua.append("setProperty('$role.scale.x', ${luaNum(kotlin.math.abs(sx))})\nsetProperty('$role.scale.y', ${luaNum(kotlin.math.abs(sy))})\n")
                if (sx < 0) characterLua.append("setProperty('$role.flipX', true)\n")
                continue
            }
            objectTags += tag
            if (type == 1 && animationData.length() > 0) {
                lua.append("makeAnimatedLuaSprite('$tag','$id',${luaNum(x)},${luaNum(y)})\n")
                for (a in 0 until animationData.length()) {
                    val anim = animationData.optJSONObject(a) ?: continue
                    val animName = "fnmm_anim$a"
                    val spd = anim.optDouble("spd", 1.0).coerceIn(0.1, 8.0)
                    val fps = (if (anim.optBoolean("spd_fps", false)) spd else 24.0 * spd).toInt().coerceIn(1, 120)
                    lua.append("addAnimationByPrefix('$tag','$animName','$animName',$fps,${anim.optBoolean("loop", true)})\n")
                }
                lua.append("objectPlayAnimation('$tag','fnmm_anim0',true)\n")
            } else {
                lua.append("makeLuaSprite('$tag','$id',${luaNum(x)},${luaNum(y)})\n")
            }
            val scrollX = if (fixed) 0.0 else scrollFactor.optDouble("x", 1.0)
            val scrollY = if (fixed) 0.0 else scrollFactor.optDouble("y", 1.0)
            lua.append("setScrollFactor('$tag',${luaNum(scrollX)},${luaNum(scrollY)})\n")
            lua.append("scaleObject('$tag',${luaNum(kotlin.math.abs(sx))},${luaNum(kotlin.math.abs(sy))})\n")
            if (sx < 0) lua.append("setProperty('$tag.flipX',true)\n")
            lua.append("setProperty('$tag.alpha',${luaNum(alpha)})\nsetProperty('$tag.visible',$visible)\n")
            if (fixed) lua.append("setObjectCamera('$tag','hud')\n")
            lua.append("addLuaSprite('$tag',false)\n")
        }
        lua.append("end\n\n")
        if (characterLua.isNotBlank()) lua.append("function onCreatePost()\n").append(characterLua).append("end\n\n")

        // Map FNMM timeline action indices to source object order.
        fun targetTag(index: Int): String? {
            val role = characterTags[index]
            if (role != null) return role
            return objectTags.getOrNull(index - characterTags.keys.count { it < index })
        }
        val eventArray = eventRoot.optJSONArray("events") ?: JSONArray()
        val timeline = mutableListOf<Pair<Double, String>>()
        var supportedActions = 0
        var skippedActions = 0
        fun durationSeconds(props: JSONObject): Double {
            val raw = props.optDouble("transitionTime", props.optDouble("duration", 0.0)).coerceAtLeast(0.0)
            val unit = props.optString("transitionTimeUnit", props.optString("timeUnit", "seconds"))
            return if (unit.equals("milliseconds", true) || unit.equals("ms", true)) raw / 1000.0 else raw
        }
        for (eventIndex in 0 until eventArray.length()) {
            val event = eventArray.optJSONObject(eventIndex) ?: continue
            val eventTime = event.optDouble("time", 0.0)
            val actions = event.optJSONArray("actions") ?: JSONArray()
            for (actionIndex in 0 until actions.length()) {
                val action = actions.optJSONObject(actionIndex) ?: continue
                val type = action.optString("type", "")
                val props = action.optJSONObject("props") ?: JSONObject()
                val seconds = if (eventTime.isFinite() && eventTime >= 0) eventTime else continue
                val timeMs = seconds * 1000.0
                if (type.equals("BPMChange", true) || type.equals("BPM Change", true) || type.equals("SetBPM", true)) {
                    supportedActions++
                    continue
                }
                val code = when (type) {
                    "ObjectVisibilitySet" -> {
                        val target = targetTag(props.optInt("object", -1))
                        if (target == null) null else "setProperty('$target.visible',${props.optBoolean("value", true)})"
                    }
                    "ObjectAnimationSet" -> {
                        val target = targetTag(props.optInt("object", -1))
                        val anim = props.optInt("anim", 0).coerceAtLeast(0)
                        if (target == null) null else if (target == "boyfriend" || target == "dad") {
                            "characterPlayAnim('${if (target == "boyfriend") "bf" else "dad"}','${fnmmAnimationName(anim)}',true)"
                        } else "objectPlayAnimation('$target','fnmm_anim$anim',true)"
                    }
                    "CameraZoom" -> {
                        // FNMM stores this as a 0..1 zoom intensity, not a Psych absolute zoom.
                        // Convert it into a small offset from the current chart camera zoom.
                        val value = "(getProperty('defaultCamZoom') + ${luaNum(props.optDouble("value", 0.0) * 0.1)})"
                        val duration = durationSeconds(props)
                        val easing = psychEase(props.optString("easingType", "linear"))
                        if (duration <= 0) "setProperty('camGame.zoom',$value)"
                        else "doTweenZoom('mb_fnmm_zoom_$eventIndex-$actionIndex','camGame',$value,${luaNum(duration)},'$easing')"
                    }
                    "CameraSet" -> {
                        val mode = props.optString("mode", "auto")
                        if (mode.equals("auto", true)) "setProperty('isCameraOnForcedPos',false)"
                        else {
                            val target = props.optInt("target", -1)
                            val tag = targetTag(target)
                            if (tag == null) null else "triggerEvent('Camera Follow Pos',tostring(getMidpointX('$tag')),tostring(getMidpointY('$tag')))"
                        }
                    }
                    "ScreenFlash" -> {
                        val r = props.optInt("color_r", 255).coerceIn(0, 255)
                        val g = props.optInt("color_g", 255).coerceIn(0, 255)
                        val b = props.optInt("color_b", 255).coerceIn(0, 255)
                        val hex = "%02X%02X%02X".format(Locale.ROOT, r, g, b)
                        val alpha = props.optDouble("alpha", 1.0).coerceIn(0.0, 1.0)
                        val duration = durationSeconds(props).takeIf { it > 0 } ?: props.optDouble("duration", 0.2).coerceAtLeast(0.05)
                        val tag = "mb_flash_$eventIndex-$actionIndex"
                        "makeLuaSprite('$tag','',0,0); makeGraphic('$tag',1280,720,'$hex'); setObjectCamera('$tag','hud'); setProperty('$tag.alpha',${luaNum(alpha)}); addLuaSprite('$tag',true); doTweenAlpha('${tag}_fade','$tag',0,${luaNum(duration)},'linear')"
                    }
                    "GUI" -> "setProperty('camHUD.alpha',${if (props.optBoolean("visible", true)) "1" else "0"})"
                    else -> null
                }
                if (code != null) {
                    timeline += timeMs to code
                    supportedActions++
                } else {
                    skippedActions++
                    warnings += "FNMM: حدث '$type' لم يُحوّل لأنه لا يملك مقابلاً آمناً في Psych."
                }
            }
        }
        timeline.sortBy { it.first }
        if (timeline.isNotEmpty()) {
            lua.append("local mbEvents = {\n")
            timeline.forEach { (time, code) -> lua.append("{t=${luaNum(time)},f=function() $code end},\n") }
            lua.append("}\nlocal mbEventIndex = 1\nfunction onUpdate(elapsed)\n  local now = getSongPosition()\n  while mbEvents[mbEventIndex] and now >= mbEvents[mbEventIndex].t do\n    mbEvents[mbEventIndex].f()\n    mbEventIndex = mbEventIndex + 1\n  end\nend\n")
        }
        if (objectInfo.any { obj ->
                val coordinate = runCatching { firstTransform(obj).optJSONObject("position")?.optDouble("x", 0.0) }.getOrNull()
                obj.optBoolean("fixed", false) && coordinate != null && coordinate in 0.0..1.0
            }) {
            warnings += "FNMM: بعض عناصر HUD ثابتة الإحداثيات (0..1) حُوّلت إلى إحداثيات شاشة Psych 1280×720؛ راجع تموضعها داخل اللعبة."
        }
        warnings += "FNMM: أسماء حركات الشخصية استنتجت حسب ترتيب فهارس الإطارات (0=idle، 1-4=sing)؛ راجعها إذا كان ترتيب المود مختلفاً."
        if ((0 until sceneObjects.length()).any { index ->
                val obj = sceneObjects.optJSONObject(index) ?: return@any false
                val p = pos(firstTransform(obj))
                kotlin.math.abs(p.optDouble("x", 0.0)) > 1280.0 || kotlin.math.abs(p.optDouble("y", 0.0)) > 720.0
            }) warnings += "FNMM: بعض إحداثيات المشهد تتجاوز مساحة Psych الافتراضية 1280×720؛ تم الاحتفاظ بها دون تحجيم تلقائي لتجنب تغيير مواضع المود عشوائياً."
        if (eventArray.length() > 0 && (0 until eventArray.length()).any { i ->
                val event = eventArray.optJSONObject(i) ?: return@any false
                val actions = event.optJSONArray("actions") ?: return@any false
                (0 until actions.length()).any { actions.optJSONObject(it)?.optString("type") == "CameraZoom" }
            }) warnings += "FNMM: تحويل CameraZoom يستخدم تقريباً محافظاً (+10% من قيمة المصدر كإزاحة) لأن مقياس الزوم يختلف بين المحركين."
        warnings += "FNMM: حُوّلت $supportedActions حدثاً/إجراءً زمنياً؛ تم تجاوز $skippedActions إجراء غير مدعوم."
        if (sceneObjects.length() > 0 || timeline.isNotEmpty()) {
            val playerObject = (0 until sceneObjects.length()).mapNotNull { sceneObjects.optJSONObject(it) }.firstOrNull { it.optInt("strumLine", -1) == 0 }
            val opponentObject = (0 until sceneObjects.length()).mapNotNull { sceneObjects.optJSONObject(it) }.firstOrNull { it.optInt("strumLine", -1) == 1 }
            fun stagePosition(obj: JSONObject?, defaultX: Double, defaultY: Double): JSONArray {
                if (obj == null) return JSONArray().put(defaultX).put(defaultY)
                val transform = obj.optJSONArray("transform")?.optJSONObject(0) ?: obj.optJSONObject("transform") ?: JSONObject()
                val p = transform.optJSONObject("position") ?: JSONObject()
                return JSONArray().put(p.optDouble("x", defaultX)).put(p.optDouble("y", defaultY))
            }
            val stageData = JSONObject()
                .put("directory", "")
                .put("defaultZoom", 0.9)
                .put("isPixelStage", false)
                .put("boyfriend", stagePosition(playerObject, 770.0, 100.0))
                .put("opponent", stagePosition(opponentObject, 100.0, 100.0))
                .put("girlfriend", JSONArray().put(400).put(130))
                .put("hide_girlfriend", false)
                .put("camera_boyfriend", JSONArray().put(0).put(0))
                .put("camera_opponent", JSONArray().put(0).put(0))
                .put("camera_girlfriend", JSONArray().put(0).put(0))
                .put("camera_speed", 1.0)
            out["stages/fnmm-stage.json"] = utf(stageData.toString(2))
            out["stages/fnmm-stage.lua"] = utf(lua.toString())
        }
        if (sceneObjects.length() == 0) warnings += "FNMM: scene.json فارغ أو مفقود؛ تم إنشاء الشارت والأصول المتاحة فقط."
        return charts
    }

    private fun buildFnmmAnimations(source: JSONArray): JSONArray {
        val animations = JSONArray()
        for (i in 0 until source.length()) {
            val item = source.optJSONObject(i) ?: continue
            val speed = item.optDouble("spd", 1.0).coerceIn(0.1, 8.0)
            val fps = (if (item.optBoolean("spd_fps", false)) speed else 24.0 * speed).toInt().coerceIn(1, 120)
            val offset = item.optJSONObject("offset") ?: JSONObject()
            animations.put(JSONObject()
                .put("anim", fnmmAnimationName(i)).put("name", "fnmm_anim$i")
                .put("fps", fps).put("loop", item.optBoolean("loop", true))
                .put("offsets", JSONArray().put(offset.optDouble("x", 0.0)).put(offset.optDouble("y", 0.0))))
        }
        return animations
    }

    private fun fnmmAnimationName(index: Int): String = when (index) {
        0 -> "idle"
        1 -> "singLEFT"
        2 -> "singDOWN"
        3 -> "singUP"
        4 -> "singRIGHT"
        5 -> "singLEFTmiss"
        6 -> "singRIGHTmiss"
        else -> "fnmm_anim$index"
    }

    private fun psychEase(source: String): String = when (source.lowercase(Locale.ROOT)) {
        "default", "linear", "none" -> "linear"
        "easein", "quad.in" -> "quadIn"
        "easeout", "quad.out" -> "quadOut"
        "easeinout", "quad.inout" -> "quadInOut"
        "cube.in" -> "cubeIn"
        "cube.out" -> "cubeOut"
        "cube.inout" -> "cubeInOut"
        "sine.in" -> "sineIn"
        "sine.out" -> "sineOut"
        "sine.inout" -> "sineInOut"
        else -> "linear"
    }
}

internal object VSliceConverter {
    fun convert(files: Map<String, ByteArray>, out: MutableMap<String, ByteArray>, warnings: MutableList<String>): Int {
        var converted = 0
        val candidates = files.keys.filter { path ->
            path.endsWith(".json", true) && (path.substringAfterLast('/').contains("chart", true) || json(files[path]!!)?.optJSONObject("notes") != null)
        }
        for (path in candidates) {
            val root = json(files[path]!!) ?: continue
            val parent = path.substringBeforeLast('/', "")
            val metadataPath = files.keys.firstOrNull {
                it.substringBeforeLast('/', "") == parent && it.substringAfterLast('/').contains("metadata", true)
            }
            val metadata = metadataPath?.let { json(files[it]!!) } ?: JSONObject()
            val playData = metadata.optJSONObject("playData") ?: JSONObject()
            val characters = playData.optJSONObject("characters") ?: JSONObject()
            val noteStyleId = playData.optString("noteStyle", "").trim()
            if (noteStyleId.isNotBlank() && !noteStyleId.equals("funkin", true)) {
                val styleFile = files.keys.firstOrNull { candidate ->
                    candidate.endsWith("/notestyles/$noteStyleId.json", true) ||
                        candidate.equals("notestyles/$noteStyleId.json", true)
                }
                val styleJson = styleFile?.let { json(files[it]!!) }
                val styleAssets = styleJson?.optJSONObject("assets")
                val assetNames = listOf("note", "noteStrumline", "holdNote", "noteSplash", "holdNoteCover")
                val declared = assetNames.filter { key ->
                    val asset = styleAssets?.optJSONObject(key) ?: return@filter false
                    asset.optString("assetPath").isNotBlank() || ((asset.optJSONObject("data")?.length() ?: 0) > 0)
                }
                warnings += if (styleJson == null) {
                    "$path: الشارت يشير إلى noteStyle مخصص '$noteStyleId' لكن ملف وصف النمط غير موجود؛ لم أقم بتخمين ملفات الأسهم أو الـsplash."
                } else {
                    "$path: تم التعرف على noteStyle '$noteStyleId' (${declared.joinToString()}). نقل صور الأصول المتاحة لا يدمج تلقائياً مجموعات note/hold/splash في أطالس Psych؛ راجع conversion-report.txt."
                }
            }
            val chartNotes = root.optJSONObject("notes")
            val flatNotes = root.optJSONArray("notes")
            val listedDifficulties = playData.optJSONArray("difficulties")
            val difficulties = buildList {
                if (listedDifficulties != null) {
                    for (i in 0 until listedDifficulties.length()) {
                        val diff = listedDifficulties.optString(i).trim()
                        if (diff.isNotBlank()) add(diff)
                    }
                }
                if (isEmpty() && chartNotes != null) {
                    val keys = chartNotes.keys()
                    while (keys.hasNext()) add(keys.next())
                }
                if (isEmpty()) add("normal")
            }.distinct()

            val changesArray = metadata.optJSONArray("timeChanges") ?: JSONArray()
            val allChanges = (0 until changesArray.length()).mapNotNull { i ->
                val point = changesArray.optJSONObject(i) ?: return@mapNotNull null
                val time = point.optDouble("t", Double.NaN)
                val value = point.optDouble("bpm", Double.NaN)
                if (time.isFinite() && value.isFinite() && value > 0) time to value else null
            }.sortedBy { it.first }
            val baseBpm = allChanges.firstOrNull { it.first <= 0.0 }?.second
                ?: metadata.optDouble("bpm", root.optDouble("bpm", 100.0)).takeIf { it > 0 } ?: 100.0
            val bpmChanges = allChanges.filter { it.first > 0.0 }
            val sourceEvents = root.optJSONArray("events") ?: JSONArray()
            val focusChanges = mutableListOf<Pair<Double, Boolean>>()
            val eventOut = JSONArray()
            for (i in 0 until sourceEvents.length()) {
                val event = sourceEvents.optJSONObject(i) ?: continue
                val time = event.optDouble("t", event.optDouble("time", event.optDouble("timestamp", 0.0)))
                val name = event.optString("e", event.optString("name", event.optString("event", "")))
                if (name.isBlank()) continue
                val rawValue = event.opt("v")
                if (name.equals("FocusCamera", true)) {
                    val focus = focusValue(rawValue)
                    if (focus != null && time.isFinite()) focusChanges += time to focus
                    continue
                }
                val (v1, v2) = eventValues(rawValue)
                eventOut.put(JSONArray().put(time).put(JSONArray().put(name).put(v1).put(v2)))
            }
            focusChanges.sortBy { it.first }

            val rawSongName = metadata.optString("songName", metadata.optString("title", path.substringAfterLast('/').substringBefore('-')))
            val song = rawSongName.ifBlank { "Converted Song" }
            val slug = safeName(song)
            val sourceStage = playData.optString("stage", metadata.optString("stage", "stage"))
            val stage = when (sourceStage) {
                "mainStage" -> "stage"
                "spookyMansion" -> "spooky"
                "phillyTrain" -> "philly"
                "limoRide" -> "limo"
                "mallXmas" -> "mall"
                "tankmanBattlefield" -> "tank"
                else -> safeName(sourceStage)
            }
            val player = characters.optString("player", "bf")
            val opponent = characters.optString("opponent", "dad")
            val girlfriend = characters.optString("girlfriend", "gf")
            val scrollSpeedValue = root.opt("scrollSpeed")

            for (difficulty in difficulties) {
                val sourceList = chartNotes?.optJSONArray(difficulty) ?: flatNotes ?: JSONArray()
                val notes = mutableListOf<Triple<Double, Int, Double>>()
                val noteTypes = linkedMapOf<Triple<Double, Int, Double>, String>()
                for (index in 0 until sourceList.length()) {
                    val note = sourceList.optJSONObject(index) ?: continue
                    val time = note.optDouble("t", note.optDouble("time", note.optDouble("timestamp", Double.NaN)))
                    val direction = note.optInt("d", note.optInt("direction", note.optInt("lane", -1)))
                    if (!time.isFinite() || direction !in 0..7) continue
                    // Psych Engine's official V-Slice importer keeps the V-Slice d lane value unchanged.
                    val lane = direction
                    val sustain = note.optDouble("l", note.optDouble("length", note.optDouble("sustain", 0.0))).coerceAtLeast(0.0)
                    val triple = Triple(time, lane, sustain)
                    notes += triple
                    val kind = note.optString("k", "").trim()
                    if (kind.isNotBlank() && !kind.equals("normal", true)) noteTypes[triple] = kind
                }
                if (notes.isEmpty()) {
                    warnings += "$path [$difficulty]: لا توجد نوتات صالحة لهذه الصعوبة؛ تم تجاوزها فقط."
                    continue
                }
                val speed = when (scrollSpeedValue) {
                    is JSONObject -> scrollSpeedValue.optDouble(difficulty, scrollSpeedValue.optDouble("default", 1.0))
                    is Number -> scrollSpeedValue.toDouble()
                    else -> 1.0
                }
                val chartText = psychChart(
                    song, baseBpm, speed, stage, player, opponent, notes, eventOut,
                    true, bpmChanges, focusChanges, true, noteTypes
                )
                val chartRoot = JSONObject(chartText)
                val psychSong = chartRoot.optJSONObject("song")
                psychSong?.put("gfVersion", girlfriend)
                metadata.optString("artist").takeIf { it.isNotBlank() }?.let { psychSong?.put("artist", it) }
                metadata.optString("charter").takeIf { it.isNotBlank() }?.let { psychSong?.put("charter", it) }
                val diffSlug = safeName(difficulty)
                val chartBytes = utf(chartRoot.toString(2))
                out["data/$slug/$slug-$diffSlug.json"] = chartBytes
                if (difficulty.equals("normal", true)) out.putIfAbsent("data/$slug/$slug.json", chartBytes)
                converted++
            }
        }
        convertVSliceCharacterJson(files, out, warnings)
        convertVSliceStageJson(files, out, warnings)
        if (converted == 0) warnings += "V-Slice: لم يتم العثور على شارت قابل للتحويل؛ لا يمنع ذلك تصدير الأصول المتوافقة."
        return converted
    }

    private fun focusValue(value: Any?): Boolean? {
        val raw = when (value) {
            is JSONObject -> value.opt("char")?.toString() ?: value.opt("value")?.toString()
            else -> value?.toString()
        } ?: return null
        return when (raw) {
            "0", "boyfriend", "player" -> true
            "1", "dad", "opponent" -> false
            else -> null
        }
    }

    private fun eventValues(value: Any?): Pair<String, String> = when (value) {
        is JSONObject -> {
            val first = value.opt("value1") ?: value.opt("x") ?: value.opt("char")
                ?: value.keys().asSequence().mapNotNull { value.opt(it) }.firstOrNull()
            val second = value.opt("value2") ?: value.opt("y")
                ?: value.keys().asSequence().mapNotNull { value.opt(it) }.drop(1).firstOrNull()
            (first?.toString() ?: "") to (second?.toString() ?: "")
        }
        is JSONArray -> (value.opt(0)?.toString() ?: "") to (value.opt(1)?.toString() ?: "")
        null -> "" to ""
        else -> value.toString() to ""
    }

    private fun convertVSliceCharacterJson(files: Map<String, ByteArray>, out: MutableMap<String, ByteArray>, warnings: MutableList<String>) {
        for ((path, bytes) in files) {
            if (!path.startsWith("data/characters/", true) || !path.endsWith(".json", true)) continue
            val source = json(bytes) ?: continue
            val renderType = source.optString("renderType", "sparrow").lowercase(Locale.ROOT)
            if (renderType != "sparrow") {
                warnings += "$path: renderType '$renderType' غير مدعوم كتحويل مباشر؛ لن أنشئ إعداد شخصية ناقصاً."
                continue
            }
            val id = safeName(path.substringAfterLast('/').removeSuffix(".json"))
            val sourceAnimations = source.optJSONArray("animations") ?: JSONArray()
            val animations = JSONArray()
            for (i in 0 until sourceAnimations.length()) {
                val anim = sourceAnimations.optJSONObject(i) ?: continue
                val indices = anim.optJSONArray("frameIndices") ?: JSONArray()
                val offsets = anim.optJSONArray("offsets") ?: JSONArray().put(0).put(0)
                animations.put(JSONObject()
                    .put("anim", anim.optString("name", "idle"))
                    .put("name", anim.optString("prefix", anim.optString("name", "idle")))
                    .put("fps", anim.optInt("frameRate", 24))
                    .put("loop", anim.optBoolean("looped", false))
                    .put("indices", indices)
                    .put("offsets", offsets))
            }
            val camera = source.optJSONArray("cameraOffsets") ?: JSONArray().put(0).put(0)
            val position = source.optJSONArray("offsets") ?: JSONArray().put(0).put(0)
            val icon = source.optJSONObject("healthIcon")?.optString("id", id) ?: id
            val asset = source.optString("assetPath", "characters/$id").removeSuffix(".png")
            val character = JSONObject()
                .put("image", asset)
                .put("healthicon", icon)
                .put("scale", source.optDouble("scale", 1.0))
                .put("sing_duration", source.optDouble("singTime", 8.0))
                .put("camera_position", camera)
                .put("position", position)
                .put("flip_x", source.optBoolean("flipX", false))
                .put("no_antialiasing", source.optBoolean("isPixel", false))
                .put("animations", animations)
            out["characters/$id.json"] = utf(character.toString(2))
            if (animations.length() == 0) warnings += "$path: لا توجد animations في تعريف الشخصية."
        }
    }

    private fun convertVSliceStageJson(files: Map<String, ByteArray>, out: MutableMap<String, ByteArray>, warnings: MutableList<String>) {
        for ((path, bytes) in files) {
            if (!path.startsWith("data/stages/", true) || !path.endsWith(".json", true)) continue
            val source = json(bytes) ?: continue
            val sourceId = path.substringAfterLast('/').removeSuffix(".json")
            val id = when (sourceId) {
                "mainStage" -> "stage"
                "spookyMansion" -> "spooky"
                "phillyTrain" -> "philly"
                "limoRide" -> "limo"
                "mallXmas" -> "mall"
                "tankmanBattlefield" -> "tank"
                else -> safeName(sourceId)
            }
            val props = source.optJSONArray("props") ?: JSONArray()
            val characters = source.optJSONObject("characters") ?: JSONObject()
            val roles = listOf("bf" to "boyfriend", "dad" to "dad", "gf" to "gf")
            val characterZ = roles.mapNotNull { (sourceRole, _) -> characters.optJSONObject(sourceRole)?.optInt("zIndex") }.minOrNull() ?: 300
            fun luaQ(text: String) = text.replace("\\", "\\\\").replace("'", "\\'")
            val lua = StringBuilder("-- Converted from V-Slice stage JSON\nfunction onCreate()\n")
            val sortedProps = (0 until props.length()).mapNotNull { props.optJSONObject(it) }.sortedBy { it.optInt("zIndex", 0) }
            for ((index, prop) in sortedProps.withIndex()) {
                val name = safeName(prop.optString("name", "prop$index"))
                val asset = prop.optString("assetPath", name).removeSuffix(".png")
                val position = prop.optJSONArray("position") ?: JSONArray().put(0).put(0)
                val scale = prop.optJSONArray("scale") ?: JSONArray().put(1).put(1)
                val scroll = prop.optJSONArray("scroll") ?: JSONArray().put(1).put(1)
                val x = position.optDouble(0, 0.0); val y = position.optDouble(1, 0.0)
                val sx = scale.optDouble(0, 1.0); val sy = scale.optDouble(1, 1.0)
                val scrollX = scroll.optDouble(0, 1.0); val scrollY = scroll.optDouble(1, 1.0)
                val alpha = prop.optDouble("alpha", 1.0).coerceIn(0.0, 1.0)
                val front = prop.optInt("zIndex", 0) > characterZ
                val animations = prop.optJSONArray("animations") ?: JSONArray()
                if (asset.startsWith("#") && asset.length in 4..9) {
                    val color = asset.removePrefix("#")
                    val normalized = if (color.length == 3) color.map { "$it$it" }.joinToString("") else color
                    lua.append("makeLuaSprite('$name','',${x},${y})\nmakeGraphic('$name',1280,720,'${normalized.uppercase(Locale.ROOT)}')\n")
                } else if (animations.length() > 0) {
                    lua.append("makeAnimatedLuaSprite('$name','${luaQ(asset)}',$x,$y)\n")
                    for (a in 0 until animations.length()) {
                        val animation = animations.optJSONObject(a) ?: continue
                        val animName = luaQ(animation.optString("name", "idle"))
                        val prefix = luaQ(animation.optString("prefix", animName))
                        val fps = animation.optInt("frameRate", 24).coerceIn(1, 120)
                        val loop = animation.optBoolean("looped", false)
                        val indices = animation.optJSONArray("frameIndices")
                        if (indices != null && indices.length() > 0) {
                            val indexList = (0 until indices.length()).map { indices.optInt(it) }.joinToString(",")
                            lua.append("addAnimationByIndices('$name','$animName','$prefix','$indexList',$fps,$loop)\n")
                        } else lua.append("addAnimationByPrefix('$name','$animName','$prefix',$fps,$loop)\n")
                    }
                    val start = luaQ(prop.optString("startingAnimation", ""))
                    if (start.isNotBlank()) lua.append("objectPlayAnimation('$name','$start',true)\n")
                } else {
                    lua.append("makeLuaSprite('$name','${luaQ(asset)}',$x,$y)\n")
                }
                lua.append("setScrollFactor('$name',$scrollX,$scrollY)\nscaleObject('$name',$sx,$sy)\n")
                lua.append("setProperty('$name.alpha',$alpha)\naddLuaSprite('$name',$front)\n")
            }
            lua.append("end\n\nfunction onCreatePost()\n")
            lua.append("setProperty('defaultCamZoom', ${source.optDouble("cameraZoom", 1.0)})\n")
            for ((sourceRole, psychRole) in roles) {
                val role = characters.optJSONObject(sourceRole) ?: continue
                val position = role.optJSONArray("position") ?: continue
                lua.append("setProperty('$psychRole.x', ${position.optDouble(0, 0.0)})\n")
                lua.append("setProperty('$psychRole.y', ${position.optDouble(1, 0.0)})\n")
            }
            lua.append("end\n")
            fun stagePos(sourceRole: String, defaultX: Double, defaultY: Double): JSONArray {
                val role = characters.optJSONObject(sourceRole) ?: return JSONArray().put(defaultX).put(defaultY)
                val position = role.optJSONArray("position") ?: return JSONArray().put(defaultX).put(defaultY)
                return JSONArray().put(position.optDouble(0, defaultX)).put(position.optDouble(1, defaultY))
            }
            val stageData = JSONObject()
                .put("directory", "")
                .put("defaultZoom", source.optDouble("cameraZoom", 1.0))
                .put("isPixelStage", source.optBoolean("isPixelStage", false))
                .put("boyfriend", stagePos("bf", 770.0, 100.0))
                .put("opponent", stagePos("dad", 100.0, 100.0))
                .put("girlfriend", stagePos("gf", 400.0, 130.0))
                .put("hide_girlfriend", false)
                .put("camera_boyfriend", JSONArray().put(0).put(0))
                .put("camera_opponent", JSONArray().put(0).put(0))
                .put("camera_girlfriend", JSONArray().put(0).put(0))
                .put("camera_speed", 1.0)
            out["stages/$id.json"] = utf(stageData.toString(2))
            out["stages/$id.lua"] = utf(lua.toString())
            if (characters.length() == 0) warnings += "$path: حُولت عناصر props وcameraZoom دون مواقع شخصيات."
        }
    }
}
