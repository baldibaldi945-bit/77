package com.modbridge.core

/** Conservative offline diagnostics. It never claims to execute or fully understand arbitrary code. */
object ScriptDoctor {
    data class Report(val language: String, val errors: List<String>, val warnings: List<String>, val migration: String?)

    fun inspect(filename: String, source: String): Report {
        val ext = filename.substringAfterLast('.', "").lowercase()
        val language = when (ext) { "lua" -> "Lua"; "hx", "haxe", "hxc" -> "Haxe/HScript"; "json" -> "JSON"; else -> "Text/Script" }
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (source.isBlank()) errors += "الملف فارغ."
        if (ext == "json") {
            try { org.json.JSONTokener(source).nextValue() }
            catch (t: Throwable) { errors += "JSON parsing: ${t.message ?: "invalid JSON"}" }
        }
        val opens = source.count { it == '{' }; val closes = source.count { it == '}' }
        if (opens != closes) warnings += "عدد الأقواس المعقوفة غير متوازن: {=$opens و }=$closes."
        val parenOpen = source.count { it == '(' }; val parenClose = source.count { it == ')' }
        if (parenOpen != parenClose) warnings += "عدد الأقواس الدائرية غير متوازن: (=$parenOpen و )=$parenClose."
        if (ext == "lua") {
            val functions = Regex("(?m)^\\s*function\\b").findAll(source).count()
            val ends = Regex("(?m)^\\s*end\\b").findAll(source).count()
            if (ends < functions) warnings += "عدد end أقل من عدد function؛ راجع إغلاق الدوال والكتل."
            if (Regex("(?i)runHaxeCode|runHaxeFunction").containsMatchIn(source)) warnings += "السكربت يستدعي Haxe؛ لن يعمل إذا لم يكن المحرك/الإصدار يدعم هذا الاستدعاء."
        }
        if (ext in setOf("hx", "haxe", "hxc")) {
            val migration = ScriptMigrationAI.translate(source)?.let {
                "Psych Lua migration: recognized ${it.recognized} statements; skipped ${it.skipped}.\n" +
                    it.recognizedFeatures.joinToString(", ") +
                    if (it.skippedExamples.isNotEmpty()) "\nNeeds manual port:\n" + it.skippedExamples.joinToString("\n") else ""
            }
            if (migration == null) warnings += "لم يتم التعرف على أنماط Haxe آمنة للتحويل الآلي؛ لم يتم اختراع كود بديل."
            return Report(language, errors, warnings, migration)
        }
        return Report(language, errors, warnings, null)
    }
}
