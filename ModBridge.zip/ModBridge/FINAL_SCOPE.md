# ModBridge 1.6.0 — implementation and verification status

## Implemented in source

- Six selectable UI languages: Algerian Arabic, Standard Arabic, English, Portuguese, Japanese, and Thai.
- Touch pointer positioning and lifecycle-aware background music pause/resume.
- Forward conversion from supported V-Slice, Codename Engine, and FNMM layouts into Psych Engine ZIP.
- Required Psych directory containers, source `My-Mod` template merge, Freeplay week generation, and Story Mode hiding.
- FNMM horizontal-strip sprite builder, multi-atlas Sprite Map reader for the supplied `ATLAS.SPRITES` / TexturePacker `frames` schemas, Sparrow PNG/XML export with generated animation-prefixed SubTexture aliases, Psych character JSON building, and embedded GIF-to-atlas processing. GIF-derived characters use `images/characters` atlases and `characters/<id>.json`.
- Offline Script Lab: code/text and ZIP source ingestion, static checks, local example retrieval. Image/audio files attach metadata only.
- Psych stage JSON editor for zoom/camera/character coordinates and chart `mustHitSection` direction flip. It saves a new archive and forces landscape while open.
- Psych→FNMM reverse conversion: chart note lane/timing conversion into the reference two-by-four `strumLines`, per-chart `.FNMM` output, copying available Inst/Voices OGG, reading stage JSON positions, extracting simple numeric `makeLuaSprite`/`makeAnimatedLuaSprite` stage props, converting Sparrow character/stage animations into horizontal FNMM strips (one PNG per animation, matching the supplied sample), and splitting `icon-*.png` player/opponent health icon sheets.
- Image Optimizer (merged after inspecting `ImageShrink.zip`): PNG/WebP/JPEG/GIF output; dimension scaling; alpha retention; selectable black/white flattening; indexed PNG output at quality below 100; animated GIF sampling with compact palette.
- Knowledge archive contains the user's example mod and code/mechanic samples; `CodeKnowledgeBase` also indexes the separate `fnmm_format_reference.json` and `sprite_map_reference.json` assets directly with per-entry and total-size guards.

## Partial / not a guaranteed engine port

- Forward conversion recognizes specific chart, character, stage, event, and Haxe/HScript patterns. Arbitrary classes, dynamic runtime APIs, custom notetypes, events, Lua callbacks, and shader behavior still require dedicated tested mappings.
- Psych→FNMM does not execute/translate all Lua/Haxe. Event arrays and unsupported scripts are retained as reference text and reported; unsupported chart lanes above the 8 lanes in the supplied example are skipped. Custom note types are metadata only unless FNMM has a matching implementation.
- Psych→FNMM converts simple static/numeric stage object creation and Sparrow prefix animations. Expressions, tweens, shader effects, object lifecycle, complex event timing, and arbitrary script-driven stage mechanics are not equivalent yet.
- The 1.6.0 live stage editor renders an approximation of Psych (Canvas, not the real engine): characters use first idle frame, camera points use Psych 0.7 formulas (VERIFY in game), only numeric makeLuaSprite/makeAnimatedLuaSprite objects are read, tweens/shaders/setGraphicSize are not previewed. It does not edit per-animation offsets or play charts.
- Image Optimizer processes one file per operation. GIF playback timing/disposal is sampled using Android's `Movie`; GIF color palette is lossy. PNG quality below 100 uses indexed color/quantized alpha; exact transparency gradients may be reduced. PNG at 100 is lossless.
- Script Lab is a local rule-based tool, not a general LLM. Image and audio attachments show metadata; there is no image understanding or speech transcription.
- Large file processing is bounded to avoid out-of-memory failures on phones. “Unlimited memory” cannot be guaranteed on Android.

## Validation completed in this environment

- Inspected user-provided Psych template ZIP, FNMM sample archive, ImageShrink source, Sprite Map PNG/JSON, and Animation.json.
- Confirmed sample FNMM root schema: `data.json` / `scene.json` / `events.json` and numbered `sprites/<name>/` PNGs with `sprite.json`.
- Added code paths that follow that schema.
- Checked the GIF LZW encoding algorithm by generating GIF payloads and decoding them with an independent image decoder for several test sizes.
- Checked source Kotlin files with Kotlin parser diagnostics; no parser-level syntax diagnostics were reported. Android/Compose/AndroidX dependencies are unavailable in this environment, so this is not a full compiler run.

## 1.6.0 additions (source only, not compiled here)

- Live stage editor (StageSession / StageModel / StagePreviewView / StageEditorScreen): drag objects, characters and camera points, add/remove/replace sprites and GIFs (GIF -> Sparrow atlas on save), replace characters, per-page chart side flip, arrow/splash skin import, health bar frame presets, non-destructive override script `scripts/ModBridge_<stage>.lua`, disk-backed ZIP streaming, minSdk 21.
- `porting_expertise.txt` indexed by Script Lab as per-topic entries.

## Not verified

- No Gradle installation or Android SDK platform was available in this container. No APK was built or installed here.
- `gradle test assembleDebug` must complete successfully in the supplied GitHub Actions workflow before this revision can be called APK-build verified.
